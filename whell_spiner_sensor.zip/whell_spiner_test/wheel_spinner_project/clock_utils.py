import os
from datetime import datetime
from PyQt5.QtCore import Qt, QRect
from PyQt5.QtGui import QPainter, QColor, QFont, QPen, QBrush, QPixmap, QRadialGradient, QLinearGradient


class ClockUtils:
    """DYNAMIC utility functions for clock drawing - scales with any size"""
    
    @staticmethod
    def get_clock_radius(width, height):
        """Get DYNAMIC clock radius based on current dimensions"""
        # Use maximum available space
        max_diameter = min(width, height) - 20  # Minimal padding
        radius = max_diameter // 2
        
        # Ensure reasonable minimum
        return max(radius, 150)
    
    @staticmethod
    def draw_background(painter, config, width, height, radius):
        """Draw DYNAMIC background that scales with size"""
        cx, cy = width // 2, height // 2
        
        # Background image with DYNAMIC scaling
        if config['background_type'] == 'Image' and config['background_image'] and os.path.exists(config['background_image']):
            pixmap = QPixmap(config['background_image'])
            if not pixmap.isNull():
                circle_diameter = radius * 2
                scaled = pixmap.scaled(
                    circle_diameter, circle_diameter, 
                    Qt.KeepAspectRatioByExpanding,
                    Qt.SmoothTransformation
                )
                
                if scaled.width() > circle_diameter or scaled.height() > circle_diameter:
                    crop_x = (scaled.width() - circle_diameter) // 2
                    crop_y = (scaled.height() - circle_diameter) // 2
                    scaled = scaled.copy(crop_x, crop_y, circle_diameter, circle_diameter)
                
                # DYNAMIC circular mask
                mask = QPixmap(circle_diameter, circle_diameter)
                mask.fill(Qt.transparent)
                mp = QPainter(mask)
                mp.setRenderHint(QPainter.Antialiasing)
                mp.setBrush(Qt.black)
                mp.setPen(Qt.NoPen)
                mp.drawEllipse(0, 0, circle_diameter, circle_diameter)
                mp.end()
                
                scaled.setMask(mask.mask())
                draw_x = cx - circle_diameter // 2
                draw_y = cy - circle_diameter // 2
                painter.drawPixmap(draw_x, draw_y, scaled)
                
        # Color background with DYNAMIC gradients
        elif config['background_type'] == 'Color':
            # Style-specific gradients for analog clocks
            if config['clock_type'] == 'Analog':
                style = config.get('analog_style', 'modern')
                if style in ['elegant', 'neon']:
                    # DYNAMIC gradient that scales with radius
                    gradient = QRadialGradient(cx, cy, radius * 1.2)
                    if style == 'elegant':
                        gradient.setColorAt(0, config['background_color'].lighter(110))
                        gradient.setColorAt(0.5, config['background_color'])
                        gradient.setColorAt(1, config['background_color'].darker(120))
                    else:  # neon
                        gradient.setColorAt(0, QColor(20, 20, 40))
                        gradient.setColorAt(0.5, QColor(10, 10, 30))
                        gradient.setColorAt(1, QColor(0, 0, 20))
                    painter.setBrush(QBrush(gradient))
                else:
                    painter.setBrush(QBrush(config['background_color']))
            else:
                # Digital gradients with DYNAMIC scaling
                if config.get('digital_style') in ['neon', 'matrix', 'retro']:
                    gradient = QRadialGradient(cx, cy, radius * 1.2)
                    
                    if config['digital_style'] == 'neon':
                        gradient.setColorAt(0, QColor(20, 20, 40))
                        gradient.setColorAt(0.5, QColor(10, 10, 30))
                        gradient.setColorAt(1, QColor(0, 0, 20))
                    elif config['digital_style'] == 'matrix':
                        gradient.setColorAt(0, QColor(0, 20, 0))
                        gradient.setColorAt(0.5, QColor(0, 10, 0))
                        gradient.setColorAt(1, QColor(0, 0, 0))
                    elif config['digital_style'] == 'retro':
                        gradient.setColorAt(0, QColor(40, 0, 40))
                        gradient.setColorAt(0.5, QColor(20, 0, 20))
                        gradient.setColorAt(1, QColor(10, 0, 10))
                    
                    painter.setBrush(QBrush(gradient))
                else:
                    painter.setBrush(QBrush(config['background_color']))
                
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(cx - radius, cy - radius, radius * 2, radius * 2)
            
        # Frame based on clock type with DYNAMIC sizing
        if config['clock_type'] == 'Digital':
            ClockUtils.draw_modern_frame(painter, cx, cy, radius, config)
        else:
            ClockUtils.draw_analog_frame(painter, cx, cy, radius, config)
    
    @staticmethod
    def draw_modern_frame(painter, cx, cy, radius, config):
        """Draw DYNAMIC modern glowing frame that scales with size"""
        # Scale frame thickness with radius
        base_thickness = max(2, radius // 100)
        
        for i in range(3):
            opacity = 60 - i * 20
            width = base_thickness + i
            color = QColor(config['clock_color'])
            color.setAlpha(opacity)
            
            painter.setPen(QPen(color, width))
            painter.setBrush(Qt.NoBrush)
            painter.drawEllipse(cx - radius - i, cy - radius - i, 
                              (radius + i) * 2, (radius + i) * 2)
    
    @staticmethod
    def draw_analog_frame(painter, cx, cy, radius, config):
        """Draw DYNAMIC frame for analog clocks"""
        style = config.get('analog_style', 'modern')
        
        # Scale frame thickness with radius
        base_thickness = max(2, radius // 80)
        
        if style == 'neon':
            # DYNAMIC glowing neon frame
            for i in range(5):
                opacity = 80 - i * 15
                width = base_thickness + i
                color = QColor(config['clock_color'])
                color.setAlpha(opacity)
                painter.setPen(QPen(color, width))
                painter.setBrush(Qt.NoBrush)
                painter.drawEllipse(cx - radius - i, cy - radius - i, 
                                  (radius + i) * 2, (radius + i) * 2)
        elif style == 'industrial':
            # DYNAMIC metallic industrial frame
            painter.setBrush(Qt.NoBrush)
            painter.setPen(QPen(QColor(100, 100, 100), base_thickness * 2))
            painter.drawEllipse(cx - radius, cy - radius, radius * 2, radius * 2)
            painter.setPen(QPen(QColor(150, 150, 150), base_thickness))
            painter.drawEllipse(cx - radius + 2, cy - radius + 2, (radius - 2) * 2, (radius - 2) * 2)
        else:
            # DYNAMIC standard frame
            painter.setBrush(Qt.NoBrush)
            painter.setPen(QPen(QColor(100, 100, 100, 150), base_thickness))
            painter.drawEllipse(cx - radius, cy - radius, radius * 2, radius * 2)
    
    @staticmethod
    def draw_date(painter, x, y, config, color=None):
        """Draw DYNAMIC date display for digital clocks with MUCH LARGER font"""
        if not color:
            color = config['clock_color']
            
        # Use selected date format
        date_format = config.get('date_format', 'dd.MM.yyyy')
        python_format = ClockUtils.convert_qt_to_python_format(date_format)
        date_text = datetime.now().strftime(python_format)
        
        # CONSTRAINED font size - fits within wheel circle
        # Calculate radius from position to estimate scale
        estimated_radius = max(200, min(x, y) // 2)  # Rough estimate
        base_font_size = 24  # Reasonable base size for date
        scale_factor = estimated_radius / 200.0
        font_size = max(18, int(base_font_size * scale_factor))  # Constrained maximum
        
        # Additional constraint: max 25% of estimated radius
        max_allowed_font = int(estimated_radius * 0.25)
        font_size = min(font_size, max_allowed_font)
        
        font = QFont("Arial", font_size, QFont.Bold)  # Made bold for better visibility
        painter.setFont(font)
        
        # DYNAMIC date positioning - scale width with font size
        date_width = max(400, font_size * 15)  # Much larger width
        
        # Date glow effect - dynamic pen width - FIXED: Use QRect for drawText
        glow_pen_width = max(2, font_size // 10)
        date_rect = QRect(int(x - date_width//2), int(y), int(date_width), int(font_size + 10))
        
        for i in range(5, 0, -1):  # More glow layers
            glow_color = QColor(color)
            glow_color.setAlpha(40)  # Stronger glow
            painter.setPen(QPen(glow_color, glow_pen_width + i))
            painter.drawText(date_rect, Qt.AlignCenter, date_text)
            
        # Main date text - dynamic pen width - FIXED: Use QRect for drawText
        main_pen_width = max(1, font_size // 20)
        painter.setPen(QPen(color, main_pen_width))
        painter.drawText(date_rect, Qt.AlignCenter, date_text)
    
    @staticmethod
    def draw_analog_date(painter, center_x, center_y, radius, config, color=None):
        """Draw DYNAMIC date display inside analog clock circle with LARGER font"""
        if not color:
            color = config['clock_color']
            
        # Use selected date format
        date_format = config.get('date_format', 'dd.MM.yyyy')
        python_format = ClockUtils.convert_qt_to_python_format(date_format)
        date_text = datetime.now().strftime(python_format)
        
        # DYNAMIC positioning in lower third of clock
        date_y = center_y + radius // 3
        
        # CONSTRAINED font size based on radius - fits within wheel
        base_font_size = 16  # Reasonable base size
        font_size = max(14, int(base_font_size * radius / 200))  # Scale with radius, reasonable minimum
        
        # Additional constraint: max 20% of radius for safety
        max_allowed_font = int(radius * 0.2)
        font_size = min(font_size, max_allowed_font)
        font = QFont("Arial", font_size, QFont.Bold)
        painter.setFont(font)
        
        rect = painter.fontMetrics().boundingRect(date_text)
        
        # DYNAMIC box size based on radius and text - LARGER
        box_padding = max(25, radius // 20)  # Increased padding
        box_width = rect.width() + box_padding * 2
        box_height = rect.height() + box_padding
        
        box_rect = QRect(center_x - box_width//2, date_y - box_height//2, 
                        box_width, box_height)
        
        # DYNAMIC box background with transparency
        box_opacity = min(240, 180 + radius // 10)  # Scale opacity slightly with size
        painter.setBrush(QBrush(QColor(192, 192, 192, box_opacity)))
        
        # DYNAMIC border thickness
        border_thickness = max(2, radius // 60)  # Thicker border
        painter.setPen(QPen(color, border_thickness))
        
        # DYNAMIC corner radius
        corner_radius = max(8, radius // 30)  # Larger corner radius
        painter.drawRoundedRect(box_rect, corner_radius, corner_radius)
        
        # Date text with better visibility
        text_pen_width = max(1, font_size // 15)
        painter.setPen(QPen(color, text_pen_width))
        painter.drawText(box_rect, Qt.AlignCenter, date_text)
    
    @staticmethod
    def convert_qt_to_python_format(qt_format):
        """Convert Qt date format to Python datetime format"""
        conversion_map = {
            'dd.MM.yyyy': '%d.%m.%Y',
            'MM/dd/yyyy': '%m/%d/%Y',
            'yyyy-MM-dd': '%Y-%m-%d',
            'dd/MM/yyyy': '%d/%m/%Y',
            'MMMM dd, yyyy': '%B %d, %Y',
            'dd MMMM yyyy': '%d %B %Y',
            'ddd, MMM dd': '%a, %b %d'
        }
        
        return conversion_map.get(qt_format, '%d.%m.%Y')
    
    @staticmethod
    def scale_font_size(base_size, radius, min_size=8, max_size=100):
        """Scale font size based on radius while keeping reasonable bounds"""
        # Calculate scale factor based on radius
        scale_factor = radius / 200  # 200 is baseline radius
        scaled_size = int(base_size * scale_factor)
        
        # Apply bounds
        return max(min_size, min(scaled_size, max_size))
    
    @staticmethod
    def scale_thickness(base_thickness, radius, min_thickness=1, max_thickness=20):
        """Scale line thickness based on radius"""
        scale_factor = radius / 200
        scaled_thickness = int(base_thickness * scale_factor)
        
        return max(min_thickness, min(scaled_thickness, max_thickness))
