import math
import random
from PyQt5.QtCore import Qt, QTime, QRect, QRectF, QPointF
from PyQt5.QtGui import QPainter, QColor, QFont, QPen, QBrush, QLinearGradient, QRadialGradient, QPolygonF


class DigitalClockStyles:
    """Enhanced digital clock style implementations with more original styles"""
    
    @staticmethod
    def draw_neon_clock(painter, config, width, height, glow_intensity, pulse_value):
        """Neon style digital clock"""
        cx, cy = width // 2, height // 2
        
        current_time = QTime.currentTime()
        time_text = current_time.toString("HH:mm:ss" if config['show_seconds'] else "HH:mm")
        
        # Neon font
        font = QFont("Arial", 72 if config['show_seconds'] else 84, QFont.Bold)
        painter.setFont(font)
        
        # Text metrics
        fm = painter.fontMetrics()
        text_rect = fm.boundingRect(time_text)
        x = cx - text_rect.width() // 2
        y = cy + text_rect.height() // 4
        
        # Multiple glow layers
        for i in range(5, 0, -1):
            glow_color = QColor(config['clock_color'])
            glow_color.setAlpha(30 + int(20 * pulse_value))
            
            pen = QPen(glow_color, i * 3)
            painter.setPen(pen)
            painter.drawText(x, y, time_text)
            
        # Main text
        painter.setPen(QPen(Qt.white, 2))
        painter.drawText(x, y, time_text)
        
        # Inner glow
        inner_glow = QColor(config['clock_color'])
        inner_glow.setAlpha(200)
        painter.setPen(QPen(inner_glow, 1))
        painter.drawText(x, y, time_text)
    
    @staticmethod
    def draw_lcd_clock(painter, config, width, height, glow_intensity, pulse_value):
        """LCD/LED style digital clock"""
        cx, cy = width // 2, height // 2
        
        current_time = QTime.currentTime()
        time_text = current_time.toString("HH:mm:ss" if config['show_seconds'] else "HH:mm")
        
        # LCD background panel
        panel_width = 400 if config['show_seconds'] else 300
        bg_rect = QRect(cx - panel_width//2, cy - 50, panel_width, 100)
        
        # Dark LCD background
        painter.setBrush(QBrush(QColor(10, 10, 10)))
        painter.setPen(QPen(QColor(30, 30, 30), 2))
        painter.drawRoundedRect(bg_rect, 10, 10)
        
        # LCD font
        font = QFont("Consolas", 64, QFont.Bold)
        painter.setFont(font)
        
        # Inactive segments (88:88:88)
        painter.setPen(QPen(QColor(30, 30, 30), 2))
        painter.drawText(bg_rect, Qt.AlignCenter, "88:88:88" if config['show_seconds'] else "88:88")
        
        # Active segments
        lcd_color = QColor(0, 255, 100)  # Green LCD
        painter.setPen(QPen(lcd_color, 2))
        painter.drawText(bg_rect, Qt.AlignCenter, time_text)
        
        # LCD glow
        for i in range(3):
            glow_color = QColor(lcd_color)
            glow_color.setAlpha(50 - i * 15)
            painter.setPen(QPen(glow_color, (i + 1) * 2))
            painter.drawText(bg_rect, Qt.AlignCenter, time_text)
    
    @staticmethod
    def draw_matrix_clock(painter, config, width, height, glow_intensity, pulse_value, rotation_angle):
        """Matrix style digital clock"""
        cx, cy = width // 2, height // 2
        
        # Matrix rain effect
        DigitalClockStyles.draw_matrix_rain(painter, width, height, rotation_angle)
        
        current_time = QTime.currentTime()
        time_text = current_time.toString("HH:mm:ss" if config['show_seconds'] else "HH:mm")
        
        # Matrix font
        font = QFont("Courier New", 68, QFont.Bold)
        painter.setFont(font)
        
        # Text metrics
        fm = painter.fontMetrics()
        text_rect = fm.boundingRect(time_text)
        x = cx - text_rect.width() // 2
        y = cy + text_rect.height() // 4
        
        # Matrix green glow
        for i in range(4, 0, -1):
            matrix_color = QColor(0, 255, 0)
            matrix_color.setAlpha(40 + int(10 * pulse_value))
            painter.setPen(QPen(matrix_color, i * 2))
            painter.drawText(x, y, time_text)
            
        # Main text
        painter.setPen(QPen(QColor(150, 255, 150), 2))
        painter.drawText(x, y, time_text)
    
    @staticmethod
    def draw_minimalist_clock(painter, config, width, height, glow_intensity, pulse_value):
        """Minimalist style digital clock"""
        cx, cy = width // 2, height // 2
        
        current_time = QTime.currentTime()
        
        # Separate hour and minute
        hour_text = f"{current_time.hour():02d}"
        minute_text = f"{current_time.minute():02d}"
        
        # Elegant font
        font = QFont("Arial", 96, QFont.Light)
        painter.setFont(font)
        
        # Hour
        painter.setPen(QPen(config['clock_color'], 1))
        hour_rect = painter.fontMetrics().boundingRect(hour_text)
        painter.drawText(cx - hour_rect.width() - 20, cy + hour_rect.height() // 4, hour_text)
        
        # Separator dots with pulse
        dot_size = 8 + 4 * pulse_value
        painter.setBrush(QBrush(config['clock_color']))
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(int(cx - dot_size/2), int(cy - 20 - dot_size/2), int(dot_size), int(dot_size))
        painter.drawEllipse(int(cx - dot_size/2), int(cy + 20 - dot_size/2), int(dot_size), int(dot_size))
        
        # Minute
        painter.setPen(QPen(config['clock_color'], 1))
        painter.drawText(cx + 20, cy + hour_rect.height() // 4, minute_text)
        
        # Seconds as a progress line
        if config['show_seconds']:
            seconds = current_time.second()
            progress = seconds / 60.0
            
            # Progress bar
            bar_width = 300
            bar_x = cx - bar_width // 2
            bar_y = cy + 80
            
            # Background line
            painter.setPen(QPen(QColor(100, 100, 100, 50), 2))
            painter.drawLine(bar_x, bar_y, bar_x + bar_width, bar_y)
            
            # Progress line
            painter.setPen(QPen(config['clock_color'], 3))
            painter.drawLine(bar_x, bar_y, int(bar_x + bar_width * progress), bar_y)
            
            # Progress dot
            dot_x = bar_x + bar_width * progress
            painter.setBrush(QBrush(config['clock_color']))
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(int(dot_x - 5), bar_y - 5, 10, 10)
    
    @staticmethod
    def draw_retro_clock(painter, config, width, height, glow_intensity, pulse_value):
        """Retro-futuristic style digital clock"""
        cx, cy = width // 2, height // 2
        
        current_time = QTime.currentTime()
        time_text = current_time.toString("HH:mm:ss" if config['show_seconds'] else "HH:mm")
        
        # Retro panel
        panel_width = 440 if config['show_seconds'] else 340
        panel_rect = QRect(cx - panel_width//2, cy - 60, panel_width, 120)
        
        # Panel gradient
        gradient = QLinearGradient(panel_rect.topLeft(), panel_rect.bottomRight())
        gradient.setColorAt(0, QColor(80, 0, 80))
        gradient.setColorAt(0.5, QColor(120, 0, 120))
        gradient.setColorAt(1, QColor(60, 0, 60))
        
        painter.setBrush(QBrush(gradient))
        painter.setPen(QPen(QColor(255, 0, 255), 3))
        painter.drawRoundedRect(panel_rect, 20, 20)
        
        # Chrome effect
        chrome_gradient = QLinearGradient(panel_rect.topLeft(), panel_rect.bottomLeft())
        chrome_gradient.setColorAt(0, QColor(255, 255, 255, 50))
        chrome_gradient.setColorAt(0.5, QColor(255, 255, 255, 20))
        chrome_gradient.setColorAt(1, QColor(255, 255, 255, 50))
        
        painter.setBrush(QBrush(chrome_gradient))
        painter.setPen(Qt.NoPen)
        painter.drawRoundedRect(panel_rect.adjusted(5, 5, -5, -5), 15, 15)
        
        # Retro font
        font = QFont("Impact", 64, QFont.Bold)
        painter.setFont(font)
        
        # 3D text effect
        for i in range(5, 0, -1):
            offset = i
            shadow_color = QColor(0, 0, 0, 150 - i * 20)
            painter.setPen(QPen(shadow_color, 2))
            painter.drawText(panel_rect.adjusted(offset, offset, offset, offset), 
                           Qt.AlignCenter, time_text)
            
        # Main text
        painter.setPen(QPen(QColor(255, 200, 255), 2))
        painter.drawText(panel_rect, Qt.AlignCenter, time_text)
        
        # Highlight
        painter.setPen(QPen(QColor(255, 255, 255, 180), 1))
        painter.drawText(panel_rect.adjusted(-1, -1, -1, -1), Qt.AlignCenter, time_text)

    # NEW ORIGINAL STYLES START HERE
    
    @staticmethod
    def draw_holographic_clock(painter, config, width, height, glow_intensity, pulse_value):
        """Holographic/Sci-fi style digital clock"""
        cx, cy = width // 2, height // 2
        
        current_time = QTime.currentTime()
        time_text = current_time.toString("HH:mm:ss" if config['show_seconds'] else "HH:mm")
        
        # Holographic base platform
        platform_width = 460 if config['show_seconds'] else 360
        platform_rect = QRect(cx - platform_width//2, cy + 40, platform_width, 20)
        
        # Platform gradient
        platform_gradient = QLinearGradient(platform_rect.topLeft(), platform_rect.bottomLeft())
        platform_gradient.setColorAt(0, QColor(0, 150, 255, 200))
        platform_gradient.setColorAt(1, QColor(0, 50, 150, 100))
        
        painter.setBrush(QBrush(platform_gradient))
        painter.setPen(QPen(QColor(0, 200, 255), 2))
        painter.drawRoundedRect(platform_rect, 10, 10)
        
        # Holographic font
        font = QFont("Arial", 72 if config['show_seconds'] else 84, QFont.Bold)
        painter.setFont(font)
        
        # Text metrics
        fm = painter.fontMetrics()
        text_rect = fm.boundingRect(time_text)
        x = cx - text_rect.width() // 2
        y = cy + text_rect.height() // 4
        
        # Holographic scanning lines
        for i in range(10):
            line_y = y - 40 + i * 8 + int(glow_intensity % 20)
            scan_color = QColor(0, 255, 255, 20 + int(10 * pulse_value))
            painter.setPen(QPen(scan_color, 1))
            painter.drawLine(x - 20, line_y, x + text_rect.width() + 20, line_y)
        
        # Multiple hologram layers
        for i in range(4, 0, -1):
            holo_color = QColor(0, 200 + i * 10, 255)
            holo_color.setAlpha(60 + int(20 * pulse_value))
            painter.setPen(QPen(holo_color, i))
            painter.drawText(x, y - i, time_text)
            
        # Main holographic text
        painter.setPen(QPen(QColor(100, 255, 255), 2))
        painter.drawText(x, y, time_text)
        
        # Holographic shimmer effect
        shimmer_color = QColor(255, 255, 255, int(50 + 30 * pulse_value))
        painter.setPen(QPen(shimmer_color, 1))
        painter.drawText(x - 1, y - 1, time_text)
    
    @staticmethod
    def draw_plasma_clock(painter, config, width, height, glow_intensity, pulse_value):
        """Plasma/Energy style digital clock"""
        cx, cy = width // 2, height // 2
        
        current_time = QTime.currentTime()
        time_text = current_time.toString("HH:mm:ss" if config['show_seconds'] else "HH:mm")
        
        # Plasma energy field
        for i in range(15):
            angle = (glow_intensity + i * 24) % 360
            radius = 120 + 20 * math.sin(math.radians(angle * 2))
            x = cx + radius * math.cos(math.radians(angle))
            y = cy + radius * math.sin(math.radians(angle))
            
            plasma_color = QColor(255, int(100 + 155 * pulse_value), 0, 30)
            painter.setBrush(QBrush(plasma_color))
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(int(x - 8), int(y - 8), 16, 16)
        
        # Plasma font
        font = QFont("Impact", 78 if config['show_seconds'] else 90, QFont.Bold)
        painter.setFont(font)
        
        # Text metrics
        fm = painter.fontMetrics()
        text_rect = fm.boundingRect(time_text)
        x = cx - text_rect.width() // 2
        y = cy + text_rect.height() // 4
        
        # Energy discharge effect
        for i in range(6, 0, -1):
            energy_color = QColor(255, int(150 - i * 15), 0)
            energy_color.setAlpha(80 + int(30 * pulse_value))
            painter.setPen(QPen(energy_color, i * 2))
            painter.drawText(x, y, time_text)
            
        # Core plasma text
        painter.setPen(QPen(QColor(255, 255, 200), 3))
        painter.drawText(x, y, time_text)
        
        # White hot center
        painter.setPen(QPen(Qt.white, 1))
        painter.drawText(x, y, time_text)
    
    @staticmethod
    def draw_crystal_clock(painter, config, width, height, glow_intensity, pulse_value):
        """Crystal/Gem style digital clock"""
        cx, cy = width // 2, height // 2
        
        current_time = QTime.currentTime()
        time_text = current_time.toString("HH:mm:ss" if config['show_seconds'] else "HH:mm")
        
        # Crystal base
        crystal_points = [
            QPointF(cx - 180, cy + 60),
            QPointF(cx - 120, cy - 80),
            QPointF(cx, cy - 100),
            QPointF(cx + 120, cy - 80),
            QPointF(cx + 180, cy + 60),
            QPointF(cx + 60, cy + 80),
            QPointF(cx - 60, cy + 80)
        ]
        
        crystal_polygon = QPolygonF(crystal_points)
        
        # Crystal gradient
        crystal_gradient = QRadialGradient(cx, cy - 20, 150)
        crystal_gradient.setColorAt(0, QColor(200, 150, 255, 100))
        crystal_gradient.setColorAt(0.7, QColor(150, 100, 255, 150))
        crystal_gradient.setColorAt(1, QColor(100, 50, 200, 200))
        
        painter.setBrush(QBrush(crystal_gradient))
        painter.setPen(QPen(QColor(255, 200, 255, 150), 3))
        painter.drawPolygon(crystal_polygon)
        
        # Crystal facets
        painter.setPen(QPen(QColor(255, 255, 255, 80), 1))
        for i in range(len(crystal_points) - 1):
            painter.drawLine(crystal_points[i], QPointF(cx, cy - 20))
        
        # Crystal font
        font = QFont("Trebuchet MS", 68 if config['show_seconds'] else 80, QFont.Bold)
        painter.setFont(font)
        
        # Text metrics
        fm = painter.fontMetrics()
        text_rect = fm.boundingRect(time_text)
        x = cx - text_rect.width() // 2
        y = cy + text_rect.height() // 4
        
        # Crystal refraction effect
        for i in range(5, 0, -1):
            refract_color = QColor(config['clock_color'])
            refract_color.setAlpha(40 + int(20 * pulse_value))
            painter.setPen(QPen(refract_color, i))
            
            # Slight offset for refraction
            offset_x = math.sin(glow_intensity * 0.1) * 2
            offset_y = math.cos(glow_intensity * 0.1) * 2
            painter.drawText(x + offset_x, y + offset_y, time_text)
            
        # Main crystal text
        painter.setPen(QPen(QColor(255, 255, 255), 2))
        painter.drawText(x, y, time_text)
        
        # Sparkle effects
        for i in range(8):
            sparkle_x = cx + (80 + i * 15) * math.cos(glow_intensity * 0.05 + i)
            sparkle_y = cy + (80 + i * 15) * math.sin(glow_intensity * 0.05 + i)
            sparkle_color = QColor(255, 255, 255, int(100 + 100 * pulse_value))
            painter.setPen(QPen(sparkle_color, 2))
            painter.drawPoint(int(sparkle_x), int(sparkle_y))
    
    @staticmethod
    def draw_cyberpunk_clock(painter, config, width, height, glow_intensity, pulse_value):
        """Cyberpunk/Neon-tech style digital clock"""
        cx, cy = width // 2, height // 2
        
        current_time = QTime.currentTime()
        time_text = current_time.toString("HH:mm:ss" if config['show_seconds'] else "HH:mm")
        
        # Cyberpunk grid background
        grid_color = QColor(255, 0, 150, 30)
        painter.setPen(QPen(grid_color, 1))
        
        # Vertical lines
        for i in range(-200, 201, 40):
            painter.drawLine(cx + i, cy - 150, cx + i, cy + 150)
        
        # Horizontal lines
        for i in range(-150, 151, 30):
            painter.drawLine(cx - 200, cy + i, cx + 200, cy + i)
        
        # HUD frame
        frame_rect = QRect(cx - 220, cy - 80, 440, 160)
        
        # Frame corners
        corner_size = 20
        painter.setPen(QPen(QColor(0, 255, 255), 3))
        
        # Top-left corner
        painter.drawLine(frame_rect.left(), frame_rect.top() + corner_size,
                        frame_rect.left(), frame_rect.top())
        painter.drawLine(frame_rect.left(), frame_rect.top(),
                        frame_rect.left() + corner_size, frame_rect.top())
        
        # Top-right corner
        painter.drawLine(frame_rect.right() - corner_size, frame_rect.top(),
                        frame_rect.right(), frame_rect.top())
        painter.drawLine(frame_rect.right(), frame_rect.top(),
                        frame_rect.right(), frame_rect.top() + corner_size)
        
        # Bottom-left corner
        painter.drawLine(frame_rect.left(), frame_rect.bottom() - corner_size,
                        frame_rect.left(), frame_rect.bottom())
        painter.drawLine(frame_rect.left(), frame_rect.bottom(),
                        frame_rect.left() + corner_size, frame_rect.bottom())
        
        # Bottom-right corner
        painter.drawLine(frame_rect.right() - corner_size, frame_rect.bottom(),
                        frame_rect.right(), frame_rect.bottom())
        painter.drawLine(frame_rect.right(), frame_rect.bottom(),
                        frame_rect.right(), frame_rect.bottom() - corner_size)
        
        # Cyberpunk font
        font = QFont("Arial", 72 if config['show_seconds'] else 84, QFont.Bold)
        painter.setFont(font)
        
        # Text metrics
        fm = painter.fontMetrics()
        text_rect = fm.boundingRect(time_text)
        x = cx - text_rect.width() // 2
        y = cy + text_rect.height() // 4
        
        # Glitch effect
        glitch_offset = int(5 * pulse_value)
        if glow_intensity % 60 < 5:  # Random glitch
            # Red channel
            painter.setPen(QPen(QColor(255, 0, 0, 150), 2))
            painter.drawText(x - glitch_offset, y, time_text)
            
            # Blue channel
            painter.setPen(QPen(QColor(0, 0, 255, 150), 2))
            painter.drawText(x + glitch_offset, y, time_text)
        
        # Main cyberpunk glow
        for i in range(4, 0, -1):
            cyber_color = QColor(0, 255, 150)
            cyber_color.setAlpha(60 + int(40 * pulse_value))
            painter.setPen(QPen(cyber_color, i * 2))
            painter.drawText(x, y, time_text)
            
        # Core text
        painter.setPen(QPen(QColor(200, 255, 200), 2))
        painter.drawText(x, y, time_text)
        
        # Data stream effect
        stream_color = QColor(0, 255, 100, 100)
        painter.setPen(QPen(stream_color, 1))
        font_small = QFont("Consolas", 8)
        painter.setFont(font_small)
        
        for i in range(10):
            stream_x = cx - 180 + i * 36
            stream_y = cy - 120 + (glow_intensity + i * 20) % 240
            painter.drawText(stream_x, stream_y, "01")
    
    @staticmethod
    def draw_neon_tube_clock(painter, config, width, height, glow_intensity, pulse_value):
        """Neon tube/Sign style digital clock"""
        cx, cy = width // 2, height // 2
        
        current_time = QTime.currentTime()
        time_text = current_time.toString("HH:mm:ss" if config['show_seconds'] else "HH:mm")
        
        # Neon tube font
        font = QFont("Impact", 76 if config['show_seconds'] else 88, QFont.Bold)
        painter.setFont(font)
        
        # Text metrics
        fm = painter.fontMetrics()
        text_rect = fm.boundingRect(time_text)
        x = cx - text_rect.width() // 2
        y = cy + text_rect.height() // 4
        
        # Neon tube backing
        backing_rect = QRect(x - 40, y - text_rect.height() - 20, 
                           text_rect.width() + 80, text_rect.height() + 60)
        
        # Dark backing
        painter.setBrush(QBrush(QColor(20, 20, 20, 200)))
        painter.setPen(QPen(QColor(60, 60, 60), 2))
        painter.drawRoundedRect(backing_rect, 15, 15)
        
        # Neon supports (vertical lines)
        support_color = QColor(100, 100, 100)
        painter.setPen(QPen(support_color, 3))
        for i in range(4):
            support_x = x + i * text_rect.width() // 3
            painter.drawLine(support_x, backing_rect.top() + 10,
                           support_x, backing_rect.bottom() - 10)
        
        # Multiple neon glow layers
        neon_color = config['clock_color']
        
        # Outer glow
        for i in range(8, 0, -1):
            glow = QColor(neon_color)
            glow.setAlpha(int(15 + 10 * pulse_value))
            painter.setPen(QPen(glow, i * 2))
            painter.drawText(x, y, time_text)
        
        # Main neon tube
        painter.setPen(QPen(neon_color, 4))
        painter.drawText(x, y, time_text)
        
        # Inner bright core
        core_color = QColor(neon_color).lighter(150)
        painter.setPen(QPen(core_color, 2))
        painter.drawText(x, y, time_text)
        
        # Hot spot
        painter.setPen(QPen(Qt.white, 1))
        painter.drawText(x, y, time_text)
        
        # Electrical buzzing effect (random flicker)
        if glow_intensity % 47 < 3:  # Random flicker
            flicker_color = QColor(neon_color)
            flicker_color.setAlpha(int(200 * pulse_value))
            painter.setPen(QPen(flicker_color, 6))
            painter.drawText(x, y, time_text)
    
    @staticmethod
    def draw_liquid_metal_clock(painter, config, width, height, glow_intensity, pulse_value):
        """Liquid metal/Mercury style digital clock"""
        cx, cy = width // 2, height // 2
        
        current_time = QTime.currentTime()
        time_text = current_time.toString("HH:mm:ss" if config['show_seconds'] else "HH:mm")
        
        # Liquid metal font
        font = QFont("Arial Black", 74 if config['show_seconds'] else 86, QFont.Bold)
        painter.setFont(font)
        
        # Text metrics
        fm = painter.fontMetrics()
        text_rect = fm.boundingRect(time_text)
        x = cx - text_rect.width() // 2
        y = cy + text_rect.height() // 4
        
        # Liquid metal gradient
        metal_gradient = QLinearGradient(x, y - text_rect.height(), 
                                       x, y + 20)
        metal_gradient.setColorAt(0, QColor(220, 220, 255))
        metal_gradient.setColorAt(0.2, QColor(180, 180, 200))
        metal_gradient.setColorAt(0.5, QColor(120, 120, 140))
        metal_gradient.setColorAt(0.8, QColor(80, 80, 100))
        metal_gradient.setColorAt(1, QColor(60, 60, 80))
        
        # Liquid ripple effect
        ripple_offset = int(3 * math.sin(glow_intensity * 0.1) * pulse_value)
        
        # Shadow layers
        for i in range(5, 0, -1):
            shadow_color = QColor(0, 0, 0, 30)
            painter.setPen(QPen(shadow_color, i))
            painter.drawText(x + i, y + i, time_text)
        
        # Main liquid metal text
        painter.setPen(QPen(QBrush(metal_gradient), 3))
        painter.drawText(x + ripple_offset, y, time_text)
        
        # Liquid highlights
        highlight_gradient = QLinearGradient(x, y - text_rect.height(), 
                                           x, y - text_rect.height() + 30)
        highlight_gradient.setColorAt(0, QColor(255, 255, 255, 200))
        highlight_gradient.setColorAt(1, QColor(255, 255, 255, 0))
        
        painter.setPen(QPen(QBrush(highlight_gradient), 2))
        painter.drawText(x + ripple_offset, y - text_rect.height() + 15, time_text)
        
        # Surface tension drops
        for i in range(6):
            drop_x = x + i * text_rect.width() // 5 + int(5 * math.sin(glow_intensity * 0.05 + i))
            drop_y = y + 20 + int(10 * pulse_value)
            
            drop_color = QColor(150, 150, 170, int(100 + 50 * pulse_value))
            painter.setBrush(QBrush(drop_color))
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(drop_x - 3, drop_y, 6, 8)
    
    @staticmethod
    def draw_fire_clock(painter, config, width, height, glow_intensity, pulse_value):
        """Fire/Flame style digital clock"""
        cx, cy = width // 2, height // 2
        
        current_time = QTime.currentTime()
        time_text = current_time.toString("HH:mm:ss" if config['show_seconds'] else "HH:mm")
        
        # Fire font
        font = QFont("Impact", 78 if config['show_seconds'] else 90, QFont.Bold)
        painter.setFont(font)
        
        # Text metrics
        fm = painter.fontMetrics()
        text_rect = fm.boundingRect(time_text)
        x = cx - text_rect.width() // 2
        y = cy + text_rect.height() // 4
        
        # Flame particles
        for i in range(20):
            flame_x = x + (i * text_rect.width() // 19) + int(10 * math.sin(glow_intensity * 0.1 + i))
            flame_y = y + 30 - int(30 * random.random()) * pulse_value
            
            if i % 3 == 0:
                flame_color = QColor(255, 100, 0, int(150 * pulse_value))
            elif i % 3 == 1:
                flame_color = QColor(255, 200, 0, int(120 * pulse_value))
            else:
                flame_color = QColor(255, 50, 0, int(100 * pulse_value))
            
            painter.setBrush(QBrush(flame_color))
            painter.setPen(Qt.NoPen)
            flame_size = 4 + int(6 * pulse_value)
            painter.drawEllipse(flame_x - flame_size//2, flame_y - flame_size//2, 
                              flame_size, flame_size * 2)
        
        # Fire glow layers
        fire_colors = [
            QColor(255, 0, 0),    # Red core
            QColor(255, 100, 0),  # Orange
            QColor(255, 200, 0),  # Yellow
            QColor(255, 255, 100) # White hot
        ]
        
        # Multiple fire layers
        for i, fire_color in enumerate(fire_colors):
            fire_color.setAlpha(int(80 - i * 15 + 40 * pulse_value))
            painter.setPen(QPen(fire_color, (4 - i) * 2))
            
            # Flame flicker offset
            flicker_x = int(2 * math.sin(glow_intensity * 0.2 + i))
            flicker_y = int(1 * math.cos(glow_intensity * 0.3 + i))
            painter.drawText(x + flicker_x, y + flicker_y, time_text)
        
        # Hot center
        painter.setPen(QPen(Qt.white, 1))
        painter.drawText(x, y, time_text)
        
        # Embers floating up
        for i in range(8):
            ember_x = x + i * text_rect.width() // 7 + int(15 * math.sin(glow_intensity * 0.05 + i))
            ember_y = y - 50 - int(glow_intensity + i * 10) % 100
            
            ember_color = QColor(255, 150, 0, int(200 * pulse_value))
            painter.setBrush(QBrush(ember_color))
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(ember_x - 2, ember_y - 2, 4, 4)
    
    @staticmethod
    def draw_ice_clock(painter, config, width, height, glow_intensity, pulse_value):
        """Ice/Frost style digital clock"""
        cx, cy = width // 2, height // 2
        
        current_time = QTime.currentTime()
        time_text = current_time.toString("HH:mm:ss" if config['show_seconds'] else "HH:mm")
        
        # Ice font
        font = QFont("Arial", 76 if config['show_seconds'] else 88, QFont.Bold)
        painter.setFont(font)
        
        # Text metrics
        fm = painter.fontMetrics()
        text_rect = fm.boundingRect(time_text)
        x = cx - text_rect.width() // 2
        y = cy + text_rect.height() // 4
        
        # Frost crystals background
        for i in range(30):
            crystal_x = cx + (150 * math.cos(i * 0.4 + glow_intensity * 0.01))
            crystal_y = cy + (150 * math.sin(i * 0.4 + glow_intensity * 0.01))
            
            crystal_color = QColor(150, 200, 255, int(50 + 30 * pulse_value))
            painter.setPen(QPen(crystal_color, 1))
            
            # Draw crystal shape
            crystal_size = 8 + int(4 * pulse_value)
            painter.drawLine(int(crystal_x - crystal_size), int(crystal_y),
                           int(crystal_x + crystal_size), int(crystal_y))
            painter.drawLine(int(crystal_x), int(crystal_y - crystal_size),
                           int(crystal_x), int(crystal_y + crystal_size))
            painter.drawLine(int(crystal_x - crystal_size*0.7), int(crystal_y - crystal_size*0.7),
                           int(crystal_x + crystal_size*0.7), int(crystal_y + crystal_size*0.7))
            painter.drawLine(int(crystal_x - crystal_size*0.7), int(crystal_y + crystal_size*0.7),
                           int(crystal_x + crystal_size*0.7), int(crystal_y - crystal_size*0.7))
        
        # Ice gradient
        ice_gradient = QLinearGradient(x, y - text_rect.height(), x, y + 20)
        ice_gradient.setColorAt(0, QColor(200, 230, 255))
        ice_gradient.setColorAt(0.3, QColor(150, 200, 255))
        ice_gradient.setColorAt(0.7, QColor(100, 150, 255))
        ice_gradient.setColorAt(1, QColor(80, 120, 200))
        
        # Ice shadow
        painter.setPen(QPen(QColor(0, 50, 100, 150), 4))
        painter.drawText(x + 3, y + 3, time_text)
        
        # Main ice text
        painter.setPen(QPen(QBrush(ice_gradient), 3))
        painter.drawText(x, y, time_text)
        
        # Ice highlight
        painter.setPen(QPen(QColor(255, 255, 255, int(150 + 50 * pulse_value)), 1))
        painter.drawText(x - 1, y - 2, time_text)
        
        # Icicles
        icicle_color = QColor(180, 220, 255, int(100 + 50 * pulse_value))
        painter.setBrush(QBrush(icicle_color))
        painter.setPen(Qt.NoPen)
        
        for i in range(5):
            icicle_x = x + i * text_rect.width() // 4
            icicle_length = 15 + int(10 * pulse_value)
            
            # Icicle triangle
            icicle_points = [
                QPointF(icicle_x, y + 25),
                QPointF(icicle_x - 3, y + 15),
                QPointF(icicle_x + 3, y + 15)
            ]
            painter.drawPolygon(QPolygonF(icicle_points))
    
    @staticmethod
    def draw_typewriter_clock(painter, config, width, height, glow_intensity, pulse_value):
        """Vintage typewriter style digital clock"""
        cx, cy = width // 2, height // 2
        
        current_time = QTime.currentTime()
        time_text = current_time.toString("HH:mm:ss" if config['show_seconds'] else "HH:mm")
        
        # Typewriter paper background
        paper_rect = QRect(cx - 200, cy - 80, 400, 160)
        
        # Paper gradient (aged paper)
        paper_gradient = QLinearGradient(paper_rect.topLeft(), paper_rect.bottomRight())
        paper_gradient.setColorAt(0, QColor(245, 240, 220))
        paper_gradient.setColorAt(0.5, QColor(240, 235, 210))
        paper_gradient.setColorAt(1, QColor(235, 230, 200))
        
        painter.setBrush(QBrush(paper_gradient))
        painter.setPen(QPen(QColor(200, 180, 140), 2))
        painter.drawRect(paper_rect)
        
        # Paper lines
        painter.setPen(QPen(QColor(200, 200, 220, 100), 1))
        for i in range(4):
            line_y = paper_rect.top() + 30 + i * 25
            painter.drawLine(paper_rect.left() + 20, line_y, 
                           paper_rect.right() - 20, line_y)
        
        # Typewriter font
        font = QFont("Courier New", 64 if config['show_seconds'] else 76, QFont.Bold)
        painter.setFont(font)
        
        # Text metrics
        fm = painter.fontMetrics()
        text_rect = fm.boundingRect(time_text)
        x = cx - text_rect.width() // 2
        y = cy + text_rect.height() // 4
        
        # Ink smudges and imperfections
        for i, char in enumerate(time_text):
            char_x = x + i * (text_rect.width() // len(time_text))
            
            # Random ink variations
            ink_darkness = 180 + int(30 * math.sin(i + glow_intensity * 0.1))
            ink_color = QColor(ink_darkness, ink_darkness, ink_darkness)
            
            # Slight character offset (typewriter imperfection)
            offset_x = int(2 * math.sin(i + glow_intensity * 0.05))
            offset_y = int(1 * math.cos(i + glow_intensity * 0.05))
            
            painter.setPen(QPen(ink_color, 2))
            painter.drawText(char_x + offset_x, y + offset_y, char)
        
        # Typewriter ribbon wear effect
        if glow_intensity % 120 < 10:  # Occasional light strike
            light_color = QColor(100, 100, 100, 150)
            painter.setPen(QPen(light_color, 1))
            painter.drawText(x, y - 1, time_text)
    
    @staticmethod  
    def draw_galaxy_clock(painter, config, width, height, glow_intensity, pulse_value):
        """Galaxy/Space style digital clock"""
        cx, cy = width // 2, height // 2
        
        # Stars background
        star_color = QColor(255, 255, 255, int(150 + 100 * pulse_value))
        painter.setPen(QPen(star_color, 1))
        
        for i in range(50):
            star_x = cx + 200 * math.cos(i * 0.4 + glow_intensity * 0.01)
            star_y = cy + 200 * math.sin(i * 0.4 + glow_intensity * 0.01)
            star_size = 1 + int(2 * pulse_value)
            painter.drawEllipse(int(star_x - star_size), int(star_y - star_size), 
                              star_size * 2, star_size * 2)
        
        # Galaxy spiral
        for i in range(100):
            angle = i * 0.3 + glow_intensity * 0.02
            radius = i * 1.5
            spiral_x = cx + radius * math.cos(angle)
            spiral_y = cy + radius * math.sin(angle)
            
            galaxy_color = QColor(150, 0, 255, int(30 + 20 * pulse_value))
            painter.setPen(QPen(galaxy_color, 1))
            painter.drawPoint(int(spiral_x), int(spiral_y))
        
        current_time = QTime.currentTime()
        time_text = current_time.toString("HH:mm:ss" if config['show_seconds'] else "HH:mm")
        
        # Galaxy font
        font = QFont("Arial", 74 if config['show_seconds'] else 86, QFont.Bold)
        painter.setFont(font)
        
        # Text metrics
        fm = painter.fontMetrics()
        text_rect = fm.boundingRect(time_text)
        x = cx - text_rect.width() // 2
        y = cy + text_rect.height() // 4
        
        # Cosmic glow
        cosmic_colors = [
            QColor(100, 0, 255),   # Deep purple
            QColor(150, 0, 255),   # Purple
            QColor(200, 100, 255), # Light purple
            QColor(255, 200, 255)  # Pink
        ]
        
        for i, cosmic_color in enumerate(cosmic_colors):
            cosmic_color.setAlpha(int(60 - i * 10 + 30 * pulse_value))
            painter.setPen(QPen(cosmic_color, (4 - i) * 2))
            painter.drawText(x, y, time_text)
        
        # Stellar core
        painter.setPen(QPen(Qt.white, 1))
        painter.drawText(x, y, time_text)
        
        # Nebula effect
        nebula_gradient = QRadialGradient(cx, cy, 150)
        nebula_gradient.setColorAt(0, QColor(100, 0, 200, 20))
        nebula_gradient.setColorAt(0.5, QColor(50, 0, 150, 10))
        nebula_gradient.setColorAt(1, QColor(0, 0, 100, 5))
        
        painter.setBrush(QBrush(nebula_gradient))
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(cx - 150, cy - 150, 300, 300)
    
    @staticmethod
    def draw_matrix_rain(painter, width, height, rotation_angle):
        """Enhanced matrix rain effect"""
        matrix_color = QColor(0, 255, 0, 30)
        painter.setPen(QPen(matrix_color, 1))
        font = QFont("Consolas", 10)
        painter.setFont(font)
        
        # Characters for matrix rain
        chars = "0123456789ABCDEF"
        
        # Vertical streams
        for i in range(25):
            x = (i * 32 + int(rotation_angle * 2)) % width
            
            # Multiple characters in each stream
            for j in range(8):
                y = (j * 40 + int(rotation_angle * 8 + i * 50)) % height
                char_index = int(rotation_angle + i + j) % len(chars)
                
                # Fade effect - brighter at top
                alpha = max(10, 50 - j * 6)
                char_color = QColor(0, 255, 0, alpha)
                painter.setPen(QPen(char_color, 1))
                painter.drawText(x, y, chars[char_index])
