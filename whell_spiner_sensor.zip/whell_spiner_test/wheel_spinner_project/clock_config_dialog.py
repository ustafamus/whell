import os
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QPushButton, QDialog, QButtonGroup, QRadioButton,
                             QColorDialog, QMessageBox, QFrame, QScrollArea, 
                             QStyle, QComboBox)
from PyQt5.QtCore import Qt, pyqtSignal, QPropertyAnimation, QEasingCurve
from PyQt5.QtGui import QColor, QPainter, QBrush, QPen
from .image_manager import ImageManager  # Import our modular image manager


class SimpleClockConfigDialog(QDialog):
    """Enhanced clock configuration dialog with menu widget style"""
    
    clock_configured = pyqtSignal(dict)
    
    def __init__(self, parent=None, current_config=None, wheel_outer_radius=200):
        super().__init__(parent)
        self.setWindowTitle("Clock Settings")
        
        # Set size same as menu widget
        dialog_size = int(wheel_outer_radius * 2 + 20)
        self.setFixedSize(dialog_size, dialog_size)
        self.setModal(True)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setWindowFlags(Qt.FramelessWindowHint)
        
        # Dialog properties
        self.is_visible = False
        self.animation = None
        self.dialog_radius = wheel_outer_radius
        
        # Default values
        self.clock_type = "Analog"
        self.background_type = "Color"
        self.background_color = QColor(20, 20, 30)
        self.background_image = None
        self.clock_color = QColor(0, 255, 255)
        self.digital_style = "neon"
        self.analog_style = "modern"
        self.date_format = "dd.MM.yyyy"
        self.show_date = True  # New field for show/hide date
        self.image_folder = os.path.join(os.path.dirname(__file__), "images")
        
        # Load current config if provided
        if current_config:
            self.load_current_config(current_config)
        
        self.setup_ui()
        self.setup_animation()
        
        # CRITICAL: Apply settings AFTER UI is set up and ONLY if config was loaded
        if hasattr(self, '_config_loaded') and self._config_loaded:
            print("DEBUG: Config was loaded, applying current settings")
            self.apply_current_settings()
        else:
            print("DEBUG: No config loaded, using defaults")
    
    def setup_ui(self):
        # Menu widget style with white background and black text
        self.setStyleSheet("""
            QWidget { background: transparent; }
            QLabel {
                color: black;
                font-size: 12px;
                font-weight: bold;
                background: transparent;
                border: none;
                padding: 0px;
                margin: 0px;
            }
            QLabel#titleLabel {
                color: black;
                font-size: 16px;
                font-weight: bold;
                margin-bottom: 10px;
            }
            QComboBox {
                background-color: #f5f5f5;
                border: 1px solid #ccc;
                border-radius: 6px;
                padding: 4px 8px;
                font-size: 11px;
                min-height: 20px;
                max-height: 24px;
                font-weight: bold;
                color: black;
            }
            QComboBox:hover {
                background-color: #e8e8e8;
                border-color: #007bff;
            }
            QLabel.textBox {
                background-color: #f5f5f5;
                border: 1px solid #ccc;
                border-radius: 6px;
                padding: 4px 8px;
                font-size: 11px;
                min-height: 20px;
                max-height: 24px;
                color: black;
                font-weight: bold;
            }
            QLabel.textBox:hover {
                background-color: #e8e8e8;
                border-color: #007bff;
            }
            QPushButton {
                background-color: #d32f2f;
                color: white;
                border: none;
                border-radius: 8px;
                padding: 8px 20px;
                font-size: 14px;
                font-weight: bold;
                min-width: 80px;
                min-height: 32px;
            }
            QPushButton:hover {
                background-color: #b71c1c;
            }
            QRadioButton {
                color: black;
                font-size: 12px;
                font-weight: bold;
                background: transparent;
                spacing: 5px;
                margin: 2px 0px;
            }
            QRadioButton::indicator {
                width: 15px;
                height: 15px;
                border-radius: 8px;
                border: 2px solid #666;
                background-color: white;
            }
            QRadioButton::indicator:checked {
                background-color: #007bff;
                border-color: #007bff;
            }
            QRadioButton::indicator:hover {
                border-color: #007bff;
            }
        """)
        
        # Calculate margin same as menu widget
        margin = int(self.dialog_radius * 2 * 0.18)
        
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(margin, margin, margin, margin)
        main_layout.setSpacing(8)

        # Title
        title_label = QLabel("Clock Configuration")
        title_label.setObjectName("titleLabel")
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)

        # SECTION 1 & 2: Clock Type and Style Selection (Side by Side)
        clock_and_style_layout = QHBoxLayout()
        clock_and_style_layout.setSpacing(20)
        
        # Left side - Clock Type
        clock_type_container = QWidget()
        clock_type_layout = QVBoxLayout(clock_type_container)
        clock_type_layout.setContentsMargins(0, 0, 0, 0)
        clock_type_layout.setSpacing(5)
        
        type_header = QLabel("Clock Type")
        clock_type_layout.addWidget(type_header)
        
        type_radio_layout = QHBoxLayout()
        type_radio_layout.setSpacing(20)
        
        self.digital_radio = QRadioButton("Digital Clock")
        self.analog_radio = QRadioButton("Analog Clock")
        
        self.clock_type_group = QButtonGroup()
        self.clock_type_group.addButton(self.digital_radio)
        self.clock_type_group.addButton(self.analog_radio)
        
        type_radio_layout.addWidget(self.digital_radio)
        type_radio_layout.addWidget(self.analog_radio)
        type_radio_layout.addStretch()
        
        clock_type_layout.addLayout(type_radio_layout)
        
        # Right side - Style Selection  
        style_container = QWidget()
        style_layout = QVBoxLayout(style_container)
        style_layout.setContentsMargins(0, 0, 0, 0)
        style_layout.setSpacing(5)
        
        style_header = QLabel("Style Selection")
        style_layout.addWidget(style_header)
        
        style_content_layout = QHBoxLayout()
        style_content_layout.setSpacing(8)
        
        style_label = QLabel("Style:")
        self.style_combo = QComboBox()
        # Will be populated in update_clock_type
        self.style_combo.setFixedWidth(120)
        
        style_content_layout.addWidget(style_label)
        style_content_layout.addWidget(self.style_combo)
        style_content_layout.addStretch()
        
        style_layout.addLayout(style_content_layout)
        
        # Add containers to horizontal layout
        clock_and_style_layout.addWidget(clock_type_container)
        clock_and_style_layout.addWidget(style_container)
        clock_and_style_layout.addStretch()
        
        main_layout.addLayout(clock_and_style_layout)

        # SECTION 3: Background
        bg_header = QLabel("Background")
        main_layout.addWidget(bg_header)
        
        bg_type_layout = QHBoxLayout()
        bg_type_layout.setSpacing(20)
        
        self.color_radio = QRadioButton("Solid Color")
        self.image_radio = QRadioButton("Image")
        self.color_radio.setChecked(True)
        
        self.bg_group = QButtonGroup()
        self.bg_group.addButton(self.color_radio)
        self.bg_group.addButton(self.image_radio)
        
        bg_type_layout.addWidget(self.color_radio)
        bg_type_layout.addWidget(self.image_radio)
        bg_type_layout.addStretch()
        
        main_layout.addLayout(bg_type_layout)

        # SECTION 4: Colors
        colors_header = QLabel("Colors")
        main_layout.addWidget(colors_header)
        
        # Background Color
        bg_color_layout = QHBoxLayout()
        bg_color_layout.setSpacing(8)
        self.bg_text_box = QLabel("Background Color")
        self.bg_text_box.setProperty("class", "textBox")
        self.bg_text_box.setCursor(Qt.PointingHandCursor)
        self.bg_text_box.mousePressEvent = self.select_background
        bg_color_layout.addWidget(self.bg_text_box, 1)
        main_layout.addLayout(bg_color_layout)
        
        # Clock Color
        clock_color_layout = QHBoxLayout()
        clock_color_layout.setSpacing(8)
        self.clock_text_box = QLabel("Clock Color")
        self.clock_text_box.setProperty("class", "textBox")
        self.clock_text_box.setCursor(Qt.PointingHandCursor)
        self.clock_text_box.mousePressEvent = self.select_clock_color
        clock_color_layout.addWidget(self.clock_text_box, 1)
        main_layout.addLayout(clock_color_layout)

        # SECTION 5: Date Display and Format (Side by Side)
        date_section_layout = QHBoxLayout()
        date_section_layout.setSpacing(20)
        
        # Left side - Date Display
        date_display_container = QWidget()
        date_display_layout = QVBoxLayout(date_display_container)
        date_display_layout.setContentsMargins(0, 0, 0, 0)
        date_display_layout.setSpacing(5)
        
        date_header = QLabel("Date Display")
        date_display_layout.addWidget(date_header)
        
        # Show/Hide Date options
        date_show_layout = QHBoxLayout()
        date_show_layout.setSpacing(20)
        
        self.show_date_radio = QRadioButton("Show Date")
        self.hide_date_radio = QRadioButton("Hide Date")
        self.show_date_radio.setChecked(True)  # Default to show
        
        self.date_group = QButtonGroup()
        self.date_group.addButton(self.show_date_radio)
        self.date_group.addButton(self.hide_date_radio)
        
        date_show_layout.addWidget(self.show_date_radio)
        date_show_layout.addWidget(self.hide_date_radio)
        date_show_layout.addStretch()
        
        date_display_layout.addLayout(date_show_layout)
        
        # Right side - Date Format (shown only when Show Date is selected)
        self.date_format_container = QWidget()
        date_format_layout = QVBoxLayout(self.date_format_container)
        date_format_layout.setContentsMargins(0, 0, 0, 0)
        date_format_layout.setSpacing(5)
        
        format_header = QLabel("Date Format")
        date_format_layout.addWidget(format_header)
        
        format_content_layout = QHBoxLayout()
        format_content_layout.setSpacing(8)
        
        date_label = QLabel("Format:")
        self.date_format_combo = QComboBox()
        self.date_format_combo.addItems([
            "dd.MM.yyyy",
            "MM/dd/yyyy", 
            "yyyy-MM-dd",
            "dd/MM/yyyy",
            "MMMM dd, yyyy",
            "dd MMMM yyyy",
            "ddd, MMM dd"
        ])
        self.date_format_combo.setFixedWidth(120)
        
        format_content_layout.addWidget(date_label)
        format_content_layout.addWidget(self.date_format_combo)
        format_content_layout.addStretch()
        
        date_format_layout.addLayout(format_content_layout)
        
        # Add containers to horizontal layout
        date_section_layout.addWidget(date_display_container)
        date_section_layout.addWidget(self.date_format_container)
        date_section_layout.addStretch()
        
        main_layout.addLayout(date_section_layout)

        # Buttons
        main_layout.addSpacing(15)
        button_layout = QHBoxLayout()
        button_layout.setContentsMargins(0, 0, 0, 0)
        
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.reject_config)
        
        self.ok_btn = QPushButton("Apply")
        self.ok_btn.clicked.connect(self.accept_config)
        
        button_layout.addWidget(self.cancel_btn)
        button_layout.addStretch()
        button_layout.addWidget(self.ok_btn)
        
        main_layout.addLayout(button_layout)

        # Signals
        self.color_radio.toggled.connect(self.update_labels)
        self.image_radio.toggled.connect(self.update_labels)
        self.digital_radio.toggled.connect(self.update_clock_type)
        self.analog_radio.toggled.connect(self.update_clock_type)
        self.show_date_radio.toggled.connect(self.update_date_visibility)
        self.hide_date_radio.toggled.connect(self.update_date_visibility)
        
        # Initial update
        self.update_labels()
        self.update_button_colors()
        self.update_clock_type()
        self.update_date_visibility()
        self.apply_current_settings()
        
    def setup_animation(self):
        self.animation = QPropertyAnimation(self, b"windowOpacity")
        self.animation.setDuration(300)
        self.animation.setEasingCurve(QEasingCurve.InOutQuad)
        
    def show_dialog(self):
        """Show dialog with animation"""
        if not self.is_visible:
            self.is_visible = True
            self.show()
            self.animation.setStartValue(0.0)
            self.animation.setEndValue(1.0)
            self.animation.start()
            
    def hide_dialog(self):
        """Hide dialog with animation"""
        if self.is_visible:
            self.is_visible = False
            self.animation.setStartValue(1.0)
            self.animation.setEndValue(0.0)
            self.animation.finished.connect(self._animation_finished_hide)
            self.animation.start()
            
    def _animation_finished_hide(self):
        self.hide()
        self.animation.finished.disconnect(self._animation_finished_hide)
        
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        center = self.rect().center()
        radius = self.dialog_radius
        
        # White Background Circle (instead of gray transparent)
        painter.setBrush(QBrush(QColor(255, 255, 255, 255)))  # Solid white
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(center.x() - radius, center.y() - radius, 
                          radius * 2, radius * 2)
        
        # Outer Frame
        painter.setBrush(QBrush(QColor(0, 0, 0, 0)))
        painter.setPen(QPen(QColor(200, 200, 200, 150), 2))  # Light gray border
        painter.drawEllipse(center.x() - radius, center.y() - radius, 
                          radius * 2, radius * 2)
        
        # Inner Frame
        painter.setPen(QPen(QColor(0, 123, 255, 100), 1))
        painter.drawEllipse(center.x() - radius + 3, center.y() - radius + 3, 
                          (radius - 3) * 2, (radius - 3) * 2)
        
        super().paintEvent(event)
        
    def load_current_config(self, config):
        """Load current configuration values"""
        if config:  # Only load if config is not empty
            self.clock_type = config.get('clock_type', 'Analog')
            self.background_type = config.get('background_type', 'Color')
            self.background_color = config.get('background_color', QColor(20, 20, 30))
            self.background_image = config.get('background_image', None)
            self.clock_color = config.get('clock_color', QColor(0, 255, 255))
            self.digital_style = config.get('digital_style', 'neon')
            self.analog_style = config.get('analog_style', 'modern')
            self.date_format = config.get('date_format', 'dd.MM.yyyy')
            self.show_date = config.get('show_date', True)  # Load show_date setting
            self._config_loaded = True  # Flag to indicate config was loaded
            print(f"DEBUG: Loaded config - Type: {self.clock_type}, Style: {self.analog_style if self.clock_type == 'Analog' else self.digital_style}, Show Date: {self.show_date}")
    
    def apply_current_settings(self):
        """Apply loaded settings to UI elements"""
        print(f"DEBUG: apply_current_settings called - Type: {self.clock_type}")
        
        # FORCE set the radio buttons using blockSignals
        self.digital_radio.blockSignals(True)
        self.analog_radio.blockSignals(True)
        
        # Clear both first
        self.digital_radio.setChecked(False)
        self.analog_radio.setChecked(False)
        
        # Now set the correct one
        if self.clock_type == "Digital":
            self.digital_radio.setChecked(True)
            print("DEBUG: FORCED Digital radio to True")
        else:
            self.analog_radio.setChecked(True)
            print("DEBUG: FORCED Analog radio to True")
        
        # Re-enable signals
        self.digital_radio.blockSignals(False)
        self.analog_radio.blockSignals(False)
        
        # Set background type
        if self.background_type == "Color":
            self.color_radio.setChecked(True)
            self.image_radio.setChecked(False)
        else:
            self.image_radio.setChecked(True)
            self.color_radio.setChecked(False)
        
        # Set date format
        date_formats = [
            "dd.MM.yyyy",
            "MM/dd/yyyy", 
            "yyyy-MM-dd",
            "dd/MM/yyyy",
            "MMMM dd, yyyy",
            "dd MMMM yyyy",
            "ddd, MMM dd"
        ]
        if self.date_format in date_formats:
            self.date_format_combo.setCurrentIndex(date_formats.index(self.date_format))
        
        # Set show/hide date
        if self.show_date:
            self.show_date_radio.setChecked(True)
            self.hide_date_radio.setChecked(False)
        else:
            self.hide_date_radio.setChecked(True)
            self.show_date_radio.setChecked(False)
        
        # Update background image label if needed
        if self.background_type == "Image" and self.background_image:
            filename = os.path.basename(self.background_image)
            self.bg_text_box.setText(f"Image: {filename}")
            self.bg_text_box.setToolTip(f"Image: {filename}")
        
        # Force update clock type (this will set the correct style dropdown)
        self.update_clock_type()
        
        # Then update other UI elements
        self.update_labels()
        self.update_button_colors()
        self.update_date_visibility()  # Update date visibility based on loaded config
        
        print(f"DEBUG: FINAL CHECK - Digital checked: {self.digital_radio.isChecked()}, Analog checked: {self.analog_radio.isChecked()}")
        print(f"DEBUG: Final clock type: {self.clock_type}")
        
        # EXTRA: Force repaint to make sure UI updates
        self.digital_radio.update()
        self.analog_radio.update()
        
    def update_clock_type(self):
        """Update interface based on clock type selection"""
        is_digital = self.digital_radio.isChecked()
        self.clock_type = "Digital" if is_digital else "Analog"
        
        print(f"DEBUG: update_clock_type called - is_digital: {is_digital}, clock_type: {self.clock_type}")
        
        # Update style combo items based on clock type
        self.style_combo.clear()
        if is_digital:
            # Digital styles (15 total)
            self.style_combo.addItems([
                "Neon", "LCD", "Matrix", "Minimalist", "Retro",
                "Holographic", "Plasma", "Crystal", "Cyberpunk", 
                "Neon Tube", "Liquid Metal", "Fire", "Ice", 
                "Typewriter", "Galaxy"
            ])
            # Updated digital styles mapping
            digital_styles = {
                "neon": 0, "lcd": 1, "matrix": 2, "minimalist": 3, "retro": 4,
                "holographic": 5, "plasma": 6, "crystal": 7, "cyberpunk": 8,
                "neon_tube": 9, "liquid_metal": 10, "fire": 11, "ice": 12,
                "typewriter": 13, "galaxy": 14
            }
            index = digital_styles.get(self.digital_style, 0)
            self.style_combo.setCurrentIndex(index)
            print(f"DEBUG: Set digital style to index {index} ({self.digital_style})")
        else:
            # Updated analog styles - now 10 styles
            self.style_combo.addItems([
                "Modern", "Classic", "Elegant", "Industrial", "Neon",
                "Luxury", "Minimalist", "Retro", "Art Deco", "Steampunk"
            ])
            # Updated analog styles mapping - for all 10 styles
            analog_styles = {
                "modern": 0, "classic": 1, "elegant": 2, "industrial": 3, "neon": 4,
                "luxury": 5, "minimalist": 6, "retro": 7, "art_deco": 8, "steampunk": 9
            }
            index = analog_styles.get(self.analog_style, 0)
            self.style_combo.setCurrentIndex(index)
            print(f"DEBUG: Set analog style to index {index} ({self.analog_style})")
        
    def update_labels(self):
        self.background_type = "Color" if self.color_radio.isChecked() else "Image"
        
        if self.background_type == "Color":
            self.bg_text_box.setText("Background Color")
        else:
            self.bg_text_box.setText("Background Image")
    
    def update_date_visibility(self):
        """Show/hide date format combo based on show date selection"""
        show_date = self.show_date_radio.isChecked()
        self.date_format_container.setVisible(show_date)
        self.show_date = show_date
            
    def update_button_colors(self):
        """Update color buttons with current colors"""
        bg_color_text = f"Background: {self.background_color.name()}"
        self.bg_text_box.setToolTip(bg_color_text)
        
        clock_color_text = f"Clock: {self.clock_color.name()}"
        self.clock_text_box.setToolTip(clock_color_text)
            
    def get_selected_style(self):
        """Get selected style based on clock type"""
        if self.clock_type == "Digital":
            style_map = {
                0: "neon", 1: "lcd", 2: "matrix", 3: "minimalist", 4: "retro",
                5: "holographic", 6: "plasma", 7: "crystal", 8: "cyberpunk",
                9: "neon_tube", 10: "liquid_metal", 11: "fire", 12: "ice",
                13: "typewriter", 14: "galaxy"
            }
            return style_map.get(self.style_combo.currentIndex(), "neon")
        else:
            # Updated style map for all 10 analog styles
            style_map = {
                0: "modern", 1: "classic", 2: "elegant", 3: "industrial", 4: "neon",
                5: "luxury", 6: "minimalist", 7: "retro", 8: "art_deco", 9: "steampunk"
            }
            return style_map.get(self.style_combo.currentIndex(), "modern")
    
    def get_selected_date_format(self):
        """Get selected date format"""
        formats = [
            "dd.MM.yyyy",
            "MM/dd/yyyy", 
            "yyyy-MM-dd",
            "dd/MM/yyyy",
            "MMMM dd, yyyy",
            "dd MMMM yyyy",
            "ddd, MMM dd"
        ]
        return formats[self.date_format_combo.currentIndex()]
    
    def select_background(self, event):
        """Use modular ImageManager for background selection"""
        if self.background_type == "Color":
            # Mavi arka planlı renk dialogu
            dialog = QColorDialog(self.background_color, self)
            dialog.setStyleSheet("""
                QColorDialog {
                    background-color: rgba(128, 128, 128, 180);
                }
            """)
            if dialog.exec_() == QColorDialog.Accepted:
                color = dialog.selectedColor()
                if color.isValid():
                    self.background_color = color
                    self.update_button_colors()
        else:
            try:
                selected_file = ImageManager.show_image_selection_dialog(
                    parent=self,
                    image_folder=self.image_folder,
                    title="Select Background Image",
                    enable_add=True
                )
                
                if selected_file:
                    self.background_image = selected_file
                    filename = os.path.basename(selected_file)
                    self.bg_text_box.setText(f"Image: {filename}")
                    self.bg_text_box.setToolTip(f"Image: {filename}")
                    
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to select background image: {str(e)}")

    def select_clock_color(self, event):
        # Mavi arka planlı renk dialogu
        dialog = QColorDialog(self.clock_color, self)
        dialog.setStyleSheet("""
            QColorDialog {
                background-color: rgba(128, 128, 128, 180);
            }
        """)
        if dialog.exec_() == QColorDialog.Accepted:
            color = dialog.selectedColor()
            if color.isValid():
                self.clock_color = color
                self.update_button_colors()
    
    def reject_config(self):
        """Cancel dialog"""
        self.hide_dialog()
        self.reject()
    
    def accept_config(self):
        selected_style = self.get_selected_style()
        
        config = {
            'clock_type': self.clock_type,
            'digital_style': selected_style if self.clock_type == 'Digital' else self.digital_style,
            'analog_style': selected_style if self.clock_type == 'Analog' else self.analog_style,
            'background_type': self.background_type,
            'background_color': self.background_color,
            'background_image': self.background_image,
            'clock_color': self.clock_color,
            'date_format': self.get_selected_date_format(),
            'show_date': self.show_date,  # Include show_date setting
            # Default values for backward compatibility
            'show_seconds': True,
            'animation_enabled': True,
            'show_numbers': True
        }
        self.clock_configured.emit(config)
        self.hide_dialog()
        self.accept()