"""
Mock IKS9 Encoder - Ubuntu'da test için
Gerçek GPIO olmadan simülasyon yapar
"""

import time
import threading
import math
from typing import Optional, Callable

class MockIKS9Encoder:
    def __init__(self, pin_a: int = 18, pin_b: int = 19, pin_z: int = 2, resolution_um: float = 5.0):
        """Mock IKS9 Encoder - Ubuntu test için"""
        self.pin_a = pin_a
        self.pin_b = pin_b
        self.pin_z = pin_z
        self.resolution_um = resolution_um
        
        # Mock değişkenler
        self._position = 0
        self._direction = True
        self._z_pulse_detected = False
        self._error_state = False
        
        # Konfigürasyon
        self.invert_direction = False
        self.z_pulse_enabled = True
        
        # Hız hesaplama
        self._last_position = 0
        self._last_time = time.time()
        self._current_speed = 0.0
        
        # Mock rotasyon simülasyonu
        self._mock_angle = 0.0
        self._mock_running = False
        self._mock_thread = None
        
        # Thread güvenliği
        self._lock = threading.Lock()
        
        # Callback
        self.position_callback: Optional[Callable[[int, float], None]] = None
        
        # Mock durum
        self._initialized = False
        
        print("Mock IKS9 Encoder oluşturuldu - Ubuntu test modu")

    def begin(self) -> bool:
        """Mock encoder başlat"""
        try:
            print(f"Mock IKS9 Encoder başlatılıyor...")
            print(f"  Mock A pin: {self.pin_a}")
            print(f"  Mock B pin: {self.pin_b}")
            print(f"  Mock Z pin: {self.pin_z}")
            
            # Mock otomatik döndürmeyi başlat
            self._start_mock_rotation()
            
            self._initialized = True
            print("Mock encoder başarıyla başlatıldı")
            print("Otomatik döndürme simülasyonu aktif")
            
            return True
            
        except Exception as e:
            print(f"Mock encoder başlatma hatası: {e}")
            return False

    def _start_mock_rotation(self):
        """Mock otomatik döndürme başlat"""
        self._mock_running = True
        self._mock_thread = threading.Thread(target=self._mock_rotation_loop)
        self._mock_thread.daemon = True
        self._mock_thread.start()

    def _mock_rotation_loop(self):
        """Mock döndürme döngüsü"""
        start_time = time.time()
        
        while self._mock_running:
            current_time = time.time()
            elapsed = current_time - start_time
            
            # Sinüsoidal döndürme simülasyonu (yavaş ve düzgün)
            rotation_speed = 0.5  # radyan/saniye
            self._mock_angle = (elapsed * rotation_speed) % (2 * math.pi)
            
            # Açıyı dereceye çevir
            angle_degrees = math.degrees(self._mock_angle)
            
            # Pozisyon hesapla
            pulses_per_revolution = 3600
            new_position = int((angle_degrees / 360.0) * pulses_per_revolution)
            
            with self._lock:
                old_position = self._position
                self._position = new_position
                
                # Callback çağır (pozisyon değişirse)
                if abs(new_position - old_position) > 0 and self.position_callback:
                    self.position_callback(self._position, angle_degrees)
            
            time.sleep(0.05)  # 20Hz güncelleme

    def cleanup(self):
        """Mock temizlik"""
        if self._mock_running:
            self._mock_running = False
            if self._mock_thread:
                self._mock_thread.join(timeout=1.0)
        
        self._initialized = False
        print("Mock IKS9 Encoder temizlendi")

    def get_position(self) -> int:
        """Mock pozisyon"""
        with self._lock:
            return self._position

    def get_position_mm(self) -> float:
        """Mock pozisyon mm"""
        with self._lock:
            return (self._position * self.resolution_um) / 1000.0

    def get_position_um(self) -> float:
        """Mock pozisyon μm"""
        with self._lock:
            return self._position * self.resolution_um

    def get_angle_degrees(self) -> float:
        """Mock açı derece"""
        with self._lock:
            pulses_per_revolution = 3600
            angle = (self._position % pulses_per_revolution) * (360.0 / pulses_per_revolution)
            return angle

    def reset_position(self):
        """Mock pozisyon sıfırla"""
        with self._lock:
            self._position = 0
            self._last_position = 0

    def get_direction(self) -> bool:
        """Mock yön"""
        return True  # Her zaman pozitif yön

    def update_speed(self):
        """Mock hız güncellemesi"""
        current_time = time.time()
        
        with self._lock:
            current_pos = self._position
            
            if current_time - self._last_time >= 0.05:
                delta_position = current_pos - self._last_position
                delta_time = current_time - self._last_time
                
                self._current_speed = (delta_position * self.resolution_um * 0.001) / delta_time
                
                self._last_position = current_pos
                self._last_time = current_time

    def get_speed(self) -> float:
        """Mock hız"""
        with self._lock:
            return self._current_speed

    def get_z_pulse_status(self) -> bool:
        """Mock Z pulse"""
        # Her tam tur sonunda Z pulse simüle et
        angle = self.get_angle_degrees()
        return abs(angle) < 5.0  # 0° civarında Z pulse

    def clear_z_pulse(self):
        """Mock Z pulse temizle"""
        pass

    def set_position_callback(self, callback: Callable[[int, float], None]):
        """Callback ayarla"""
        self.position_callback = callback

    def set_resolution(self, resolution_um: float):
        """Çözünürlük ayarla"""
        self.resolution_um = resolution_um

    def set_invert_direction(self, invert: bool):
        """Yön inversiyonu"""
        self.invert_direction = invert