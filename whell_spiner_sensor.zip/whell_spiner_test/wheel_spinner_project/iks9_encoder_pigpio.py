import pigpio, time

class IKS9Encoder:
    """Quadrature (A/B) + optional index Z encoder reader for Raspberry Pi (pigpio)."""
    _TRANSITIONS = [0,-1,+1,0, +1,0,0,-1, -1,0,0,+1, 0,+1,-1,0]

    def __init__(self, pi, pin_a, pin_b, pin_z=None, cpr=2048, invert=False):
        self.pi = pi
        self.pin_a, self.pin_b, self.pin_z = pin_a, pin_b, pin_z
        self.cpr = int(cpr)
        self.invert = -1 if invert else +1

        for p in (pin_a, pin_b):
            self.pi.set_mode(p, pigpio.INPUT)
            self.pi.set_pull_up_down(p, pigpio.PUD_UP)

        self._last_ab = ((self.pi.read(pin_a) << 1) | self.pi.read(pin_b)) & 0x3
        self.count = 0
        self._cb_a = self.pi.callback(pin_a, pigpio.EITHER_EDGE, self._cb_ab)
        self._cb_b = self.pi.callback(pin_b, pigpio.EITHER_EDGE, self._cb_ab)

        self._cb_z = None
        self._last_index_count = None
        self.measured_cpr = None
        if pin_z is not None:
            self.pi.set_mode(pin_z, pigpio.INPUT)
            self.pi.set_pull_up_down(pin_z, pigpio.PUD_UP)
            self._cb_z = self.pi.callback(pin_z, pigpio.RISING_EDGE, self._cb_z)

    def _cb_ab(self, gpio, level, tick):
        a = self.pi.read(self.pin_a)
        b = self.pi.read(self.pin_b)
        ab = ((a << 1) | b) & 0x3
        idx = ((self._last_ab << 2) | ab) & 0xF
        self.count += self._TRANSITIONS[idx] * self.invert
        self._last_ab = ab

    def _cb_z(self, gpio, level, tick):
        if self._last_index_count is not None:
            delta = self.count - self._last_index_count
            if abs(delta) > 0:
                self.measured_cpr = abs(delta)
        self._last_index_count = self.count
        if self.cpr > 0:
            self.count %= self.cpr

    @property
    def angle_deg(self) -> float:
        cpr = self.measured_cpr or self.cpr or 1
        return ((self.count % cpr) * 360.0) / float(cpr)

    def zero_here(self):
        self.count = 0

    def close(self):
        if self._cb_a: self._cb_a.cancel()
        if self._cb_b: self._cb_b.cancel()
        if self._cb_z: self._cb_z.cancel()
