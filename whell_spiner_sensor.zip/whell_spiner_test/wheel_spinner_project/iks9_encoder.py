"""
BOGEN IKS9 Encoder - Hibrit Versiyon
Ubuntu'da mock, Raspberry Pi'de gerçek GPIO kullanır
"""

import platform
import time
import threading
import math
from typing import Optional, Callable

# Platform kontrolü
IS_RASPBERRY_PI = False
try:
    # Raspberry Pi kontrolü
    with open('/proc/cpuinfo', 'r') as f:
        cpuinfo = f.read()
    IS_RASPBERRY_PI = 'Raspberry Pi' in cpuinfo or 'BCM' in cpuinfo
except:
    IS_RASPBERRY_PI = False

# GPIO import - Raspberry Pi'de gerçek, diğerlerinde None
if IS_RASPBERRY_PI:
    try:
        import RPi.GPIO as GPIO
        print("Raspberry Pi GPIO detected - Real sensor mode")
    except ImportError:
        IS_RASPBERRY_PI = False
        print("RPi.GPIO not found - Using mock mode")
        GPIO = None
else:
    GPIO = None
    print("Not on Raspberry Pi - Using mock mode")


class IKS9Encoder:
    def __init__(self, pin_a: int = 18, pin_b: int = 19, pin_z: int = 2, resolution_um: float = 5.0):
        """
        IKS9 Encoder - Otomatik platform algılama
        Raspberry Pi'de gerçek GPIO, Ubuntu'da mock simülasyon
        """
        self.pin_a = pin_a
        self.pin_b = pin_b
        self.pin_z = pin_z
        self.resolution_um = resolution_um
        self.is_raspberry_pi = IS_RASPBERRY_PI
        
        # Ortak değişkenler
        self._position = 0
        self._direction = True
        self._z_pulse_detected = False
        self._error_state = False
        
        # Konfigürasyon
        self.invert_direction = False
        self.z_pulse_enabled = True
        
        # Hız hesaplama
        self._last_position = 0
        self._last_time = time.time()
        self._current_speed = 0.0
        
        # Thread güvenliği
        self._lock = threading.Lock()
        
        # Callback
        self.position_callback: Optional[Callable[[int, float], None]] = None
        
        # Platform-specific değişkenler
        if self.is_raspberry_pi:
            # Raspberry Pi - Gerçek GPIO
            self._last_state = 0
            self._initialized = False
            print("IKS9 Encoder - Raspberry Pi modu (Gerçek GPIO)")
        else:
            # Mock mode - Ubuntu/Test
            self._mock_angle = 0.0
            self._mock_running = False
            self._mock_thread = None
            self._initialized = False
            print("IKS9 Encoder - Mock modu (Ubuntu test)")

    def begin(self) -> bool:
        """Platform-aware encoder başlatma"""
        if self.is_raspberry_pi:
            return self._begin_raspberry_pi()
        else:
            return self._begin_mock()

    def _begin_raspberry_pi(self) -> bool:
        """Raspberry Pi GPIO başlatma"""
        try:
            print("Raspberry Pi GPIO başlatılıyor...")
            
            # GPIO ayarları
            GPIO.setmode(GPIO.BCM)
            GPIO.setup(self.pin_a, GPIO.IN, pull_up_down=GPIO.PUD_UP)
            GPIO.setup(self.pin_b, GPIO.IN, pull_up_down=GPIO.PUD_UP)
            
            if self.z_pulse_enabled:
                GPIO.setup(self.pin_z, GPIO.IN, pull_up_down=GPIO.PUD_UP)
            
            # İlk durumu oku
            self._last_state = (GPIO.input(self.pin_a) << 1) | GPIO.input(self.pin_b)
            
            # Interrupt'ları bağla
            GPIO.add_event_detect(self.pin_a, GPIO.BOTH, callback=self._handle_encoder_change)
            GPIO.add_event_detect(self.pin_b, GPIO.BOTH, callback=self._handle_encoder_change)
            
            if self.z_pulse_enabled:
                GPIO.add_event_detect(self.pin_z, GPIO.RISING, callback=self._handle_z_pulse)
            
            self._last_time = time.time()
            self._initialized = True
            
            print(f"Raspberry Pi GPIO başlatıldı - A:{self.pin_a}, B:{self.pin_b}, Z:{self.pin_z}")
            return True
            
        except Exception as e:
            print(f"Raspberry Pi GPIO başlatma hatası: {e}")
            return False

    def _begin_mock(self) -> bool:
        """Mock mode başlatma"""
        try:
            print("Mock encoder başlatılıyor...")
            print(f"  Mock pins: A={self.pin_a}, B={self.pin_b}, Z={self.pin_z}")
            print("  Otomatik döndürme simülasyonu aktif olacak")
            
            # Mock otomatik döndürme başlat
            self._start_mock_rotation()
            
            self._initialized = True
            print("Mock encoder başarıyla başlatıldı")
            return True
            
        except Exception as e:
            print(f"Mock encoder başlatma hatası: {e}")
            return False

    def _start_mock_rotation(self):
        """Mock otomatik döndürme"""
        self._mock_running = True
        self._mock_thread = threading.Thread(target=self._mock_rotation_loop)
        self._mock_thread.daemon = True
        self._mock_thread.start()

    def _mock_rotation_loop(self):
        """Mock döndürme döngüsü - Ubuntu test için"""
        start_time = time.time()
        
        while self._mock_running:
            current_time = time.time()
            elapsed = current_time - start_time
            
            # Yavaş sinüsoidal döndürme (çok yavaş ve düzgün)
            rotation_speed = 0.3  # radyan/saniye
            self._mock_angle = (elapsed * rotation_speed) % (2 * math.pi)
            
            # Açıyı dereceye çevir
            angle_degrees = math.degrees(self._mock_angle)
            
            # Pozisyon hesapla (3600 pulse = 360°)
            pulses_per_revolution = 3600
            new_position = int((angle_degrees / 360.0) * pulses_per_revolution)
            
            with self._lock:
                old_position = self._position
                self._position = new_position
                
                # Yön hesapla
                if new_position > old_position:
                    self._direction = True
                elif new_position < old_position:
                    self._direction = False
                
                # Callback çağır (pozisyon değiştiyse)
                if abs(new_position - old_position) > 2 and self.position_callback:
                    self.position_callback(self._position, angle_degrees)
            
            time.sleep(0.1)  # 10Hz güncelleme

    def _handle_encoder_change(self, channel):
        """Raspberry Pi GPIO interrupt handler"""
        if self.is_raspberry_pi:
            self._update_position_raspberry_pi()

    def _handle_z_pulse(self, channel):
        """Raspberry Pi Z pulse handler"""
        if self.is_raspberry_pi:
            with self._lock:
                self._z_pulse_detected = True

    def _update_position_raspberry_pi(self):
        """Raspberry Pi quadrature decoding"""
        with self._lock:
            current_state = (GPIO.input(self.pin_a) << 1) | GPIO.input(self.pin_b)
            
            # Quadrature decode
            state_change = 0
            transition = (self._last_state << 2) | current_state
            
            if transition in [0b0001, 0b0111, 0b1110, 0b1000]:
                state_change = 1
                self._direction = True
            elif transition in [0b0010, 0b1011, 0b1101, 0b0100]:
                state_change = -1
                self._direction = False
            else:
                state_change = 0
            
            self._position += state_change
            self._last_state = current_state
            
            # Callback çağır
            if self.position_callback and state_change != 0:
                angle_deg = self.get_angle_degrees()
                self.position_callback(self._position, angle_deg)

    def cleanup(self):
        """Platform-aware temizlik"""
        if self.is_raspberry_pi and self._initialized:
            try:
                GPIO.cleanup([self.pin_a, self.pin_b, self.pin_z])
                print("Raspberry Pi GPIO temizlendi")
            except:
                pass
        
        if not self.is_raspberry_pi and self._mock_running:
            self._mock_running = False
            if self._mock_thread:
                self._mock_thread.join(timeout=1.0)
            print("Mock encoder temizlendi")
        
        self._initialized = False

    def get_position(self) -> int:
        """Ham pozisyon"""
        with self._lock:
            return self._position

    def get_position_mm(self) -> float:
        """Pozisyon mm"""
        with self._lock:
            return (self._position * self.resolution_um) / 1000.0

    def get_position_um(self) -> float:
        """Pozisyon μm"""
        with self._lock:
            return self._position * self.resolution_um

    def get_angle_degrees(self) -> float:
        """Açı derece (0-360)"""
        with self._lock:
            pulses_per_revolution = 3600
            angle = (self._position % pulses_per_revolution) * (360.0 / pulses_per_revolution)
            return angle

    def reset_position(self):
        """Pozisyon sıfırla"""
        with self._lock:
            self._position = 0
            self._last_position = 0

    def get_direction(self) -> bool:
        """Yön bilgisi"""
        with self._lock:
            return self._direction if not self.invert_direction else not self._direction

    def update_speed(self):
        """Hız hesaplama"""
        current_time = time.time()
        
        with self._lock:
            current_pos = self._position
            
            if current_time - self._last_time >= 0.05:
                delta_position = current_pos - self._last_position
                delta_time = current_time - self._last_time
                
                self._current_speed = (delta_position * self.resolution_um * 0.001) / delta_time
                
                self._last_position = current_pos
                self._last_time = current_time

    def get_speed(self) -> float:
        """Hız mm/s"""
        with self._lock:
            return self._current_speed

    def get_z_pulse_status(self) -> bool:
        """Z pulse durumu"""
        if self.is_raspberry_pi:
            with self._lock:
                return self._z_pulse_detected
        else:
            # Mock: her tam turda Z pulse
            angle = self.get_angle_degrees()
            return abs(angle) < 10.0

    def clear_z_pulse(self):
        """Z pulse temizle"""
        with self._lock:
            self._z_pulse_detected = False

    def set_position_callback(self, callback: Callable[[int, float], None]):
        """Callback ayarla"""
        self.position_callback = callback

    def set_resolution(self, resolution_um: float):
        """Çözünürlük ayarla"""
        with self._lock:
            self.resolution_um = resolution_um

    def set_invert_direction(self, invert: bool):
        """Yön inversiyonu"""
        with self._lock:
            self.invert_direction = invert

    def get_platform_info(self) -> str:
        """Platform bilgisi"""
        if self.is_raspberry_pi:
            return "Raspberry Pi - Real GPIO"
        else:
            return f"Mock Mode - {platform.system()} {platform.machine()}"
