import sys
import os
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt

def main():
    # GStreamer sorunlarını önlemek için backend ayarları
    os.environ['QT_MULTIMEDIA_PREFERRED_PLUGINS'] = 'windowsmediafoundation,avfoundation,gstreamer'
    
    # X11 Authorization için environment variable'ları kopyala
    if 'DISPLAY' in os.environ:
        print(f"Environment variables:")
        print(f"DISPLAY: {os.environ.get('DISPLAY')}")
        print(f"QT_QPA_PLATFORM: {os.environ.get('QT_QPA_PLATFORM', 'xcb')}")
    
    # Desktop environment'ı tespit et
    desktop = os.environ.get('DESKTOP_SESSION', 'Unknown')
    print(f"Desktop Environment: {desktop}")
    
    # Qt ayarları
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    
    # Linux'ta video için gerekli olabilecek ek ayarlar
    os.environ.setdefault('QT_XCB_GL_INTEGRATION', 'none')
    
    try:
        app = QApplication(sys.argv)
        app.setApplicationName("Wheel Spinner - IKS9 Encoder Mode")
        
        # Font ayarını kontrol et
        font = app.font()
        print(f"Using font: {font.family()}")
        
        # Ana pencereyi oluştur
        print("Creating main window with IKS9 Encoder...")
        from .main_window import MainWindow
        window = MainWindow()
        
        # Raspberry Pi kontrolü
        try:
            import RPi.GPIO as GPIO
            print("Raspberry Pi GPIO detected - IKS9 Encoder mode active")
        except ImportError:
            print("WARNING: RPi.GPIO not found - Make sure you're running on Raspberry Pi")
            print("Install with: sudo apt install python3-rpi.gpio")
        
        window.show()
        
        print("Application started successfully with IKS9 Encoder")
        print("Hardware connections required:")
        print("  Brown wire (A signal)  -> GPIO 18")
        print("  Grey wire (B signal)   -> GPIO 19")
        print("  Pink wire (Z signal)   -> GPIO 2")
        print("  Red wire (5V)          -> 5V pin")
        print("  Blue wire (GND)        -> GND pin")
        print("")
        print("Controls:")
        print("  F1 = Menu")
        print("  F2 = Clock")
        print("  ESC = Toggle fullscreen")
        print("  Ctrl+Q = Quit")
        
        sys.exit(app.exec_())
    
    except KeyboardInterrupt:
        print("\nKeyboard interrupt detected...")
        if 'window' in locals() and hasattr(window, 'encoder') and window.encoder:
            print("Cleaning up GPIO...")
            window.encoder.cleanup()
        print("Application closed cleanly")
        
    except ImportError as e:
        if "RPi.GPIO" in str(e):
            print("\nERROR: RPi.GPIO library not found!")
            print("This application requires Raspberry Pi GPIO support.")
            print("Install with:")
            print("  sudo apt update")
            print("  sudo apt install python3-rpi.gpio")
            print("  pip3 install RPi.GPIO")
        else:
            print(f"Import error: {e}")
            
    except Exception as e:
        print(f"Application error: {e}")
        if 'window' in locals() and hasattr(window, 'encoder') and window.encoder:
            try:
                window.encoder.cleanup()
                print("GPIO cleaned up after error")
            except:
                pass

if __name__ == "__main__":
    print("=" * 50)
    print("WHEEL SPINNER - IKS9 ENCODER VERSION")
    print("=" * 50)
    print("Make sure you run this with sudo for GPIO access:")
    print("sudo python3 app.py")
    print("")
    
    # Root kontrolü
    if os.geteuid() != 0:
        print("WARNING: Not running as root (sudo)")
        print("GPIO access may fail. Use: sudo python3 app.py")
        print("")
    
    main()
