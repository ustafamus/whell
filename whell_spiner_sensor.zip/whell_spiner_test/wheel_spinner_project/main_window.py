import os
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout,
    QHBoxLayout, QLabel, QPushButton, QStackedWidget)
from PyQt5.QtCore import Qt, QPropertyAnimation, QTimer
from PyQt5.QtGui import QFont, QColor
from .wheel_widget import WheelWidget
from .menu_widget import MenuWidget
from .clock_widget import SimpleClockWidget
from .clock_config_dialog import SimpleClockConfigDialog
from .iks9_encoder import IKS9Encoder
import signal
import sys


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Wheel Spinner")
        
        self.setWindowState(Qt.WindowFullScreen)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)  
        
        # Full screen optimized styling
        self.setStyleSheet("""
            QMainWindow { 
                background-color: #1a1a1a; 
                border: none;
                margin: 0px;
                padding: 0px;
            }
            QLabel { 
                color: #333; 
                font-size: 14px; 
            }
            QPushButton {
                background-color: #007bff; 
                border: none; 
                border-radius: 8px;
                padding: 12px 24px; 
                font-size: 14px; 
                color: white; 
            }
        """)
        
        self.menu_positioning_timer = QTimer()
        self.menu_positioning_timer.setSingleShot(True)
        self.menu_positioning_timer.timeout.connect(self.position_menu_center)
        
        # Clock functionality
        self.clock_widget = None
        self.clock_timer = None
        self.remaining_timer = None
        self.clock_duration = 22
        self.clock_active = False
        self.clock_start_time = None
        
        # Clock config dialog tracking
        self.clock_config_dialog = None
        self.menu_was_visible_before_dialog = False
        
        # Default clock config
        self.clock_config = {
            'clock_type': 'Analog',
            'digital_style': 'neon',
            'analog_style': 'modern',
            'background_type': 'Color',
            'background_color': QColor(20, 20, 30),
            'background_image': None,
            'clock_color': QColor(0, 255, 255),
            'show_date': True,
            'show_seconds': True,
            'animation_enabled': True,
            'show_numbers': True,
            'date_format': 'dd.MM.yyyy'
        }

        # Screen saver functionality
        self.screen_saver_config = []
        self.current_screen_saver_index = 0
        self.screen_saver_items_shown = 0
        self.total_screen_saver_items = 0
        
        # Auto-clock timer
        self.auto_clock_timer = QTimer()
        self.auto_clock_timer.setSingleShot(True)
        self.auto_clock_timer.timeout.connect(self.start_auto_clock)
        self.auto_clock_timeout = 30000
        self.auto_clock_enabled = True
        
        # IKS9 Encoder
        self.encoder = None
        
        # Signal handler
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
        
        self.setup_ui()
        self.setup_encoder()

    def setup_encoder(self):
        """IKS9 Encoder kurulumu - Platform aware"""
        try:
            print("IKS9 Encoder başlatılıyor...")
            
            # Encoder oluştur (hibrit - platform otomatik algılama)
            self.encoder = IKS9Encoder(
                pin_a=18,    # PIN_A - kahverengi kablo
                pin_b=19,    # PIN_B - gri kablo  
                pin_z=2,     # PIN_Z - pembe kablo
                resolution_um=5.0  # ENCODER_RESOLUTION_UM
            )
            
            # Platform bilgisini göster
            print(f"Platform: {self.encoder.get_platform_info()}")
            
            # Encoder başlat
            if self.encoder.begin():
                # Pozisyon değişikliği callback'i ayarla
                self.encoder.set_position_callback(self.on_encoder_position_changed)
                print("IKS9 Encoder başarıyla başlatıldı")
                
                if not self.encoder.is_raspberry_pi:
                    print("UBUNTU TEST MODU - Çark otomatik döner")
                    print("Raspberry Pi'de gerçek sensör ile test edin")
                
            else:
                print("IKS9 Encoder başlatılamadı!")
                self.encoder = None
                
        except Exception as e:
            print(f"Encoder kurulum hatası: {e}")
            self.encoder = None

    def on_encoder_position_changed(self, position: int, angle_degrees: float):
        """
        Encoder pozisyon değişikliği callback'i
        
        Args:
            position: Ham encoder pozisyonu
            angle_degrees: Derece cinsinden açı (0-360)
        """
        if not self.clock_active and not self.wheel_widget.screen_saver_mode:
            # Wheel widget'ini güncelle
            self.wheel_widget.set_target_angle(angle_degrees)

    def setup_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        
        # DYNAMIC LAYOUT - NO FIXED SIZES, FULL EXPANSION
        main_layout = QVBoxLayout(central)
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)

        # FIXED: Use QStackedWidget for clean widget switching
        self.stacked_widget = QStackedWidget()
        
        # DYNAMIC WHEEL WIDGET - MAXIMUM SIZE ALWAYS
        self.wheel_widget = WheelWidget()
        self.wheel_widget.screen_saver_item_finished.connect(self.on_screen_saver_media_finished)
        
        # CRITICAL: Remove all size constraints - let it expand to full window
        from PyQt5.QtWidgets import QSizePolicy
        self.wheel_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.wheel_widget.setMinimumSize(0, 0)  # No minimum
        self.wheel_widget.setMaximumSize(16777215, 16777215)  # No maximum
        
        # DYNAMIC CLOCK WIDGET - SAME SIZE AS WHEEL
        self.clock_widget = SimpleClockWidget()
        
        # Same expansion policy as wheel
        self.clock_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.clock_widget.setMinimumSize(0, 0)
        self.clock_widget.setMaximumSize(16777215, 16777215)
        
        # Add both widgets to stacked widget
        self.stacked_widget.addWidget(self.wheel_widget)  # Index 0
        self.stacked_widget.addWidget(self.clock_widget)  # Index 1
        
        # Set initial widget to wheel
        self.stacked_widget.setCurrentIndex(0)
        
        # Add stacked widget to main layout - FULL SIZE
        main_layout.addWidget(self.stacked_widget)

        # Menu Widget - DYNAMIC SIZE
        self.menu_widget = MenuWidget(self)
        self.menu_widget.hide()
        self.menu_widget.game_image_selected.connect(self.on_image_selected)
        self.menu_widget.slices_changed.connect(self.wheel_widget.set_slices)
        self.menu_widget.save_clicked.connect(self.on_settings_saved)
        self.menu_widget.clock_config_requested.connect(self.show_clock_config)
        self.menu_widget.clock_duration_changed.connect(self.update_clock_duration)
        self.menu_widget.screen_saver_config_changed.connect(self.update_screen_saver_config)
        
        # Set initial clock config
        self.menu_widget.set_current_clock_config(self.clock_config)

        # Install event filter
        self.installEventFilter(self)
        central.installEventFilter(self)
        self.menu_widget.installEventFilter(self)
        
        print("DYNAMIC Main window setup complete - ENCODER MODE (No Slider)")

    def get_dynamic_wheel_radius(self):
        """Calculate MAXIMUM possible wheel radius for current window size"""
        window_width = self.width()
        window_height = self.height()
        
        # Use MAXIMUM available space (subtract minimal padding)
        max_diameter = min(window_width, window_height) - 10  # Very minimal padding
        radius = max_diameter // 2
        
        # Ensure reasonable minimum for functionality
        return max(radius, 250)

    def eventFilter(self, obj, event):
        if event.type() == event.KeyPress:
            if event.key() == Qt.Key_F1:
                print("F1 key pressed - toggling DYNAMIC menu")
                if (self.menu_widget.animation and
                    self.menu_widget.animation.state() == QPropertyAnimation.Running):
                    return True
                self.toggle_menu()
                return True
            elif event.key() == Qt.Key_F2:
                print("F2 key pressed")
                if self.clock_active:
                    print("F2: Closing DYNAMIC clock")
                    self.toggle_clock()
                elif self.wheel_widget.screen_saver_mode:
                    print("F2: Stopping screen saver and returning to DYNAMIC wheel")
                    self.exit_screen_saver_mode()
                else:
                    print("F2: Opening DYNAMIC clock")
                    self.toggle_clock()
                return True
            elif event.key() == Qt.Key_F11:
                print("F11 pressed - toggling fullscreen")
                self.toggle_fullscreen()
                return True
            elif event.key() == Qt.Key_F4 and event.modifiers() == Qt.AltModifier:
                print("Alt+F4 blocked in fullscreen mode")
                return True
            elif event.key() == Qt.Key_Q and event.modifiers() == Qt.ControlModifier:
                print("Ctrl+Q pressed - Closing application")
                self.close()
                return True

        # Reset auto-clock timer on ALL interactions
        if event.type() in [event.MouseButtonPress, event.KeyPress, event.MouseMove, 
                           event.MouseButtonRelease, event.Wheel, event.FocusIn, 
                           event.FocusOut, event.Enter, event.Leave]:
            self.reset_auto_clock_timer()

        return super().eventFilter(obj, event)

    def toggle_fullscreen(self):
        if self.isFullScreen():
            self.showNormal()
            self.setWindowFlags(Qt.Window)
            self.show()
            print("Exited fullscreen mode - DYNAMIC sizing continues")
        else:
            self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
            self.showFullScreen()
            print("Entered fullscreen mode - DYNAMIC sizing active")

    def reset_auto_clock_timer(self):
        """Reset auto-clock timer"""
        if self.auto_clock_enabled and not self.clock_active:
            if not self.wheel_widget.screen_saver_mode:
                self.auto_clock_timer.stop()
                self.auto_clock_timer.start(self.auto_clock_timeout)

    def start_auto_clock(self):
        """Show clock automatically after 30 seconds inactivity"""
        if self.auto_clock_enabled and not self.clock_active:
            if not self.wheel_widget.screen_saver_mode and not self.menu_widget.is_visible:
                print("Auto-clock activated - DYNAMIC clock shown")
                self.show_clock()
            else:
                if self.menu_widget.is_visible:
                    self.reset_auto_clock_timer()

    def toggle_menu(self):
        print(f"Toggle DYNAMIC menu called - menu visible: {self.menu_widget.is_visible}")
        if self.menu_widget.is_visible:
            self.menu_widget.hide_menu()
        else:
            self.show_menu()
        self.reset_auto_clock_timer()

    def show_menu(self):
        print("Showing DYNAMIC menu...")
        wheel_outer_radius = self.get_dynamic_wheel_radius()
        self.menu_widget.update_size(wheel_outer_radius)
        self.position_menu_center()
        self.menu_widget.show_menu()
        self.reset_auto_clock_timer()

    def position_menu_center(self):
        try:
            # Position menu at window center (same as wheel/clock center)
            wheel_center_x = self.width() // 2
            wheel_center_y = self.height() // 2
            
            menu_x = wheel_center_x - self.menu_widget.width() // 2
            menu_y = wheel_center_y - self.menu_widget.height() // 2
            
            menu_x = max(0, min(menu_x, self.width() - self.menu_widget.width()))
            menu_y = max(0, min(menu_y, self.height() - self.menu_widget.height()))
            
            self.menu_widget.move(menu_x, menu_y)
            print(f"DYNAMIC menu positioned at ({menu_x}, {menu_y}) with radius {self.get_dynamic_wheel_radius()}")
        except Exception as e:
            print(f"Error positioning DYNAMIC menu: {e}")
            center_x = self.width() // 2 - self.menu_widget.width() // 2
            center_y = self.height() // 2 - self.menu_widget.height() // 2
            self.menu_widget.move(center_x, center_y)

    def show_clock_config(self, current_config):
        """Show clock configuration dialog"""
        config_to_use = current_config if current_config else self.clock_config
        print(f"DEBUG MAIN: DYNAMIC clock config with radius: {self.get_dynamic_wheel_radius()}")
        
        # Save menu visibility state
        self.menu_was_visible_before_dialog = self.menu_widget.is_visible
        
        # Hide menu if open
        if self.menu_widget.is_visible:
            self.menu_widget.hide_menu()
            print("DEBUG: Menu hidden for DYNAMIC clock config dialog")
        
        # Create dialog with DYNAMIC radius
        wheel_outer_radius = self.get_dynamic_wheel_radius()
        self.clock_config_dialog = SimpleClockConfigDialog(self, config_to_use, wheel_outer_radius)
        self.clock_config_dialog.clock_configured.connect(self.update_clock_config)
        
        # Position dialog
        self.position_clock_dialog()
        
        # Show dialog
        self.clock_config_dialog.show_dialog()
        
        # Wait for result
        result = self.clock_config_dialog.exec_()
        
        # Restore menu if it was visible
        if self.menu_was_visible_before_dialog:
            QTimer.singleShot(200, self.restore_menu_after_dialog)
        
        self.clock_config_dialog = None

    def position_clock_dialog(self):
        """Position clock config dialog to center"""
        if self.clock_config_dialog:
            try:
                # Position at window center
                widget_center_x = self.width() // 2
                widget_center_y = self.height() // 2
                
                dialog_x = widget_center_x - self.clock_config_dialog.width() // 2
                dialog_y = widget_center_y - self.clock_config_dialog.height() // 2
                
                dialog_x = max(0, min(dialog_x, self.width() - self.clock_config_dialog.width()))
                dialog_y = max(0, min(dialog_y, self.height() - self.clock_config_dialog.height()))
                
                self.clock_config_dialog.move(dialog_x, dialog_y)
                print(f"DEBUG: DYNAMIC clock dialog positioned at ({dialog_x}, {dialog_y})")
            except:
                center_x = self.width() // 2 - self.clock_config_dialog.width() // 2
                center_y = self.height() // 2 - self.clock_config_dialog.height() // 2
                self.clock_config_dialog.move(center_x, center_y)

    def restore_menu_after_dialog(self):
        """Show menu back after dialog closes"""
        if not self.menu_widget.is_visible:
            print("DEBUG: Restoring DYNAMIC menu after clock config dialog")
            wheel_outer_radius = self.get_dynamic_wheel_radius()
            self.menu_widget.update_size(wheel_outer_radius)
            self.position_menu_center()
            self.menu_widget.show_menu()
        
    def update_clock_config(self, config):
        """Update clock configuration"""
        self.clock_config = config.copy()
        
        # Update menu widget's clock display
        self.menu_widget.set_current_clock_config(self.clock_config)
        
        # Sync duration
        self.clock_duration = int(self.menu_widget.duration_combo.currentText())
        
        # Update DYNAMIC clock widget
        if self.clock_widget:
            self.clock_widget.configure_clock(self.clock_config)
        
        print(f"DYNAMIC clock configured: {config['clock_type']} with duration {self.clock_duration} minutes")

    def toggle_clock(self):
        """Toggle DYNAMIC clock with F2"""
        if self.clock_active:
            self.hide_clock_manually()
        else:
            self.show_clock()

    def show_clock(self):
        """Show DYNAMIC clock instead of wheel - FIXED with StackedWidget"""
        # Get duration from menu
        self.clock_duration = int(self.menu_widget.duration_combo.currentText())
        
        # Configure DYNAMIC clock
        self.clock_widget.configure_clock(self.clock_config)
        
        # Hide menu if open
        if self.menu_widget.is_visible:
            self.menu_widget.hide_menu()
            print("DEBUG: Menu hidden when DYNAMIC clock shown")
        
        # FIXED: Use stacked widget to switch to clock
        self.stacked_widget.setCurrentIndex(1)  # Switch to clock widget
        self.clock_active = True
        
        # Stop auto-clock timer
        self.auto_clock_timer.stop()
        
        # Stop previous timer
        if self.clock_timer:
            self.clock_timer.stop()
        if self.remaining_timer:
            self.remaining_timer.stop()
        
        # Save start time
        from PyQt5.QtCore import QDateTime
        self.clock_start_time = QDateTime.currentDateTime()
        
        # Start timer
        self.clock_timer = QTimer()
        self.clock_timer.setSingleShot(True)
        self.clock_timer.timeout.connect(self.hide_clock)
        self.clock_timer.start(self.clock_duration * 60 * 1000)
        
        # Debug timer
        self.remaining_timer = QTimer()
        self.remaining_timer.timeout.connect(self.print_remaining_time)
        self.remaining_timer.start(5000)
        
        clock_type = self.clock_config.get('clock_type', 'Analog')
        style = self.clock_config.get(f'{clock_type.lower()}_style', 'modern')
        print(f"DYNAMIC clock shown for {self.clock_duration} minutes ({clock_type} - {style})")
        
    def print_remaining_time(self):
        """Print remaining time for debug"""
        if self.clock_start_time and self.clock_active:
            from PyQt5.QtCore import QDateTime
            now = QDateTime.currentDateTime()
            elapsed_ms = self.clock_start_time.msecsTo(now)
            elapsed_minutes = elapsed_ms / (60 * 1000)
            remaining_minutes = self.clock_duration - elapsed_minutes
            
            if remaining_minutes > 0:
                print(f"DYNAMIC clock remaining time: {remaining_minutes:.1f} minutes")

    def hide_clock_manually(self):
        """Hide DYNAMIC clock manually with F2 - FIXED with StackedWidget"""
        if self.clock_timer:
            self.clock_timer.stop()
            self.clock_timer = None
        if self.remaining_timer:
            self.remaining_timer.stop()
            self.remaining_timer = None
        
        # FIXED: Use stacked widget to switch back to wheel
        self.stacked_widget.setCurrentIndex(0)  # Switch to wheel widget
        self.clock_active = False
        self.clock_start_time = None

        # Restart auto-clock timer
        if self.auto_clock_enabled:
            self.reset_auto_clock_timer()

        print("DYNAMIC clock hidden - returned to DYNAMIC wheel")

    def hide_clock(self):
        """Hide DYNAMIC clock automatically with timer - FIXED with StackedWidget"""
        if self.clock_timer:
            self.clock_timer.stop()
            self.clock_timer = None
        if self.remaining_timer:
            self.remaining_timer.stop()
            self.remaining_timer = None
        
        # FIXED: Use stacked widget to switch back to wheel
        self.stacked_widget.setCurrentIndex(0)  # Switch to wheel widget
        self.clock_active = False
        self.clock_start_time = None

        # Start screen saver or return to wheel
        if self.screen_saver_config:
            print("DYNAMIC clock auto-hidden - starting screen saver")
            self.start_screen_saver()
        else:
            print("DYNAMIC clock auto-hidden - returned to DYNAMIC wheel")

    def on_image_selected(self, image_path):
        self.wheel_widget.set_background_image(image_path)

    def on_settings_saved(self):
        self.clock_duration = int(self.menu_widget.duration_combo.currentText())
        print(f"Settings saved - DYNAMIC duration: {self.clock_duration} minutes")
        self.reset_auto_clock_timer()

    def resizeEvent(self, event):
        """DYNAMIC resize event - everything scales with window size"""
        super().resizeEvent(event)
        
        print(f"DYNAMIC resize event - New size: {self.width()}x{self.height()}")
        
        # Update dynamic wheel radius
        new_radius = self.get_dynamic_wheel_radius()
        print(f"DYNAMIC new wheel radius: {new_radius}")
        
        # If menu is visible, update its size
        if self.menu_widget.is_visible:
            self.menu_widget.update_size(new_radius)
            self.menu_positioning_timer.start(100)
        
        # Update clock config dialog position
        if self.clock_config_dialog and self.clock_config_dialog.isVisible():
            QTimer.singleShot(50, self.position_clock_dialog)

        print(f"DYNAMIC resize complete - All elements scaled to radius: {new_radius}")

    def keyPressEvent(self, event):
        """Key press events"""
        if event.key() == Qt.Key_Escape:
            if self.clock_config_dialog and self.clock_config_dialog.isVisible():
                self.clock_config_dialog.reject_config()
            elif self.wheel_widget.screen_saver_mode:
                self.exit_screen_saver_mode()
            elif self.clock_active:
                self.hide_clock_manually()
            elif self.menu_widget.is_visible:
                self.menu_widget.hide_menu()
            else:
                if self.isFullScreen():
                    print("ESC pressed - Exiting fullscreen mode")
                    self.toggle_fullscreen()
                else:
                    print("ESC pressed - Entering fullscreen mode")
                    self.toggle_fullscreen()
        super().keyPressEvent(event)

    def update_clock_duration(self, duration):
        """Update duration value from menu"""
        self.clock_duration = duration
        print(f"DYNAMIC clock duration updated to: {duration} minutes")
        self.reset_auto_clock_timer()

    def update_screen_saver_config(self, config):
        self.screen_saver_config = config
        self.total_screen_saver_items = len(config)
        print(f"DYNAMIC screen saver config updated with {len(config)} items.")
        self.reset_auto_clock_timer()

    def start_screen_saver(self):
        """Start screen saver inside DYNAMIC wheel widget"""
        if not self.screen_saver_config:
            print("No screen saver config found, staying on DYNAMIC wheel")
            return

        print(f"Starting DYNAMIC screen saver sequence with {len(self.screen_saver_config)} items")
        
        # Reset screen saver variables
        self.current_screen_saver_index = 0
        self.screen_saver_items_shown = 0
        self.total_screen_saver_items = len(self.screen_saver_config)
        
        # Show first item
        self.show_next_screen_saver_item()

    def show_next_screen_saver_item(self):
        """Show next screen saver item in DYNAMIC wheel"""
        if not self.screen_saver_config:
            print("Screen saver config missing, exiting")
            self.exit_screen_saver_mode()
            return

        if self.screen_saver_items_shown >= self.total_screen_saver_items:
            print("All DYNAMIC screen saver items shown, returning to wheel")
            self.exit_screen_saver_mode()
            return

        if self.current_screen_saver_index >= len(self.screen_saver_config):
            self.current_screen_saver_index = 0

        item = self.screen_saver_config[self.current_screen_saver_index]
        print(f"Showing DYNAMIC screen saver item {self.current_screen_saver_index + 1}/{len(self.screen_saver_config)}")
        
        # Give item to DYNAMIC wheel widget
        self.wheel_widget.start_screen_saver_mode(item)
        
        # Increment counters
        self.current_screen_saver_index += 1
        self.screen_saver_items_shown += 1

    def on_screen_saver_media_finished(self):
        """Signal from DYNAMIC wheel widget when screen saver media finishes"""
        print("DYNAMIC screen saver media finished")
        
        if self.screen_saver_items_shown >= self.total_screen_saver_items:
            print("All DYNAMIC screen saver items completed")
            self.exit_screen_saver_mode()
        else:
            print("Showing next DYNAMIC screen saver item")
            QTimer.singleShot(300, self.show_next_screen_saver_item)

    def exit_screen_saver_mode(self):
        """Exit screen saver mode"""
        print("Exiting DYNAMIC screen saver mode")
        
        # Exit wheel widget from screen saver mode
        self.wheel_widget.exit_screen_saver_mode()
        
        # Reset counters
        self.screen_saver_items_shown = 0
        self.current_screen_saver_index = 0

        # Restart auto-clock timer
        if self.auto_clock_enabled:
            QTimer.singleShot(1000, self.reset_auto_clock_timer)

        print("Returned to DYNAMIC wheel mode")

    def signal_handler(self, signum, frame):
        """Sistem sinyali yakalama (Ctrl+C vs.)"""
        print(f"Sinyal yakalandı: {signum}")
        self.cleanup_and_exit()

    def cleanup_and_exit(self):
        """Temiz çıkış"""
        print("Uygulama kapatılıyor...")
        
        if self.encoder:
            self.encoder.cleanup()
        
        from PyQt5.QtWidgets import QApplication
        QApplication.quit()

    def closeEvent(self, event):
        """Pencere kapatılırken"""
        if self.encoder:
            self.encoder.cleanup()
        
        print("Application closing from DYNAMIC fullscreen mode...")
        self.setCursor(Qt.ArrowCursor)
        event.accept()
