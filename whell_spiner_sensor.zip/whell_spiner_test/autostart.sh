#!/bin/bash

echo "Setting up Wheel Spinner Autostart..."
echo "======================================"

# Autostart dizinini oluştur
echo "Creating autostart directory..."
mkdir -p ~/.config/autostart

# Mevcut dizini al
CURRENT_DIR="$(pwd)"
echo "Current directory: $CURRENT_DIR"

# Autostart desktop dosyasını oluştur
echo "Creating autostart entry..."
cat > ~/.config/autostart/wheel-spinner-autostart.desktop << EOF
[Desktop Entry]
Type=Application
Name=Wheel Spinner Autostart
Comment=Auto-start Wheel Spinner on boot
Exec=$CURRENT_DIR/run_wheel_spinner.py
Icon=$CURRENT_DIR/wheel_spinner_icon.png
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
StartupNotify=false
Terminal=false
EOF

chmod +x ~/.config/autostart/wheel-spinner-autostart.desktop

echo "✔ Autostart entry created"
echo ""
echo "Wheel Spinner will now start automatically when you log in!"
echo ""
echo "To disable autostart:"
echo "1. Delete: ~/.config/autostart/wheel-spinner-autostart.desktop"
echo "2. Or run: rm ~/.config/autostart/wheel-spinner-autostart.desktop"
echo ""
echo "Note: The application will start automatically after desktop loads"

