#!/usr/bin/env python3
from PyQt5.QtWidgets import QApplication
from PyQt5.QtGui import QPainter, QColor, QBrush, QPen, QPixmap, QPolygon
from PyQt5.QtCore import Qt, QPoint
import sys

app = QApplication(sys.argv)

# 128x128 ikon olu?tur
pixmap = QPixmap(128, 128)
pixmap.fill(Qt.transparent)

painter = QPainter(pixmap)
painter.setRenderHint(QPainter.Antialiasing)

center = QPoint(64, 64)
radius = 54

# Arka plan dairesi
painter.setBrush(QBrush(QColor(50, 50, 50)))
painter.setPen(QPen(QColor(100, 100, 100), 3))
painter.drawEllipse(center, radius, radius)

# Renkli dilimler
colors = [
    QColor(231, 76, 60), QColor(230, 126, 34), 
    QColor(241, 196, 15), QColor(46, 204, 113),
    QColor(26, 188, 156), QColor(52, 152, 219),
    QColor(155, 89, 182), QColor(149, 165, 166)
]

slice_angle = 45 
for i in range(8):
    start_angle = i * slice_angle
    painter.setBrush(QBrush(colors[i]))
    painter.setPen(QPen(QColor(255, 255, 255), 1))
    painter.drawPie(10, 10, 108, 108, int(start_angle * 16), int(slice_angle * 16))

# Merkez nokta
painter.setBrush(QBrush(QColor(255, 255, 255)))
painter.setPen(QPen(QColor(0, 0, 0), 2))
painter.drawEllipse(center, 8, 8)

# Ok i?areti
painter.setBrush(QBrush(QColor(220, 53, 69)))
painter.setPen(QPen(QColor(120, 30, 40), 2))
arrow_size = 12
ax, ay = center.x(), center.y() - radius - 5
arrow_points = [
    QPoint(ax, ay + arrow_size),
    QPoint(ax - arrow_size//2, ay),
    QPoint(ax + arrow_size//2, ay)
]
arrow = QPolygon(arrow_points)
painter.drawPolygon(arrow)

painter.end()
pixmap.save("wheel_spinner_icon.png", "PNG")
print("? wheel_spinner_icon.png created")
