#!/bin/bash

# Color codes for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}===========================================${NC}"
echo -e "${GREEN}      Wheel Spinner Project Setup Script     ${NC}"
echo -e "${GREEN}===========================================${NC}"

# Exit immediately if a command exits with a non-zero status.
set -e

# --- STEP 1: Install System Dependencies (apt) ---
echo -e "\n${YELLOW}> Step 1: Checking and installing system dependencies...${NC}"
REQUIRED_PKGS="python3-pyqt5 python3-pyqt5.qtmultimedia python3-pip python3-venv"
NEEDS_INSTALL=0

for PKG in $REQUIRED_PKGS; do
  if ! dpkg -s "$PKG" > /dev/null 2>&1; then
    echo "  - Package '$PKG' not found. It will be installed."
    NEEDS_INSTALL=1
  fi
done

if [ $NEEDS_INSTALL -eq 1 ]; then
  echo "Updating package list and installing missing packages..."
  echo "This may require you to enter your password for system-wide installation."
  sudo apt-get update
  sudo apt-get install -y $REQUIRED_PKGS
  echo "✔ System dependencies installed successfully."
else
  echo "✔ All system dependencies are already installed."
fi

# --- STEP 2: Create Python Virtual Environment (venv) ---
VENV_DIR="venv"
echo -e "\n${YELLOW}> Step 2: Setting up Python Virtual Environment...${NC}"
if [ ! -d "$VENV_DIR" ]; then
  python3 -m venv "$VENV_DIR" --system-site-packages
  echo "✔ Virtual environment created at '$VENV_DIR/'"
else
  echo "✔ Virtual environment already exists."
fi


# --- STEP 3: Install Python Packages into venv (pip) ---
echo -e "\n${YELLOW}> Step 3: Installing Python packages into the virtual environment...${NC}"
if [ -f "requirements.txt" ]; then
  "$VENV_DIR/bin/pip" install --upgrade pip
  "$VENV_DIR/bin/pip" install -r requirements.txt
  echo "✔ Python packages installed successfully."
else
  echo "Warning: requirements.txt not found. Skipping pip installation."
fi


# --- STEP 4: Generate Application Icon ---
echo -e "\n${YELLOW}> Step 4: Generating application icon...${NC}"
"$VENV_DIR/bin/python3" create_icon.py
if [ -f "wheel_spinner_icon.png" ]; then
    echo "✔ 'wheel_spinner_icon.png' created successfully."
else
    echo "ERROR: Failed to create icon file."
    exit 1
fi


# --- STEP 5: Desktop Integration ---
echo -e "\n${YELLOW}> Step 5: Creating application menu and desktop shortcut...${NC}"
CURRENT_DIR="$(pwd)"
VENV_DIR="venv" # Ensure VENV_DIR is defined
EXEC_PATH="$CURRENT_DIR/$VENV_DIR/bin/python3 $CURRENT_DIR/run_wheel_spinner.py"
echo "Application executable path set to: $EXEC_PATH"

mkdir -p ~/.local/share/applications

cat > ~/.local/share/applications/wheel-spinner.desktop << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Wheel Spinner
Comment=Interactive Wheel Spinner Game with Clock and Screen Saver
Exec=$EXEC_PATH
Icon=$CURRENT_DIR/wheel_spinner_icon.png
Terminal=false
StartupNotify=true
Categories=Game;Amusement;
Keywords=wheel;spinner;game;clock;screensaver;
StartupWMClass=wheel-spinner
NoDisplay=false
EOF

chmod +x ~/.local/share/applications/wheel-spinner.desktop
echo "✔ Application menu entry created."

if [ -d ~/Desktop ] || [ -d ~/Masaüstü ]; then
    DESKTOP_PATH=$(xdg-user-dir DESKTOP)
    DESKTOP_SHORTCUT_PATH="$DESKTOP_PATH/wheel-spinner.desktop"
    
    cp ~/.local/share/applications/wheel-spinner.desktop "$DESKTOP_SHORTCUT_PATH"
    chmod +x "$DESKTOP_SHORTCUT_PATH"
    echo "✔ Desktop shortcut created."
    
    # --- YENİ EKLENEN KISIM ---
    # Mark the desktop shortcut as trusted to avoid "Allow Launching?" prompt.
    echo "Attempting to mark desktop shortcut as trusted..."
    gio set "$DESKTOP_SHORTCUT_PATH" "metadata::trusted" yes || true
    # --- YENİ KISIM SONU ---

else
    echo "Desktop folder not found, skipping shortcut creation."
fi

update-desktop-database ~/.local/share/applications/ 2>/dev/null || true
echo "✔ Application menu refreshed."


# --- STEP 6: Test Run ---
echo -e "\n${YELLOW}> Step 6: Launching the application for a test run...${NC}"
echo "The application will now open for a moment to confirm it works."
# --- DEĞİŞEN KISIM ---
# Removed the "read -p" prompt for a non-interactive setup.
# The script will now wait 5 seconds while the app is running for the user to see it.
( "$EXEC_PATH" & ) # Run in background
sleep 5             # Wait for 5 seconds
pkill -f "$CURRENT_DIR/run_wheel_spinner.py" || true # Close the test app
# --- DEĞİŞİKLİK SONU ---
echo -e "\n${GREEN}Test finished.${NC}"


# --- Setup Complete ---
echo -e "\n${GREEN}===========================================${NC}"
echo -e "${GREEN}      SETUP COMPLETED SUCCESSFULLY!        ${NC}"
echo -e "${GREEN}===========================================${NC}"
echo ""
echo "✔ A trusted shortcut has been created on your Desktop."
echo "✔ You can also find 'Wheel Spinner' in your Applications Menu (under Games)."
echo ""
echo -e "${YELLOW}If you want the application to start automatically on login,${NC}"
echo -e "${YELLOW}you can now run the following command:${NC}"
echo "  bash autostart.sh"
echo ""
