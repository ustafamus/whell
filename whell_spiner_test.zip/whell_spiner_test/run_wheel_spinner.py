#!/usr/bin/env python3
"""
Wheel Spinner Application - Raspberry Pi Edition
"""

import sys
import os
from pathlib import Path

def setup_environment():
    # Proje dizinini Python path'e ekle
    project_dir = Path(__file__).parent.absolute()
    if str(project_dir) not in sys.path:
        sys.path.insert(0, str(project_dir))
    
    os.environ.setdefault('DISPLAY', ':0')
    os.environ.setdefault('QT_QPA_PLATFORM', 'xcb')
    
    os.environ['QT_MULTIMEDIA_PREFERRED_PLUGINS'] = 'gstreamer'
    os.environ.setdefault('QT_XCB_GL_INTEGRATION', 'none')
    
    print(f"? Project directory: {project_dir}")
    print(f"? Display: {os.environ.get('DISPLAY')}")

def main():
    """Ana uygulama ba?lat?c?s?"""
    print("=" * 50)
    print("   WHEEL SPINNER - Raspberry Pi Edition")
    print("=" * 50)
    
    try:
        # Environment'? ayarla
        setup_environment()
        
        try:
            import PyQt5
            print("? PyQt5 is available")
        except ImportError:
            print("? PyQt5 not found. Install with: sudo apt install python3-pyqt5")
            sys.exit(1)
        
        # Ana uygulamay? ba?lat
        print("Starting Wheel Spinner application...")
        from wheel_spinner_project.app import main as app_main
        app_main()
        
    except KeyboardInterrupt:
        print("\n? Application closed by user")
        sys.exit(0)
    except Exception as e:
        print(f"? Error starting application: {e}")
        print("\nTroubleshooting:")
        print("1. Make sure you're on desktop (not SSH without X11)")
        print("2. Try: export DISPLAY=:0")
        print("3. Check: sudo apt install python3-pyqt5 python3-pyqt5.qtmultimedia")
        sys.exit(1)

if __name__ == "__main__":
    main()
