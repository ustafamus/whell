import math
from PyQt5.QtWidgets import QWidget, QGraphicsDropShadowEffect
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QPainter, QColor

from wheel_spinner_project.digital_clock_styles import DigitalClockStyles
from wheel_spinner_project.analog_clock_styles import AnalogClockStyles
from wheel_spinner_project.clock_utils import ClockUtils


class SimpleClockWidget(QWidget):
    """DYNAMIC clock widget - scales to maximum window size like wheel"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.config = {
            'clock_type': 'Analog',
            'digital_style': 'neon',
            'analog_style': 'modern',
            'background_type': 'Color',
            'background_color': QColor(20, 20, 30),
            'background_image': None,
            'clock_color': QColor(0, 255, 255),
            'show_date': True,
            'show_seconds': True,
            'animation_enabled': True,
            'show_numbers': True,
            'date_format': 'dd.MM.yyyy'
        }
        
        # Animation values
        self._glow_intensity = 0
        self._pulse_value = 0
        self._rotation_angle = 0
        
        # Timers
        self.timer = QTimer()
        self.timer.timeout.connect(self.update)
        self.timer.start(50)
        
        self.animation_timer = QTimer()
        self.animation_timer.timeout.connect(self.animate)
        self.animation_timer.start(16)  # ~60 FPS
        
        # CRITICAL: Remove all size constraints - let widget expand dynamically
        from PyQt5.QtWidgets import QSizePolicy
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMinimumSize(0, 0)  # No minimum constraint
        self.setMaximumSize(16777215, 16777215)  # No maximum constraint
        
        # Drop shadow
        self.setup_shadow()
        
        print("DYNAMIC Clock Widget initialized - will scale to maximum size")
        
    def setup_shadow(self):
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(30)
        shadow.setColor(QColor(0, 0, 0, 150))
        shadow.setOffset(0, 5)
        self.setGraphicsEffect(shadow)
        
    def animate(self):
        """Update animation values"""
        if self.config['animation_enabled']:
            self._glow_intensity = (self._glow_intensity + 2) % 100
            self._pulse_value = abs(math.sin(self._glow_intensity * math.pi / 50))
            self._rotation_angle = (self._rotation_angle + 0.5) % 360
            
    def configure_clock(self, config):
        """Apply configuration to DYNAMIC clock"""
        # Ensure backward compatibility
        if 'analog_style' not in config and config.get('clock_type') == 'Analog':
            config['analog_style'] = 'modern'
        if 'digital_style' not in config and config.get('clock_type') == 'Digital':
            config['digital_style'] = 'neon'
        if 'date_format' not in config:
            config['date_format'] = 'dd.MM.yyyy'
            
        self.config.update(config)
        print(f"DYNAMIC clock configured: {config.get('clock_type', 'Unknown')} type")
        self.update()
        
    def get_dynamic_clock_radius(self):
        """Calculate MAXIMUM clock radius based on current widget size"""
        # Use the FULL widget size (which expands to fill the window)
        widget_width = self.width()
        widget_height = self.height()
        
        # Calculate maximum possible radius (same logic as wheel)
        max_diameter = min(widget_width, widget_height) - 20  # Minimal padding
        radius = max_diameter // 2
        
        # Ensure reasonable minimum
        radius = max(radius, 150)
        
        print(f"DYNAMIC clock radius calculated: {radius} (widget size: {widget_width}x{widget_height})")
        return radius
        
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setRenderHint(QPainter.TextAntialiasing)
        painter.setRenderHint(QPainter.SmoothPixmapTransform)
        
        # Get current dynamic size
        current_radius = self.get_dynamic_clock_radius()
        
        if self.config['clock_type'] == 'Digital':
            self.draw_dynamic_digital_clock(painter, current_radius)
        else:
            self.draw_dynamic_analog_clock(painter, current_radius)
    
    def draw_dynamic_digital_clock(self, painter, radius):
        """Draw DYNAMIC digital clock based on current size"""
        # Background
        ClockUtils.draw_background(painter, self.config, self.width(), self.height(), radius)
        
        # Clock style
        style = self.config.get('digital_style', 'neon')
        
        # Scale parameters based on current size
        scaled_width = self.width()
        scaled_height = self.height()
        
        # Original styles with DYNAMIC scaling
        if style == 'neon':
            DigitalClockStyles.draw_neon_clock(painter, self.config, scaled_width, scaled_height, 
                                            self._glow_intensity, self._pulse_value)
        elif style == 'lcd':
            DigitalClockStyles.draw_lcd_clock(painter, self.config, scaled_width, scaled_height, 
                                            self._glow_intensity, self._pulse_value)
        elif style == 'matrix':
            DigitalClockStyles.draw_matrix_clock(painter, self.config, scaled_width, scaled_height, 
                                                self._glow_intensity, self._pulse_value, self._rotation_angle)
        elif style == 'minimalist':
            DigitalClockStyles.draw_minimalist_clock(painter, self.config, scaled_width, scaled_height, 
                                                self._glow_intensity, self._pulse_value)
        elif style == 'retro':
            DigitalClockStyles.draw_retro_clock(painter, self.config, scaled_width, scaled_height, 
                                            self._glow_intensity, self._pulse_value)
        # NEW STYLES
        elif style == 'holographic':
            DigitalClockStyles.draw_holographic_clock(painter, self.config, scaled_width, scaled_height, 
                                                    self._glow_intensity, self._pulse_value)
        elif style == 'plasma':
            DigitalClockStyles.draw_plasma_clock(painter, self.config, scaled_width, scaled_height, 
                                                self._glow_intensity, self._pulse_value)
        elif style == 'crystal':
            DigitalClockStyles.draw_crystal_clock(painter, self.config, scaled_width, scaled_height, 
                                                self._glow_intensity, self._pulse_value)
        elif style == 'cyberpunk':
            DigitalClockStyles.draw_cyberpunk_clock(painter, self.config, scaled_width, scaled_height, 
                                                self._glow_intensity, self._pulse_value)
        elif style == 'neon_tube':
            DigitalClockStyles.draw_neon_tube_clock(painter, self.config, scaled_width, scaled_height, 
                                                self._glow_intensity, self._pulse_value)
        elif style == 'liquid_metal':
            DigitalClockStyles.draw_liquid_metal_clock(painter, self.config, scaled_width, scaled_height, 
                                                    self._glow_intensity, self._pulse_value)
        elif style == 'fire':
            DigitalClockStyles.draw_fire_clock(painter, self.config, scaled_width, scaled_height, 
                                            self._glow_intensity, self._pulse_value)
        elif style == 'ice':
            DigitalClockStyles.draw_ice_clock(painter, self.config, scaled_width, scaled_height, 
                                            self._glow_intensity, self._pulse_value)
        elif style == 'typewriter':
            DigitalClockStyles.draw_typewriter_clock(painter, self.config, scaled_width, scaled_height, 
                                                    self._glow_intensity, self._pulse_value)
        elif style == 'galaxy':
            DigitalClockStyles.draw_galaxy_clock(painter, self.config, scaled_width, scaled_height, 
                                            self._glow_intensity, self._pulse_value)
        else:
            # Fallback to neon
            DigitalClockStyles.draw_neon_clock(painter, self.config, scaled_width, scaled_height, 
                                            self._glow_intensity, self._pulse_value)
        
        # DYNAMIC Date
        if self.config['show_date']:
            cx, cy = scaled_width // 2, scaled_height // 2
            # Scale date position based on current size
            date_y_offset = max(90, radius // 4)  # Scale with clock size
            ClockUtils.draw_date(painter, cx, cy + date_y_offset, self.config)
    
    def draw_dynamic_analog_clock(self, painter, radius):
        """Draw DYNAMIC analog clock with current size"""
        # Background
        ClockUtils.draw_background(painter, self.config, self.width(), self.height(), radius)
        
        center = self.rect().center()
        
        # Clock style
        style = self.config.get('analog_style', 'modern')
        valid_styles = ['modern', 'classic', 'elegant', 'industrial', 'neon', 
                       'luxury', 'minimalist', 'retro', 'art_deco', 'steampunk']
        if style not in valid_styles:
            style = 'modern'
        
        # Draw based on style with DYNAMIC radius
        if style == 'modern':
            AnalogClockStyles.draw_modern_analog(painter, self.config, center, radius)
        elif style == 'classic':
            AnalogClockStyles.draw_classic_analog(painter, self.config, center, radius)
        elif style == 'elegant':
            AnalogClockStyles.draw_elegant_analog(painter, self.config, center, radius)
        elif style == 'industrial':
            AnalogClockStyles.draw_industrial_analog(painter, self.config, center, radius)
        elif style == 'neon':
            AnalogClockStyles.draw_neon_analog(painter, self.config, center, radius, self._pulse_value)
        elif style == 'luxury':
            AnalogClockStyles.draw_luxury_analog(painter, self.config, center, radius)
        elif style == 'minimalist':
            AnalogClockStyles.draw_minimalist_analog(painter, self.config, center, radius)
        elif style == 'retro':
            AnalogClockStyles.draw_retro_analog(painter, self.config, center, radius)
        elif style == 'art_deco':
            AnalogClockStyles.draw_art_deco_analog(painter, self.config, center, radius)
        elif style == 'steampunk':
            AnalogClockStyles.draw_steampunk_analog(painter, self.config, center, radius)
        else:
            AnalogClockStyles.draw_modern_analog(painter, self.config, center, radius)
        
        # Draw hands with DYNAMIC radius
        AnalogClockStyles.draw_clock_hands(painter, center, radius, style, self.config)
        
        # DYNAMIC Date inside the clock circle
        if self.config['show_date']:
            center_x, center_y = self.width() // 2, self.height() // 2
            ClockUtils.draw_analog_date(painter, center_x, center_y, radius, self.config)
            
    def resizeEvent(self, event):
        """DYNAMIC resize event - clock scales with window"""
        super().resizeEvent(event)
        
        new_radius = self.get_dynamic_clock_radius()
        print(f"DYNAMIC clock resized - new radius: {new_radius}, size: {self.width()}x{self.height()}")
        
        # Force repaint with new size
        self.update()
