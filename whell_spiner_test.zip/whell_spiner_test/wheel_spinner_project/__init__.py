# Wheel Spinner Project
# Modular Python wheel spinner application

__version__ = "1.0.0"
__author__ = "Wheel Spinner Team"