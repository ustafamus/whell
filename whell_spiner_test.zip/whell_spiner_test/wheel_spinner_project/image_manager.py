import os
import shutil
import re
import subprocess
from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QListWidget, QListWidgetItem, QMessageBox,
    QWidget, QComboBox)
from PyQt5.QtCore import Qt


class USBDetector:
    """
    Robust USB device detection for ALL Linux distributions
    Compatible with: Ubuntu, Debian, CentOS, RHEL, Fedora, Arch, openSUSE, etc.
    Handles any USB device name and mount location
    """

    @staticmethod
    def get_usb_devices():
        """
        Detect USB devices using multiple methods for maximum compatibility
        Works regardless of Linux distribution or USB device name
        """
        usb_devices = []
        detected_paths = set()  # Prevent duplicates
        
        # Method 1: Common mount points (/media, /run/media, /mnt)
        mount_points = ['/media', '/run/media', '/mnt']
        for mount_point in mount_points:
            if os.path.exists(mount_point):
                devices = USBDetector._scan_mount_point(mount_point)
                for device in devices:
                    if device['path'] not in detected_paths:
                        usb_devices.append(device)
                        detected_paths.add(device['path'])
        
        # Method 2: Parse /proc/mounts for any mounted USB-like devices
        proc_devices = USBDetector._parse_proc_mounts()
        for device in proc_devices:
            if device['path'] not in detected_paths:
                usb_devices.append(device)
                detected_paths.add(device['path'])
        
        # Method 3: Use lsblk if available (most reliable)
        lsblk_devices = USBDetector._use_lsblk()
        for device in lsblk_devices:
            if device['path'] not in detected_paths:
                usb_devices.append(device)
                detected_paths.add(device['path'])
        
        return usb_devices

    @staticmethod
    def _scan_mount_point(base_path):
        """Scan mount point for USB devices"""
        devices = []
        
        try:
            for item in os.listdir(base_path):
                item_path = os.path.join(base_path, item)
                
                if os.path.isdir(item_path):
                    # Direct mount (e.g., /media/USB_DEVICE)
                    if os.path.ismount(item_path) and USBDetector._is_removable_device(item_path):
                        devices.append({
                            'name': USBDetector._clean_device_name(item),
                            'path': item_path,
                            'user': 'system'
                        })
                    else:
                        # User subdirectories (e.g., /media/username/USB_DEVICE)
                        try:
                            for subitem in os.listdir(item_path):
                                subitem_path = os.path.join(item_path, subitem)
                                if (os.path.isdir(subitem_path) and 
                                    os.path.ismount(subitem_path) and
                                    USBDetector._is_removable_device(subitem_path)):
                                    
                                    devices.append({
                                        'name': USBDetector._clean_device_name(subitem),
                                        'path': subitem_path,
                                        'user': item
                                    })
                        except (OSError, PermissionError):
                            continue
                            
        except (OSError, PermissionError) as e:
            print(f"Error scanning {base_path}: {e}")
        
        return devices

    @staticmethod
    def _parse_proc_mounts():
        """Parse /proc/mounts to find USB devices"""
        devices = []
        
        try:
            with open('/proc/mounts', 'r') as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) >= 3:
                        device_node, mount_point, fs_type = parts[0], parts[1], parts[2]
                        
                        # Look for USB-like patterns and filesystems
                        if (USBDetector._looks_like_usb_device(device_node, mount_point, fs_type) and
                            os.path.exists(mount_point) and 
                            os.path.ismount(mount_point) and
                            USBDetector._is_removable_device(mount_point)):
                            
                            device_name = USBDetector._extract_device_name(device_node, mount_point)
                            devices.append({
                                'name': device_name,
                                'path': mount_point,
                                'user': 'system'
                            })
        except (OSError, PermissionError) as e:
            print(f"Error reading /proc/mounts: {e}")
        
        return devices

    @staticmethod
    def _use_lsblk():
        """Use lsblk command for reliable USB detection"""
        devices = []
        
        try:
            result = subprocess.run(
                ['lsblk', '-J', '-o', 'NAME,MOUNTPOINT,RM,TYPE,SIZE,LABEL'],
                capture_output=True, text=True, timeout=5
            )
            
            if result.returncode == 0:
                import json
                data = json.loads(result.stdout)
                
                for device in data.get('blockdevices', []):
                    devices.extend(USBDetector._process_lsblk_device(device))
                    
        except (subprocess.TimeoutExpired, subprocess.CalledProcessError, 
                json.JSONDecodeError, FileNotFoundError):
            pass  # lsblk not available
        except Exception as e:
            print(f"lsblk error: {e}")
        
        return devices

    @staticmethod
    def _process_lsblk_device(device):
        """Process lsblk device entry"""
        devices = []
        
        # Check if removable and mounted
        if (device.get('rm') == '1' and  # removable
            device.get('mountpoint') and  # mounted
            device.get('type') in ['part', 'disk']):
            
            mount_point = device['mountpoint']
            if os.path.exists(mount_point) and os.path.ismount(mount_point):
                device_name = device.get('label') or device.get('name', 'USB Device')
                devices.append({
                    'name': USBDetector._clean_device_name(device_name),
                    'path': mount_point,
                    'user': 'system'
                })
        
        # Process partitions
        for child in device.get('children', []):
            devices.extend(USBDetector._process_lsblk_device(child))
        
        return devices

    @staticmethod
    def _looks_like_usb_device(device_node, mount_point, fs_type):
        """Check if device appears to be USB"""
        # USB device patterns
        usb_patterns = [r'/dev/sd[a-z]\d*', r'/dev/mmcblk\d+p\d+', r'/dev/nvme\d+n\d+p\d+']
        
        # Check device node
        if not any(re.match(pattern, device_node) for pattern in usb_patterns):
            return False
        
        # Check filesystem (common for removable devices)
        if fs_type not in ['vfat', 'ntfs', 'exfat', 'ext4', 'ext3', 'ext2', 'hfsplus']:
            return False
        
        # Avoid system directories
        system_mounts = ['/', '/boot', '/home', '/usr', '/var', '/tmp', '/opt']
        if mount_point in system_mounts or mount_point.startswith(('/sys', '/proc')):
            return False
        
        return True

    @staticmethod
    def _is_removable_device(mount_point):
        """Verify if device is actually removable"""
        try:
            if not os.access(mount_point, os.R_OK):
                return False
            
            # Check reasonable size (avoid tiny system partitions)
            statvfs = os.statvfs(mount_point)
            total_space = statvfs.f_frsize * statvfs.f_blocks
            
            if total_space < 1024 * 1024:  # Less than 1MB
                return False
            
            return True
            
        except (OSError, PermissionError):
            return False

    @staticmethod
    def _clean_device_name(name):
        """Clean up device name for display"""
        if not name or name.strip() == '':
            return "USB Device"
        
        name = name.strip()
        name = re.sub(r'^/dev/', '', name)
        name = re.sub(r'\d+$', '', name)
        
        # Handle generic names
        generic_names = {
            'NO_NAME': 'USB Drive', 'UNTITLED': 'USB Drive',
            'USB_DISK': 'USB Drive', 'DISK': 'USB Drive'
        }
        
        upper_name = name.upper()
        if upper_name in generic_names:
            return generic_names[upper_name]
        
        # Limit length
        if len(name) > 20:
            name = name[:17] + "..."
        
        return name.replace('_', ' ').title()

    @staticmethod
    def _extract_device_name(device_node, mount_point):
        """Extract meaningful device name"""
        mount_name = os.path.basename(mount_point)
        if mount_name and mount_name not in ['mnt', 'media', 'run']:
            return mount_name
        
        device_name = os.path.basename(device_node)
        return device_name if device_name else "USB Device"

    @staticmethod
    def get_media_files_from_usb(usb_path, media_type="image"):
        """Get media files from USB - enhanced with multiple search locations"""
        media_files = []

        if media_type == "image":
            extensions = ('.png', '.jpg', '.jpeg', '.bmp', '.gif', '.webp', '.tiff')
            folder_names = ["images", "IMAGES", "Images", "Pictures", "PICTURES", "pics", "PICS"]
        else:  # video
            extensions = ('.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv', '.webm', '.m4v', '.3gp', '.ogv')
            folder_names = ["videos", "VIDEOS", "Videos", "Movies", "MOVIES", "vids", "VIDS"]

        # Search in specific folders first, then root
        search_paths = []
        for folder_name in folder_names:
            folder_path = os.path.join(usb_path, folder_name)
            if os.path.exists(folder_path):
                search_paths.append(folder_path)
        
        # Add root directory as fallback
        search_paths.append(usb_path)

        for search_path in search_paths:
            if os.path.exists(search_path) and os.path.isdir(search_path):
                try:
                    for file_name in os.listdir(search_path):
                        if file_name.lower().endswith(extensions):
                            full_path = os.path.join(search_path, file_name)
                            if os.path.isfile(full_path):
                                try:
                                    file_size = os.path.getsize(full_path)
                                    media_files.append({
                                        'name': file_name,
                                        'path': full_path,
                                        'size': file_size
                                    })
                                except OSError:
                                    continue
                except (OSError, PermissionError) as e:
                    print(f"Error reading {search_path}: {e}")
                    continue

            # Stop after finding files in a specific folder
            if media_files and search_path != usb_path:
                break

        return sorted(media_files, key=lambda x: x['name'].lower())

    @staticmethod
    def format_file_size(size_bytes):
        """Format file size to readable format"""
        try:
            size_bytes = int(size_bytes)
        except (ValueError, TypeError):
            return "Unknown"
            
        if size_bytes < 1024:
            return f"{size_bytes} B"
        elif size_bytes < 1024 * 1024:
            return f"{size_bytes / 1024:.1f} KB"
        elif size_bytes < 1024 * 1024 * 1024:
            return f"{size_bytes / (1024 * 1024):.1f} MB"
        else:
            return f"{size_bytes / (1024 * 1024 * 1024):.1f} GB"


class ImageManager:
    """Enhanced image and video management with robust USB support"""

    @staticmethod
    def copy_image_to_folder(source_path, target_folder, target_filename=None):
        """Copy media file to target folder"""
        try:
            if not os.path.exists(target_folder):
                os.makedirs(target_folder)

            if not target_filename:
                filename = os.path.basename(source_path)
                name, ext = os.path.splitext(filename)

                counter = 1
                target_filename = filename
                while os.path.exists(os.path.join(target_folder, target_filename)):
                    target_filename = f"{name}_{counter}{ext}"
                    counter += 1

            target_path = os.path.join(target_folder, target_filename)
            shutil.copy2(source_path, target_path)
            return target_filename

        except Exception as e:
            return None, str(e)

    @staticmethod
    def show_file_browser(parent_dialog, title="Select File", file_types="image"):
        """Enhanced file browser with robust USB detection"""
        browser_dialog = QDialog(parent_dialog)
        browser_dialog.setWindowTitle(title)
        browser_dialog.setFixedSize(600, 500)
        browser_dialog.setModal(True)

        if file_types == "video":
            extensions = ('.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv', '.webm', '.m4v')
            file_icon = "📹"
        else:
            extensions = ('.png', '.jpg', '.jpeg', '.bmp', '.gif')
            file_icon = "🖼️"

        browser_dialog.setStyleSheet("""
            QDialog {
                background-color: #ffffff;
                border: 1px solid #e0e0e0;
                border-radius: 8px;
            }
            QLabel {
                color: #2c3e50;
                font-size: 12px;
                font-weight: 500;
                padding: 4px 0px;
                background: transparent;
                border: none;
            }
            QLabel#usbLabel {
                background-color: #e3f2fd;
                border: 1px solid #2196f3;
                border-radius: 4px;
                padding: 6px 10px;
                color: #1976d2;
                font-weight: 600;
            }
            QLabel#usbLabel:hover {
                background-color: #bbdefb;
                cursor: pointer;
            }
            QListWidget {
                background-color: #fafafa;
                border: 1px solid #e0e0e0;
                border-radius: 6px;
                font-size: 12px;
                color: #2c3e50;
                padding: 4px;
                outline: none;
            }
            QListWidget::item {
                padding: 6px 10px;
                margin: 1px 0px;
                border-radius: 4px;
                background-color: transparent;
                border: none;
            }
            QListWidget::item:hover {
                background-color: #f0f7ff;
                color: #1976d2;
            }
            QListWidget::item:selected {
                background-color: #1976d2;
                color: white;
            }
            QPushButton {
                background-color: #1976d2;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 6px 12px;
                font-size: 11px;
                font-weight: 500;
                min-width: 60px;
                min-height: 28px;
            }
            QPushButton:hover {
                background-color: #1565c0;
            }
            QPushButton#cancelButton {
                background-color: #f5f5f5;
                color: #757575;
                border: 1px solid #e0e0e0;
            }
            QPushButton#cancelButton:hover {
                background-color: #eeeeee;
                color: #424242;
            }
        """)

        layout = QVBoxLayout(browser_dialog)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        path_label = QLabel(f"Select a {file_types} file:")
        layout.addWidget(path_label)

        # Enhanced USB Detection
        current_usb_devices = USBDetector.get_usb_devices()
        current_usb_index = 0
        
        if current_usb_devices:
            device_info = f"{current_usb_devices[0]['name']} ({current_usb_devices[0]['user']})"
            usb_label = QLabel(f"🔌 USB: {device_info} - Click to switch")
            usb_label.setObjectName("usbLabel")
            
            def switch_usb():
                nonlocal current_usb_index
                if len(current_usb_devices) > 1:
                    current_usb_index = (current_usb_index + 1) % len(current_usb_devices)
                    device = current_usb_devices[current_usb_index]
                    device_info = f"{device['name']} ({device['user']})"
                    usb_label.setText(f"🔌 USB: {device_info} - Click to switch")
                    load_usb_files()
            
            usb_label.mousePressEvent = lambda event: switch_usb()
            layout.addWidget(usb_label)
        else:
            usb_label = QLabel("🔌 No USB devices found")
            usb_label.setObjectName("usbLabel")
            layout.addWidget(usb_label)

        # Common locations
        locations_widget = QWidget()
        locations_layout = QHBoxLayout(locations_widget)
        locations_layout.setContentsMargins(0, 0, 0, 0)

        home_btn = QPushButton("Home")
        desktop_btn = QPushButton("Desktop")
        pictures_btn = QPushButton("Pictures" if file_types == "image" else "Videos")
        downloads_btn = QPushButton("Downloads")

        locations_layout.addWidget(home_btn)
        locations_layout.addWidget(desktop_btn)
        locations_layout.addWidget(pictures_btn)
        locations_layout.addWidget(downloads_btn)
        locations_layout.addStretch()

        layout.addWidget(locations_widget)

        # File list
        file_list = QListWidget()
        file_list.setMaximumHeight(220)
        layout.addWidget(file_list)

        current_path = os.path.expanduser("~")

        def load_usb_files():
            """Load files from current USB device"""
            if current_usb_devices and current_usb_index < len(current_usb_devices):
                device = current_usb_devices[current_usb_index]
                media_files = USBDetector.get_media_files_from_usb(device['path'], file_types)

                file_list.clear()
                if media_files:
                    path_label.setText(f"USB: {device['name']} - {file_types} files ({len(media_files)} found)")
                    for media_file in media_files:
                        size_str = USBDetector.format_file_size(media_file['size'])
                        display_name = f"{file_icon} {media_file['name']} ({size_str})"
                        item = QListWidgetItem(display_name)
                        item.setData(Qt.UserRole, media_file['path'])
                        file_list.addItem(item)
                else:
                    folder_names = "images/pictures" if file_types == "image" else "videos/movies"
                    path_label.setText(f"USB: {device['name']} - No {file_types} files found")
                    item = QListWidgetItem(f"No {file_types} files found in /{folder_names} folders")
                    item.setData(Qt.UserRole, None)
                    file_list.addItem(item)

        def update_file_list(path):
            nonlocal current_path
            current_path = path
            file_list.clear()

            try:
                if os.path.exists(path) and os.path.isdir(path):
                    path_label.setText(f"Current folder: {os.path.basename(path) or path}")

                    # Add parent directory
                    parent_dir = os.path.dirname(path)
                    if parent_dir != path:
                        item = QListWidgetItem("📁 .. (Parent Directory)")
                        item.setData(Qt.UserRole, parent_dir)
                        file_list.addItem(item)

                    # List directories and media files
                    items = []
                    try:
                        for item_name in os.listdir(path):
                            item_path = os.path.join(path, item_name)
                            if os.path.isdir(item_path):
                                items.append((f"📁 {item_name}/", item_path, True))
                            elif item_name.lower().endswith(extensions):
                                items.append((f"{file_icon} {item_name}", item_path, False))
                    except PermissionError:
                        path_label.setText(f"Permission denied: {path}")
                        return

                    # Sort: directories first, then files
                    items.sort(key=lambda x: (not x[2], x[0].lower()))

                    for display_name, full_path, is_dir in items:
                        item = QListWidgetItem(display_name)
                        item.setData(Qt.UserRole, full_path)
                        file_list.addItem(item)

            except PermissionError:
                path_label.setText(f"Permission denied: {path}")
            except Exception as e:
                path_label.setText(f"Error accessing: {path} - {str(e)}")

        def on_location_click(location):
            home = os.path.expanduser("~")
            locations = {
                "Home": home,
                "Desktop": os.path.join(home, "Desktop"),
                "Pictures": os.path.join(home, "Pictures"),
                "Videos": os.path.join(home, "Videos"),
                "Downloads": os.path.join(home, "Downloads")
            }
            target = locations.get(location)
            if target and os.path.exists(target):
                update_file_list(target)

        # Event connections
        home_btn.clicked.connect(lambda: on_location_click("Home"))
        desktop_btn.clicked.connect(lambda: on_location_click("Desktop"))
        pictures_btn.clicked.connect(lambda: on_location_click("Pictures" if file_types == "image" else "Videos"))
        downloads_btn.clicked.connect(lambda: on_location_click("Downloads"))

        def on_item_double_click(item):
            path = item.data(Qt.UserRole)
            if path and os.path.isdir(path):
                update_file_list(path)
            elif path and os.path.isfile(path):
                browser_dialog.selected_file = path
                browser_dialog.accept()

        file_list.itemDoubleClicked.connect(on_item_double_click)

        # Buttons
        button_layout = QHBoxLayout()
        cancel_btn = QPushButton("Cancel")
        cancel_btn.setObjectName("cancelButton")
        select_btn = QPushButton("Select")

        def on_select():
            current_item = file_list.currentItem()
            if current_item:
                path = current_item.data(Qt.UserRole)
                if path and not os.path.isdir(path) and path.lower().endswith(extensions):
                    browser_dialog.selected_file = path
                    browser_dialog.accept()
                else:
                    QMessageBox.information(browser_dialog, "Invalid Selection", 
                                          f"Please select a {file_types} file.")
            else:
                QMessageBox.information(browser_dialog, "No Selection", "Please select a file.")

        cancel_btn.clicked.connect(browser_dialog.reject)
        select_btn.clicked.connect(on_select)

        button_layout.addStretch()
        button_layout.addWidget(cancel_btn)
        button_layout.addWidget(select_btn)

        layout.addLayout(button_layout)

        # Initialize
        browser_dialog.selected_file = None
        if current_usb_devices:
            load_usb_files()
        else:
            update_file_list(current_path)

        if browser_dialog.exec_() == QDialog.Accepted:
            return browser_dialog.selected_file
        return None

    @staticmethod
    def show_image_selection_dialog(parent, image_folder, title="Select Image", enable_add=True):
        """Enhanced image selection with robust USB support"""
        if not os.path.exists(image_folder):
            os.makedirs(image_folder)

        dialog = QDialog(parent)
        dialog.setWindowTitle(title)
        dialog.setFixedSize(380, 450)
        dialog.setWindowFlags(Qt.Dialog | Qt.WindowCloseButtonHint)

        dialog.setStyleSheet("""
            QDialog {
                background-color: #ffffff;
                border: 1px solid #e0e0e0;
                border-radius: 8px;
            }
            QLabel {
                color: #2c3e50;
                font-size: 14px;
                font-weight: 600;
                padding: 8px 0px;
                background: transparent;
                border: none;
            }
            QLabel#usbLabel {
                background-color: #e8f5e8;
                border: 1px solid #4caf50;
                border-radius: 4px;
                padding: 8px 12px;
                color: #2e7d32;
                font-weight: 600;
                font-size: 12px;
            }
            QLabel#usbLabel:hover {
                background-color: #c8e6c9;
                cursor: pointer;
            }
            QListWidget {
                background-color: #fafafa;
                border: 1px solid #e0e0e0;
                border-radius: 6px;
                font-size: 12px;
                color: #2c3e50;
                padding: 4px;
                outline: none;
            }
            QListWidget::item {
                padding: 8px 12px;
                margin: 1px 0px;
                border-radius: 4px;
                background-color: transparent;
                border: none;
            }
            QListWidget::item:hover {
                background-color: #f0f7ff;
                color: #1976d2;
            }
            QListWidget::item:selected {
                background-color: #1976d2;
                color: white;
            }
            QPushButton {
                background-color: #1976d2;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px 16px;
                font-size: 12px;
                font-weight: 500;
                min-width: 70px;
                min-height: 32px;
            }
            QPushButton:hover {
                background-color: #1565c0;
            }
            QPushButton#cancelButton {
                background-color: #f5f5f5;
                color: #757575;
                border: 1px solid #e0e0e0;
            }
            QPushButton#cancelButton:hover {
                background-color: #eeeeee;
                color: #424242;
            }
            QPushButton#addButton {
                background-color: #4caf50;
                color: white;
            }
            QPushButton#addButton:hover {
                background-color: #45a049;
            }
        """)

        layout = QVBoxLayout(dialog)
        layout.setSpacing(12)
        layout.setContentsMargins(16, 16, 16, 16)

        header_label = QLabel(title)
        header_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(header_label)

        # Enhanced USB section
        current_usb_devices = USBDetector.get_usb_devices()
        current_usb_index = 0
        
        if current_usb_devices:
            device_name = current_usb_devices[0]['name']
            usb_label = QLabel(f"🔌 USB: {device_name} - Click to switch")
            usb_label.setObjectName("usbLabel")
            
            def switch_usb():
                nonlocal current_usb_index
                if len(current_usb_devices) > 1:
                    current_usb_index = (current_usb_index + 1) % len(current_usb_devices)
                    device = current_usb_devices[current_usb_index]
                    usb_label.setText(f"🔌 USB: {device['name']} - Click to switch")
                    refresh_list()
            
            usb_label.mousePressEvent = lambda event: switch_usb()
            layout.addWidget(usb_label)

        list_widget = QListWidget(dialog)
        list_widget.setMaximumHeight(200)

        def refresh_list():
            list_widget.clear()
            
            # Local files
            local_files = [f for f in os.listdir(image_folder) 
                          if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
            for f in sorted(local_files):
                item = QListWidgetItem(f"🖼️ {f}")
                item.setData(Qt.UserRole, os.path.join(image_folder, f))
                list_widget.addItem(item)
            
            # USB files
            if current_usb_devices and current_usb_index < len(current_usb_devices):
                device = current_usb_devices[current_usb_index]
                media_files = USBDetector.get_media_files_from_usb(device['path'], "image")
                
                for media_file in media_files:
                    size_str = USBDetector.format_file_size(media_file['size'])
                    display_name = f"🔌 {media_file['name']} ({size_str})"
                    item = QListWidgetItem(display_name)
                    item.setData(Qt.UserRole, media_file['path'])
                    list_widget.addItem(item)

        refresh_list()
        layout.addWidget(list_widget)

        # Add button
        if enable_add:
            button_row = QHBoxLayout()
            add_button = QPushButton("Add from Computer")
            add_button.setObjectName("addButton")
            button_row.addWidget(add_button)
            button_row.addStretch()
            layout.addLayout(button_row)

            def on_add_image():
                try:
                    file_path = ImageManager.show_file_browser(dialog, "Select Image to Add", "image")
                    if file_path and os.path.exists(file_path):
                        if not file_path.startswith('/media/'):
                            filename = ImageManager.copy_image_to_folder(file_path, image_folder)
                            if filename:
                                refresh_list()
                                for i in range(list_widget.count()):
                                    item_data = list_widget.item(i).data(Qt.UserRole)
                                    if item_data and item_data.endswith(filename):
                                        list_widget.setCurrentRow(i)
                                        break
                        else:
                            QMessageBox.information(dialog, "USB File", 
                                                  "USB files are used directly without copying.")
                except Exception as e:
                    QMessageBox.warning(dialog, "Error", f"Failed to add image: {str(e)}")

            add_button.clicked.connect(on_add_image)

        # Bottom buttons
        button_layout = QHBoxLayout()
        button_layout.setSpacing(8)
        cancel_button = QPushButton("Cancel")
        cancel_button.setObjectName("cancelButton")
        select_button = QPushButton("Select")

        button_layout.addStretch()
        button_layout.addWidget(cancel_button)
        button_layout.addWidget(select_button)
        layout.addLayout(button_layout)

        selected_file = None

        def on_select_clicked():
            nonlocal selected_file
            current_item = list_widget.currentItem()
            if current_item:
                selected_file = current_item.data(Qt.UserRole)
                dialog.accept()
            else:
                QMessageBox.information(dialog, "No Selection", "Please select an image first.")

        def on_item_double_clicked(item):
            nonlocal selected_file
            selected_file = item.data(Qt.UserRole)
            dialog.accept()

        select_button.clicked.connect(on_select_clicked)
        cancel_button.clicked.connect(dialog.reject)
        list_widget.itemDoubleClicked.connect(on_item_double_clicked)

        if list_widget.count() > 0:
            list_widget.setCurrentRow(0)

        if dialog.exec_() == QDialog.Accepted:
            return selected_file
        return None

    @staticmethod
    def show_video_selection_dialog(parent, video_folder, title="Select Video", enable_add=True):
        """Enhanced video selection with robust USB support"""
        # Similar to image dialog but for videos
        # Implementation follows same pattern as show_image_selection_dialog
        # but with video-specific extensions and folder names
        
        if not os.path.exists(video_folder):
            os.makedirs(video_folder)

        video_extensions = ('.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv', '.webm', '.m4v')

        dialog = QDialog(parent)
        dialog.setWindowTitle(title)
        dialog.setFixedSize(420, 480)
        dialog.setWindowFlags(Qt.Dialog | Qt.WindowCloseButtonHint)

        # Styling (same as image dialog)
        dialog.setStyleSheet("""
            QDialog {
                background-color: #ffffff;
                border: 1px solid #e0e0e0;
                border-radius: 8px;
            }
            QLabel {
                color: #2c3e50;
                font-size: 14px;
                font-weight: 600;
                padding: 8px 0px;
                background: transparent;
                border: none;
            }
            QLabel#usbLabel {
                background-color: #fff3e0;
                border: 1px solid #ff9800;
                border-radius: 4px;
                padding: 8px 12px;
                color: #e65100;
                font-weight: 600;
                font-size: 12px;
            }
            QLabel#usbLabel:hover {
                background-color: #ffe0b2;
                cursor: pointer;
            }
            QListWidget {
                background-color: #fafafa;
                border: 1px solid #e0e0e0;
                border-radius: 6px;
                font-size: 12px;
                color: #2c3e50;
                padding: 4px;
                outline: none;
            }
            QListWidget::item {
                padding: 10px 12px;
                margin: 1px 0px;
                border-radius: 4px;
                background-color: transparent;
                border: none;
            }
            QListWidget::item:hover {
                background-color: #f0f7ff;
                color: #1976d2;
            }
            QListWidget::item:selected {
                background-color: #1976d2;
                color: white;
            }
            QPushButton {
                background-color: #1976d2;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px 16px;
                font-size: 12px;
                font-weight: 500;
                min-width: 70px;
                min-height: 32px;
            }
            QPushButton:hover {
                background-color: #1565c0;
            }
            QPushButton#cancelButton {
                background-color: #f5f5f5;
                color: #757575;
                border: 1px solid #e0e0e0;
            }
            QPushButton#cancelButton:hover {
                background-color: #eeeeee;
                color: #424242;
            }
            QPushButton#addButton {
                background-color: #ff9800;
                color: white;
            }
            QPushButton#addButton:hover {
                background-color: #f57c00;
            }
        """)

        layout = QVBoxLayout(dialog)
        layout.setSpacing(12)
        layout.setContentsMargins(16, 16, 16, 16)

        header_label = QLabel(title)
        header_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(header_label)

        # USB section
        current_usb_devices = USBDetector.get_usb_devices()
        current_usb_index = 0
        
        if current_usb_devices:
            device_name = current_usb_devices[0]['name']
            usb_label = QLabel(f"📹 USB: {device_name} - Click to switch")
            usb_label.setObjectName("usbLabel")
            
            def switch_usb():
                nonlocal current_usb_index
                if len(current_usb_devices) > 1:
                    current_usb_index = (current_usb_index + 1) % len(current_usb_devices)
                    device = current_usb_devices[current_usb_index]
                    usb_label.setText(f"📹 USB: {device['name']} - Click to switch")
                    refresh_list()
            
            usb_label.mousePressEvent = lambda event: switch_usb()
            layout.addWidget(usb_label)

        list_widget = QListWidget(dialog)
        list_widget.setMaximumHeight(230)

        def refresh_list():
            list_widget.clear()
            
            # Local files
            local_files = [f for f in os.listdir(video_folder) 
                          if f.lower().endswith(video_extensions)]
            for f in sorted(local_files):
                item = QListWidgetItem(f"📹 {f}")
                item.setData(Qt.UserRole, os.path.join(video_folder, f))
                list_widget.addItem(item)
            
            # USB files
            if current_usb_devices and current_usb_index < len(current_usb_devices):
                device = current_usb_devices[current_usb_index]
                media_files = USBDetector.get_media_files_from_usb(device['path'], "video")
                
                for media_file in media_files:
                    size_str = USBDetector.format_file_size(media_file['size'])
                    display_name = f"🔌 {media_file['name']} ({size_str})"
                    item = QListWidgetItem(display_name)
                    item.setData(Qt.UserRole, media_file['path'])
                    list_widget.addItem(item)

        refresh_list()
        layout.addWidget(list_widget)

        # Add video button
        if enable_add:
            button_row = QHBoxLayout()
            add_button = QPushButton("Add from Computer")
            add_button.setObjectName("addButton")
            button_row.addWidget(add_button)
            button_row.addStretch()
            layout.addLayout(button_row)

            def on_add_video():
                try:
                    file_path = ImageManager.show_file_browser(dialog, "Select Video to Add", "video")
                    if file_path and os.path.exists(file_path):
                        if not file_path.startswith('/media/'):
                            if file_path.lower().endswith(video_extensions):
                                filename = ImageManager.copy_image_to_folder(file_path, video_folder)
                                if filename:
                                    refresh_list()
                                    for i in range(list_widget.count()):
                                        item_data = list_widget.item(i).data(Qt.UserRole)
                                        if item_data and item_data.endswith(filename):
                                            list_widget.setCurrentRow(i)
                                            break
                            else:
                                QMessageBox.warning(dialog, "Invalid Format",
                                    "Selected file is not a supported video format.\n"
                                    "Supported formats: MP4, AVI, MOV, MKV, WMV, FLV, WEBM, M4V")
                        else:
                            QMessageBox.information(dialog, "USB File", 
                                                  "USB files are used directly without copying.")
                except Exception as e:
                    QMessageBox.warning(dialog, "Error", f"Failed to add video: {str(e)}")

            add_button.clicked.connect(on_add_video)

        # Bottom buttons
        button_layout = QHBoxLayout()
        button_layout.setSpacing(8)
        cancel_button = QPushButton("Cancel")
        cancel_button.setObjectName("cancelButton")
        select_button = QPushButton("Select")

        button_layout.addStretch()
        button_layout.addWidget(cancel_button)
        button_layout.addWidget(select_button)
        layout.addLayout(button_layout)

        selected_file = None

        def on_select_clicked():
            nonlocal selected_file
            current_item = list_widget.currentItem()
            if current_item:
                selected_file = current_item.data(Qt.UserRole)
                dialog.accept()
            else:
                QMessageBox.information(dialog, "No Selection", "Please select a video first.")

        def on_item_double_clicked(item):
            nonlocal selected_file
            selected_file = item.data(Qt.UserRole)
            dialog.accept()

        select_button.clicked.connect(on_select_clicked)
        cancel_button.clicked.connect(dialog.reject)
        list_widget.itemDoubleClicked.connect(on_item_double_clicked)

        if list_widget.count() > 0:
            list_widget.setCurrentRow(0)

        if dialog.exec_() == QDialog.Accepted:
            return selected_file
        return None
