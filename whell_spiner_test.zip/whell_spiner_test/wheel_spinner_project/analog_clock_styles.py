import math
from PyQt5.QtCore import Qt, QTime, QPoint, QPointF
from PyQt5.QtGui import QPainter, QColor, QFont, QPen, QBrush, QPolygon, QLinearGradient, QRadialGradient


class AnalogClockStyles:
    """Analog clock style implementations"""
    
    @staticmethod
    def draw_modern_analog(painter, config, center, radius):
        """Modern style analog clock"""
        # Modern hour markers
        painter.setPen(QPen(config['clock_color'], 3))
        for i in range(12):
            angle = i * 30 - 90
            angle_rad = math.radians(angle)
            
            # Different lengths for 12, 3, 6, 9
            if i % 3 == 0:
                inner_radius = radius - 25
                marker_width = 4
            else:
                inner_radius = radius - 15
                marker_width = 2
            
            painter.setPen(QPen(config['clock_color'], marker_width))
            
            x1 = center.x() + inner_radius * math.cos(angle_rad)
            y1 = center.y() + inner_radius * math.sin(angle_rad)
            x2 = center.x() + (radius - 5) * math.cos(angle_rad)
            y2 = center.y() + (radius - 5) * math.sin(angle_rad)
            painter.drawLine(int(x1), int(y1), int(x2), int(y2))
        
        # Numbers (if enabled) - LARGER SIZE
        if config['show_numbers']:
            font = QFont("Arial", 50, QFont.Bold)  # Increased to 32
            painter.setFont(font)
            painter.setPen(QPen(config['clock_color'], 2))
            
            for i in range(1, 13):
                angle = (i * 30) - 90
                angle_rad = math.radians(angle)
                x = center.x() + (radius - 60) * math.cos(angle_rad)  # More outward
                y = center.y() + (radius - 60) * math.sin(angle_rad)
                
                rect = painter.fontMetrics().boundingRect(str(i))
                painter.drawText(int(x - rect.width()/2), int(y + rect.height()/2), str(i))
    
    @staticmethod
    def draw_classic_analog(painter, config, center, radius):
        """Classic style analog clock"""
        # Classic Roman numerals - LARGER SIZE
        if config['show_numbers']:
            roman_nums = ["XII", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI"]
            font = QFont("Times New Roman", 45, QFont.Bold)  # Increased to 34
            painter.setFont(font)
            painter.setPen(QPen(config['clock_color'], 2))
            
            for i, num in enumerate(roman_nums):
                angle = i * 30 - 90
                angle_rad = math.radians(angle)
                x = center.x() + (radius - 65) * math.cos(angle_rad)  # More outward
                y = center.y() + (radius - 65) * math.sin(angle_rad)
                
                rect = painter.fontMetrics().boundingRect(num)
                painter.drawText(int(x - rect.width()/2), int(y + rect.height()/2), num)
        
        # Classic hour markers
        painter.setPen(QPen(config['clock_color'], 2))
        for i in range(60):
            angle = i * 6 - 90
            angle_rad = math.radians(angle)
            
            if i % 15 == 0:  # Main hours
                inner_radius = radius - 20
                width = 3
            elif i % 5 == 0:  # 5-minute marks
                inner_radius = radius - 12
                width = 2
            else:  # Minute marks
                inner_radius = radius - 8
                width = 1
            
            painter.setPen(QPen(config['clock_color'], width))
            x1 = center.x() + inner_radius * math.cos(angle_rad)
            y1 = center.y() + inner_radius * math.sin(angle_rad)
            x2 = center.x() + (radius - 3) * math.cos(angle_rad)
            y2 = center.y() + (radius - 3) * math.sin(angle_rad)
            painter.drawLine(int(x1), int(y1), int(x2), int(y2))
    
    @staticmethod
    def draw_elegant_analog(painter, config, center, radius):
        """Elegant style analog clock"""
        # Elegant diamonds for hour markers
        painter.setBrush(QBrush(config['clock_color']))
        painter.setPen(QPen(config['clock_color'], 1))
        
        for i in range(12):
            angle = i * 30 - 90
            angle_rad = math.radians(angle)
            
            x = center.x() + (radius - 15) * math.cos(angle_rad)
            y = center.y() + (radius - 15) * math.sin(angle_rad)
            
            if i % 3 == 0:  # Main hours - larger diamonds
                size = 8
            else:
                size = 5
            
            # Draw diamond
            diamond_points = [
                QPoint(int(x), int(y - size)),  # top
                QPoint(int(x + size), int(y)),  # right
                QPoint(int(x), int(y + size)),  # bottom
                QPoint(int(x - size), int(y))   # left
            ]
            diamond_polygon = QPolygon(diamond_points)
            painter.drawPolygon(diamond_polygon)
        
        # Elegant numbers - LARGER SIZE
        if config['show_numbers']:
            font = QFont("Georgia", 45, QFont.Normal)  # Increased to 30
            painter.setFont(font)
            painter.setPen(QPen(config['clock_color'], 1))
            
            for i in range(1, 13):
                angle = (i * 30) - 90
                angle_rad = math.radians(angle)
                x = center.x() + (radius - 60) * math.cos(angle_rad)  # More outward
                y = center.y() + (radius - 75) * math.sin(angle_rad)
                
                rect = painter.fontMetrics().boundingRect(str(i))
                painter.drawText(int(x - rect.width()/2), int(y + rect.height()/2), str(i))
    
    @staticmethod
    def draw_industrial_analog(painter, config, center, radius):
        """Industrial style analog clock"""
        # Industrial bolts/screws as markers
        painter.setBrush(QBrush(QColor(120, 120, 120)))
        painter.setPen(QPen(QColor(80, 80, 80), 2))
        
        for i in range(12):
            angle = i * 30 - 90
            angle_rad = math.radians(angle)
            
            x = center.x() + (radius - 15) * math.cos(angle_rad)
            y = center.y() + (radius - 15) * math.sin(angle_rad)
            
            if i % 3 == 0:  # Main hours - larger bolts
                bolt_radius = 6
            else:
                bolt_radius = 4
            
            # Draw bolt
            painter.drawEllipse(int(x - bolt_radius), int(y - bolt_radius), 
                              bolt_radius * 2, bolt_radius * 2)
            
            # Cross on bolt
            painter.setPen(QPen(QColor(60, 60, 60), 1))
            painter.drawLine(int(x - bolt_radius + 2), int(y), 
                           int(x + bolt_radius - 2), int(y))
            painter.drawLine(int(x), int(y - bolt_radius + 2), 
                           int(x), int(y + bolt_radius - 2))
            painter.setPen(QPen(QColor(80, 80, 80), 2))
        
        # Industrial numbers - LARGER SIZE
        if config['show_numbers']:
            font = QFont("Arial Black", 40, QFont.Bold)  # Increased to 30
            painter.setFont(font)
            painter.setPen(QPen(QColor(200, 200, 200), 2))
            
            for i in range(1, 13):
                angle = (i * 30) - 90
                angle_rad = math.radians(angle)
                x = center.x() + (radius - 65) * math.cos(angle_rad)  # More outward
                y = center.y() + (radius - 65) * math.sin(angle_rad)
                
                rect = painter.fontMetrics().boundingRect(str(i))
                painter.drawText(int(x - rect.width()/2), int(y + rect.height()/2), str(i))
    
    @staticmethod
    def draw_neon_analog(painter, config, center, radius, pulse_value):
        """Neon style analog clock"""
        # Neon hour markers with glow
        for i in range(12):
            angle = i * 30 - 90
            angle_rad = math.radians(angle)
            
            x1 = center.x() + (radius - 20) * math.cos(angle_rad)
            y1 = center.y() + (radius - 20) * math.sin(angle_rad)
            x2 = center.x() + (radius - 5) * math.cos(angle_rad)
            y2 = center.y() + (radius - 5) * math.sin(angle_rad)
            
            # Glow effect
            for j in range(5, 0, -1):
                glow_color = QColor(config['clock_color'])
                glow_color.setAlpha(30 + int(10 * pulse_value))
                painter.setPen(QPen(glow_color, j * 2))
                painter.drawLine(int(x1), int(y1), int(x2), int(y2))
            
            # Main line
            painter.setPen(QPen(Qt.white, 2))
            painter.drawLine(int(x1), int(y1), int(x2), int(y2))
        
        # Neon numbers with glow - LARGER SIZE
        if config['show_numbers']:
            font = QFont("Arial", 40, QFont.Bold)  # Increased to 32
            painter.setFont(font)
            
            for i in range(1, 13):
                angle = (i * 30) - 90
                angle_rad = math.radians(angle)
                x = center.x() + (radius - 60) * math.cos(angle_rad)  # More outward
                y = center.y() + (radius - 60) * math.sin(angle_rad)
                
                # Glow effect
                for j in range(3, 0, -1):
                    glow_color = QColor(config['clock_color'])
                    glow_color.setAlpha(50)
                    painter.setPen(QPen(glow_color, j * 2))
                    rect = painter.fontMetrics().boundingRect(str(i))
                    painter.drawText(int(x - rect.width()/2), int(y + rect.height()/2), str(i))
                
                # Main number
                painter.setPen(QPen(Qt.white, 1))
                rect = painter.fontMetrics().boundingRect(str(i))
                painter.drawText(int(x - rect.width()/2), int(y + rect.height()/2), str(i))
    
    @staticmethod
    def draw_luxury_analog(painter, config, center, radius):
        """Luxury watch style analog clock"""
        # NOT: Arka plan resmi/rengi zaten ClockUtils.draw_background() ile çizildiği için
        # burada sadece dekoratif elementleri çiziyoruz
        
        # Luxury gold border ring (arka planı kapatmayacak şekilde)
        painter.setBrush(Qt.NoBrush)  # İçi boş, sadece kenarlık
        painter.setPen(QPen(QColor(218, 165, 32), 4))  # Gold border
        painter.drawEllipse(center, int(radius * 0.98), int(radius * 0.98))
        
        # İnce iç kenarlık
        painter.setPen(QPen(QColor(184, 134, 11), 2))  # Dark gold
        painter.drawEllipse(center, int(radius * 0.92), int(radius * 0.92))
        
        # Luxury hour markers - jewels
        for i in range(12):
            angle = i * 30 - 90
            angle_rad = math.radians(angle)
            
            x = center.x() + (radius - 20) * math.cos(angle_rad)
            y = center.y() + (radius - 20) * math.sin(angle_rad)
            
            if i % 3 == 0:  # Main hours - larger jewels
                jewel_size = 10
                jewel_color = QColor(220, 20, 60)  # Crimson
            else:
                jewel_size = 6
                jewel_color = QColor(70, 130, 180)  # Steel blue
            
            # Draw jewel with gradient
            jewel_gradient = QRadialGradient(QPointF(x, y), jewel_size)
            jewel_gradient.setColorAt(0, jewel_color.lighter(150))
            jewel_gradient.setColorAt(0.5, jewel_color)
            jewel_gradient.setColorAt(1, jewel_color.darker(150))
            
            painter.setBrush(QBrush(jewel_gradient))
            painter.setPen(QPen(QColor(139, 69, 19), 1))
            painter.drawEllipse(int(x - jewel_size/2), int(y - jewel_size/2), 
                              jewel_size, jewel_size)
        
        # Luxury numbers - gold embossed
        if config['show_numbers']:
            font = QFont("Bodoni MT", 45, QFont.Bold)  # Increased to 36
            painter.setFont(font)
            
            for i in range(1, 13):
                angle = (i * 30) - 90
                angle_rad = math.radians(angle)
                x = center.x() + (radius - 70) * math.cos(angle_rad)  # Much more outward
                y = center.y() + (radius - 70) * math.sin(angle_rad)
                
                # Shadow effect
                painter.setPen(QPen(QColor(0, 0, 0, 100), 2))
                rect = painter.fontMetrics().boundingRect(str(i))
                painter.drawText(int(x - rect.width()/2 + 2), int(y + rect.height()/2 + 2), str(i))
                
                # Main number
                painter.setPen(QPen(QColor(255, 215, 0), 2))  # Gold
                painter.drawText(int(x - rect.width()/2), int(y + rect.height()/2), str(i))
    
    @staticmethod
    def draw_minimalist_analog(painter, config, center, radius):
        """Minimalist style analog clock"""
        # Only show 12, 3, 6, 9
        painter.setPen(QPen(config['clock_color'], 2))
        
        for i in [0, 3, 6, 9]:  # Only quarters
            angle = i * 30 - 90
            angle_rad = math.radians(angle)
            
            # Small dots instead of lines
            x = center.x() + (radius - 15) * math.cos(angle_rad)
            y = center.y() + (radius - 15) * math.sin(angle_rad)
            
            painter.setBrush(QBrush(config['clock_color']))
            painter.drawEllipse(int(x - 3), int(y - 3), 6, 6)
        
        # Minimalist numbers - only quarters
        if config['show_numbers']:
            font = QFont("Helvetica Neue", 40, QFont.Light)  # Increased to 38
            painter.setFont(font)
            painter.setPen(QPen(config['clock_color'], 1))
            
            numbers = {0: "12", 3: "3", 6: "6", 9: "9"}
            for i, num in numbers.items():
                angle = i * 30 - 90
                angle_rad = math.radians(angle)
                x = center.x() + (radius - 65) * math.cos(angle_rad)  # More outward
                y = center.y() + (radius - 65) * math.sin(angle_rad)
                
                rect = painter.fontMetrics().boundingRect(num)
                painter.drawText(int(x - rect.width()/2), int(y + rect.height()/2), num)
    
    @staticmethod
    def draw_retro_analog(painter, config, center, radius):
        """Retro 70s style analog clock"""
        # Retro orange/brown color scheme
        retro_colors = [QColor(255, 140, 0, 80), QColor(255, 69, 0, 80), QColor(139, 69, 19, 80)]
        
        # Retro sunburst pattern - yarı saydam olarak çiz
        for i in range(24):
            angle = i * 15 - 90
            angle_rad = math.radians(angle)
            
            if i % 2 == 0:
                painter.setBrush(QBrush(retro_colors[i % 3]))  # Yarı saydam renkler
                painter.setPen(Qt.NoPen)
                
                # Triangle rays
                points = [
                    center,
                    QPoint(int(center.x() + radius * math.cos(angle_rad)), 
                          int(center.y() + radius * math.sin(angle_rad))),
                    QPoint(int(center.x() + radius * math.cos(angle_rad + math.radians(15))), 
                          int(center.y() + radius * math.sin(angle_rad + math.radians(15))))
                ]
                painter.drawPolygon(QPolygon(points))
        
        # Inner circle - yarı saydam
        painter.setBrush(QBrush(QColor(255, 228, 181, 100)))  # Moccasin with transparency
        painter.setPen(QPen(QColor(139, 69, 19), 3))
        painter.drawEllipse(center, int(radius * 0.7), int(radius * 0.7))
        
        # Retro numbers - groovy font
        if config['show_numbers']:
            font = QFont("Cooper Black", 45, QFont.Bold)  # Increased to 34
            painter.setFont(font)
            painter.setPen(QPen(QColor(139, 69, 19), 2))
            
            for i in range(1, 13):
                angle = (i * 30) - 90
                angle_rad = math.radians(angle)
                x = center.x() + (radius - 50) * math.cos(angle_rad)  # Much more outward
                y = center.y() + (radius - 70) * math.sin(angle_rad)
                
                rect = painter.fontMetrics().boundingRect(str(i))
                painter.drawText(int(x - rect.width()/2), int(y + rect.height()/2), str(i))
    
    @staticmethod
    def draw_art_deco_analog(painter, config, center, radius):
        """Art Deco style analog clock"""
        # Art Deco geometric patterns - sadece dekoratif çizgiler
        painter.setPen(QPen(config['clock_color'], 2))
        painter.setBrush(Qt.NoBrush)  # İçi boş
        
        # Concentric circles
        for i in range(3):
            circle_radius = radius - (i * 15)
            painter.drawEllipse(center, circle_radius, circle_radius)
        
        # Art Deco hour markers - geometric shapes
        for i in range(12):
            angle = i * 30 - 90
            angle_rad = math.radians(angle)
            
            x = center.x() + (radius - 25) * math.cos(angle_rad)
            y = center.y() + (radius - 25) * math.sin(angle_rad)
            
            if i % 3 == 0:  # Main hours - Art Deco triangles
                size = 12
                # Draw triangle pointing outward
                points = [
                    QPoint(int(x), int(y)),
                    QPoint(int(x - size/2 * math.sin(angle_rad)), 
                          int(y + size/2 * math.cos(angle_rad))),
                    QPoint(int(x + size/2 * math.sin(angle_rad)), 
                          int(y - size/2 * math.cos(angle_rad)))
                ]
                painter.setBrush(QBrush(config['clock_color']))
                painter.drawPolygon(QPolygon(points))
            else:
                # Small rectangles
                painter.setBrush(QBrush(config['clock_color']))
                painter.save()
                painter.translate(x, y)
                painter.rotate(angle + 90)
                painter.drawRect(-2, -8, 4, 16)
                painter.restore()
        
        # Art Deco numbers - geometric font
        if config['show_numbers']:
            font = QFont("Broadway", 32, QFont.Bold)  # Increased to 32
            painter.setFont(font)
            painter.setPen(QPen(config['clock_color'], 2))
            
            for i in range(1, 13):
                angle = (i * 30) - 90
                angle_rad = math.radians(angle)
                x = center.x() + (radius - 70) * math.cos(angle_rad)  # Much more outward
                y = center.y() + (radius - 70) * math.sin(angle_rad)
                
                rect = painter.fontMetrics().boundingRect(str(i))
                painter.drawText(int(x - rect.width()/2), int(y + rect.height()/2), str(i))
    
    @staticmethod
    def draw_steampunk_analog(painter, config, center, radius):
        """Steampunk style analog clock"""
        # Brass/copper color scheme
        brass_color = QColor(181, 166, 66)
        copper_color = QColor(184, 115, 51)
        
        # Gear teeth around the edge - yarı saydam
        painter.setPen(QPen(brass_color, 2))
        painter.setBrush(QBrush(QColor(184, 115, 51, 100)))  # Yarı saydam copper
        
        for i in range(60):
            angle = i * 6 - 90
            angle_rad = math.radians(angle)
            
            if i % 5 == 0:  # Larger gear teeth
                tooth_width = 8
                tooth_height = 15
            else:
                tooth_width = 4
                tooth_height = 8
            
            x = center.x() + (radius - tooth_height/2) * math.cos(angle_rad)
            y = center.y() + (radius - tooth_height/2) * math.sin(angle_rad)
            
            painter.save()
            painter.translate(x, y)
            painter.rotate(angle + 90)
            painter.drawRect(int(-tooth_width/2), int(-tooth_height/2), 
                           tooth_width, tooth_height)
            painter.restore()
        
        # Inner brass circle - yarı saydam
        painter.setBrush(QBrush(QColor(181, 166, 66, 50)))  # Yarı saydam brass
        painter.setPen(QPen(brass_color, 3))
        painter.drawEllipse(center, int(radius * 0.85), int(radius * 0.85))
        
        # Steampunk rivets
        painter.setBrush(QBrush(QColor(105, 105, 105)))  # Dim gray
        painter.setPen(QPen(QColor(47, 79, 79), 1))  # Dark slate gray
        
        for i in range(8):
            angle = i * 45
            angle_rad = math.radians(angle)
            rivet_x = center.x() + (radius * 0.75) * math.cos(angle_rad)
            rivet_y = center.y() + (radius * 0.75) * math.sin(angle_rad)
            painter.drawEllipse(int(rivet_x - 4), int(rivet_y - 4), 8, 8)
        
        # Steampunk numbers - Victorian style
        if config['show_numbers']:
            font = QFont("Copperplate Gothic", 30, QFont.Bold)  # Increased to 30
            painter.setFont(font)
            
            for i in range(1, 13):
                angle = (i * 30) - 90
                angle_rad = math.radians(angle)
                x = center.x() + (radius - 70) * math.cos(angle_rad)  # MUCH more outward (was 0.6)
                y = center.y() + (radius - 70) * math.sin(angle_rad)
                
                # Brass plate behind numbers - yarı saydam
                painter.setBrush(QBrush(QColor(255, 248, 220, 150)))  # Light brass with transparency
                painter.setPen(QPen(copper_color, 1))
                rect_size = 40  # Larger plate for bigger numbers
                painter.drawRect(int(x - rect_size/2), int(y - rect_size/2), 
                               rect_size, rect_size)
                
                # Number
                painter.setPen(QPen(QColor(47, 79, 79), 2))
                rect = painter.fontMetrics().boundingRect(str(i))
                painter.drawText(int(x - rect.width()/2), int(y + rect.height()/2), str(i))
    
    @staticmethod
    def draw_clock_hands(painter, center, radius, style, config):
        """Draw clock hands based on style"""
        current_time = QTime.currentTime()
        hour = current_time.hour() % 12
        minute = current_time.minute()
        second = current_time.second()
        
        # Calculate angles
        hour_angle = (hour + minute / 60.0) * 30 - 90
        minute_angle = minute * 6 - 90
        second_angle = second * 6 - 90
        
        hour_rad = math.radians(hour_angle)
        minute_rad = math.radians(minute_angle)
        second_rad = math.radians(second_angle)
        
        # Define hand_color at the beginning for all styles
        hand_color = config['clock_color']
        
        if style == "neon":
            # Neon hands with glow
            # Hour hand
            for i in range(5, 0, -1):
                glow_color = QColor(config['clock_color'])
                glow_color.setAlpha(40)
                painter.setPen(QPen(glow_color, 8 + i * 2, Qt.SolidLine, Qt.RoundCap))
                painter.drawLine(center.x(), center.y(),
                               int(center.x() + radius * 0.5 * math.cos(hour_rad)),
                               int(center.y() + radius * 0.5 * math.sin(hour_rad)))
            
            painter.setPen(QPen(Qt.white, 6, Qt.SolidLine, Qt.RoundCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.5 * math.cos(hour_rad)),
                           int(center.y() + radius * 0.5 * math.sin(hour_rad)))
            
            # Minute hand
            for i in range(4, 0, -1):
                glow_color = QColor(config['clock_color'])
                glow_color.setAlpha(40)
                painter.setPen(QPen(glow_color, 6 + i * 2, Qt.SolidLine, Qt.RoundCap))
                painter.drawLine(center.x(), center.y(),
                               int(center.x() + radius * 0.7 * math.cos(minute_rad)),
                               int(center.y() + radius * 0.7 * math.sin(minute_rad)))
            
            painter.setPen(QPen(Qt.white, 4, Qt.SolidLine, Qt.RoundCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.7 * math.cos(minute_rad)),
                           int(center.y() + radius * 0.7 * math.sin(minute_rad)))
            
            # Second hand
            painter.setPen(QPen(QColor(255, 0, 255), 2, Qt.SolidLine, Qt.RoundCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.8 * math.cos(second_rad)),
                           int(center.y() + radius * 0.8 * math.sin(second_rad)))
        
        elif style == "industrial":
            # Industrial thick hands
            painter.setPen(QPen(QColor(150, 150, 150), 8, Qt.SolidLine, Qt.FlatCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.5 * math.cos(hour_rad)),
                           int(center.y() + radius * 0.5 * math.sin(hour_rad)))
            
            painter.setPen(QPen(QColor(180, 180, 180), 6, Qt.SolidLine, Qt.FlatCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.7 * math.cos(minute_rad)),
                           int(center.y() + radius * 0.7 * math.sin(minute_rad)))
            
            painter.setPen(QPen(QColor(200, 100, 100), 3, Qt.SolidLine, Qt.RoundCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.8 * math.cos(second_rad)),
                           int(center.y() + radius * 0.8 * math.sin(second_rad)))
        
        elif style == "luxury":
            # Luxury ornate hands
            # Hour hand - ornate with jewel
            painter.setPen(QPen(QColor(255, 215, 0), 8, Qt.SolidLine, Qt.RoundCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.5 * math.cos(hour_rad)),
                           int(center.y() + radius * 0.5 * math.sin(hour_rad)))
            
            # Minute hand - elegant gold
            painter.setPen(QPen(QColor(255, 215, 0), 6, Qt.SolidLine, Qt.RoundCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.7 * math.cos(minute_rad)),
                           int(center.y() + radius * 0.7 * math.sin(minute_rad)))
            
            # Second hand - thin elegant
            painter.setPen(QPen(QColor(220, 20, 60), 2, Qt.SolidLine, Qt.RoundCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.8 * math.cos(second_rad)),
                           int(center.y() + radius * 0.8 * math.sin(second_rad)))
        
        elif style == "minimalist":
            # Minimalist thin hands
            painter.setPen(QPen(hand_color, 3, Qt.SolidLine, Qt.RoundCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.5 * math.cos(hour_rad)),
                           int(center.y() + radius * 0.5 * math.sin(hour_rad)))
            
            painter.setPen(QPen(hand_color, 2, Qt.SolidLine, Qt.RoundCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.75 * math.cos(minute_rad)),
                           int(center.y() + radius * 0.75 * math.sin(minute_rad)))
            
            # No second hand for minimalist
        
        elif style == "retro":
            # Retro thick colorful hands
            painter.setPen(QPen(QColor(255, 140, 0), 10, Qt.SolidLine, Qt.RoundCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.4 * math.cos(hour_rad)),
                           int(center.y() + radius * 0.4 * math.sin(hour_rad)))
            
            painter.setPen(QPen(QColor(255, 69, 0), 8, Qt.SolidLine, Qt.RoundCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.6 * math.cos(minute_rad)),
                           int(center.y() + radius * 0.6 * math.sin(minute_rad)))
            
            painter.setPen(QPen(QColor(139, 69, 19), 4, Qt.SolidLine, Qt.RoundCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.7 * math.cos(second_rad)),
                           int(center.y() + radius * 0.7 * math.sin(second_rad)))
        
        elif style == "art_deco":
            # Art Deco geometric hands
            # Hour hand - geometric shape
            hour_points = [
                center,
                QPoint(int(center.x() + radius * 0.1 * math.cos(hour_rad - math.radians(90))),
                      int(center.y() + radius * 0.1 * math.sin(hour_rad - math.radians(90)))),
                QPoint(int(center.x() + radius * 0.5 * math.cos(hour_rad)),
                      int(center.y() + radius * 0.5 * math.sin(hour_rad))),
                QPoint(int(center.x() + radius * 0.1 * math.cos(hour_rad + math.radians(90))),
                      int(center.y() + radius * 0.1 * math.sin(hour_rad + math.radians(90))))
            ]
            painter.setBrush(QBrush(hand_color))
            painter.setPen(Qt.NoPen)
            painter.drawPolygon(QPolygon(hour_points))
            
            # Minute hand
            minute_points = [
                center,
                QPoint(int(center.x() + radius * 0.08 * math.cos(minute_rad - math.radians(90))),
                      int(center.y() + radius * 0.08 * math.sin(minute_rad - math.radians(90)))),
                QPoint(int(center.x() + radius * 0.7 * math.cos(minute_rad)),
                      int(center.y() + radius * 0.7 * math.sin(minute_rad))),
                QPoint(int(center.x() + radius * 0.08 * math.cos(minute_rad + math.radians(90))),
                      int(center.y() + radius * 0.08 * math.sin(minute_rad + math.radians(90))))
            ]
            painter.drawPolygon(QPolygon(minute_points))
            
            # Second hand
            painter.setPen(QPen(QColor(255, 0, 0), 2, Qt.SolidLine, Qt.RoundCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.8 * math.cos(second_rad)),
                           int(center.y() + radius * 0.8 * math.sin(second_rad)))
        
        elif style == "steampunk":
            # Steampunk mechanical hands
            # Hour hand - gear-like
            painter.setPen(QPen(QColor(184, 115, 51), 10, Qt.SolidLine, Qt.FlatCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.5 * math.cos(hour_rad)),
                           int(center.y() + radius * 0.5 * math.sin(hour_rad)))
            
            # Gear teeth on hour hand
            for i in range(3):
                gear_x = center.x() + (radius * 0.2 + i * radius * 0.1) * math.cos(hour_rad)
                gear_y = center.y() + (radius * 0.2 + i * radius * 0.1) * math.sin(hour_rad)
                painter.setBrush(QBrush(QColor(181, 166, 66)))
                painter.drawEllipse(int(gear_x - 4), int(gear_y - 4), 8, 8)
            
            # Minute hand
            painter.setPen(QPen(QColor(181, 166, 66), 8, Qt.SolidLine, Qt.FlatCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.7 * math.cos(minute_rad)),
                           int(center.y() + radius * 0.7 * math.sin(minute_rad)))
            
            # Second hand - thin brass
            painter.setPen(QPen(QColor(218, 165, 32), 2, Qt.SolidLine, Qt.RoundCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.8 * math.cos(second_rad)),
                           int(center.y() + radius * 0.8 * math.sin(second_rad)))
        
        else:
            # Default hands for modern, classic, elegant styles
            # Hour hand
            painter.setPen(QPen(hand_color, 6, Qt.SolidLine, Qt.RoundCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.5 * math.cos(hour_rad)),
                           int(center.y() + radius * 0.5 * math.sin(hour_rad)))
            
            # Minute hand
            painter.setPen(QPen(hand_color, 4, Qt.SolidLine, Qt.RoundCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.7 * math.cos(minute_rad)),
                           int(center.y() + radius * 0.7 * math.sin(minute_rad)))
            
            # Second hand
            painter.setPen(QPen(QColor(255, 0, 0), 2, Qt.SolidLine, Qt.RoundCap))
            painter.drawLine(center.x(), center.y(),
                           int(center.x() + radius * 0.8 * math.cos(second_rad)),
                           int(center.y() + radius * 0.8 * math.sin(second_rad)))
        
        # Center dot for all styles
        painter.setBrush(QBrush(hand_color))
        painter.setPen(QPen(hand_color, 2))
        painter.drawEllipse(center.x() - 5, center.y() - 5, 10, 10)