import sys
import os
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt

def main():
    # GStreamer sorunlarını önlemek için backend ayarları
    os.environ['QT_MULTIMEDIA_PREFERRED_PLUGINS'] = 'windowsmediafoundation,avfoundation,gstreamer'
    
    # X11 Authorization için environment variable'ları kopyala
    if 'DISPLAY' in os.environ:
        print(f"Environment variables:")
        print(f"DISPLAY: {os.environ.get('DISPLAY')}")
        print(f"QT_QPA_PLATFORM: {os.environ.get('QT_QPA_PLATFORM', 'xcb')}")
    
    # Desktop environment'ı tespit et
    desktop = os.environ.get('DESKTOP_SESSION', 'Unknown')
    print(f"Desktop Environment: {desktop}")
    
    # Qt ayarları
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    
    # Linux'ta video için gerekli olabilecek ek ayarlar
    os.environ.setdefault('QT_XCB_GL_INTEGRATION', 'none')
    
    app = QApplication(sys.argv)
    app.setApplicationName("Wheel Spinner")
    
    # Font ayarını kontrol et
    font = app.font()
    print(f"Using font: {font.family()}")
    
    # Ana pencereyi oluştur
    print("Creating main window...")
    from wheel_spinner_project.main_window import MainWindow
    window = MainWindow()
    window.show()
    
    print("Application started successfully")
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()