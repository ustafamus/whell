import math
import os
import subprocess
import sys
from PyQt5.QtWidgets import QWidget
from PyQt5.QtCore import Qt, QRect, QPoint, QTimer, QPropertyAnimation, QEasingCurve, pyqtSignal, pyqtProperty, QUrl
from PyQt5.QtGui import (QPainter, QColor, QFont, QPen, QBrush,
    QPixmap, QLinearGradient, QPolygon, QRadialGradient)
from PyQt5.QtMultimedia import QMediaPlayer, QMediaContent
from PyQt5.QtMultimediaWidgets import QVideoWidget


class WheelWidget(QWidget):
    """DYNAMIC wheel widget - scales to maximum window size always"""
    
    screen_saver_item_finished = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.num_slices = 8
        self.target_angle = 0
        self.background_image = None
        
        # Screen saver mode variables
        self.screen_saver_mode = False
        self.screen_saver_image = None
        self.screen_saver_video_placeholder = None
        self.screen_saver_timer = QTimer()
        self.screen_saver_timer.setSingleShot(True)
        self.screen_saver_timer.timeout.connect(self.on_screen_saver_finished)
        
        # Embedded video player
        self.video_player = None
        self.video_widget = None
        self.video_player_active = False
        self.current_video_path = None
        
        # Smooth transition variables
        self.transitioning = False
        self._transition_opacity = 1.0
        self.transition_animation = QPropertyAnimation(self, b"transitionOpacity")
        self.transition_animation.setDuration(300)
        self.transition_animation.setEasingCurve(QEasingCurve.InOutQuad)
        self.transition_animation.finished.connect(self.on_transition_finished)
        
        # Pending content for transitions
        self.pending_screen_saver_content = None
        
        self.colors = [
            QColor(231, 76, 60), QColor(230, 126, 34), QColor(241, 196, 15),
            QColor(46, 204, 113), QColor(26, 188, 156), QColor(52, 152, 219),
            QColor(155, 89, 182), QColor(149, 165, 166)
        ]
        
        # CRITICAL: Remove all size constraints - let widget expand dynamically
        from PyQt5.QtWidgets import QSizePolicy
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMinimumSize(0, 0)  # No minimum constraint
        self.setMaximumSize(16777215, 16777215)  # No maximum constraint
        
        print("DYNAMIC Wheel Widget initialized - will scale to maximum size")

    @pyqtProperty(float)
    def transitionOpacity(self):
        return self._transition_opacity

    @transitionOpacity.setter
    def transitionOpacity(self, value):
        self._transition_opacity = value
        self.update()

    def get_dynamic_wheel_radius(self):
        """Calculate MAXIMUM wheel radius based on current widget size"""
        # Use the FULL widget size (which expands to fill the window)
        widget_width = self.width()
        widget_height = self.height()
        
        # Calculate maximum possible radius (minimal padding for visual clarity)
        max_diameter = min(widget_width, widget_height) - 20  # Very small padding
        radius = max_diameter // 2
        
        # Ensure reasonable minimum
        radius = max(radius, 150)
        
        print(f"DYNAMIC wheel radius calculated: {radius} (widget size: {widget_width}x{widget_height})")
        return radius

    def set_slices(self, num_slices):
        self.num_slices = num_slices
        print(f"DYNAMIC wheel slices set to: {num_slices}")
        self.update()

    def set_target_angle(self, angle):
        self.target_angle = angle
        self.update()

    def set_background_image(self, image_path):
        if image_path and os.path.exists(image_path):
            pixmap = QPixmap(image_path)
            self.background_image = None if pixmap.isNull() else pixmap
            print(f"DYNAMIC wheel background image set: {os.path.basename(image_path) if image_path else 'None'}")
        else:
            self.background_image = None
        self.update()

    def start_screen_saver_mode(self, media_info):
        """Start screen saver mode with smooth transition"""
        print(f"Starting DYNAMIC screen saver mode: {media_info.get('type')} - {os.path.basename(media_info.get('path', ''))}")
        
        self.pending_screen_saver_content = media_info
        self.start_smooth_transition()

    def start_smooth_transition(self):
        """Start smooth transition animation"""
        if self.transitioning:
            return
        
        self.transitioning = True
        self.transition_animation.setStartValue(1.0)
        self.transition_animation.setEndValue(0.0)
        self.transition_animation.start()

    def on_transition_finished(self):
        """When transition animation finishes"""
        if self._transition_opacity <= 0.0:
            # Fade out finished, change content
            if self.pending_screen_saver_content == "EXIT":
                self.apply_exit_screen_saver()
            elif self.pending_screen_saver_content:
                self.apply_screen_saver_content(self.pending_screen_saver_content)
            
            self.pending_screen_saver_content = None
            
            # Start fade in
            self.transition_animation.setStartValue(0.0)
            self.transition_animation.setEndValue(1.0)
            self.transition_animation.start()
        else:
            # Fade in finished
            self.transitioning = False

    def apply_screen_saver_content(self, media_info):
        """Apply screen saver content to DYNAMIC wheel"""
        media_type = media_info.get('type')
        path = media_info.get('path')
        duration = media_info.get('duration', 5)
        
        self.screen_saver_mode = True
        
        if media_type == 'image':
            self.set_screen_saver_image(path)
            self.screen_saver_timer.start(duration * 1000)
        elif media_type == 'video':
            self.play_video_in_wheel(path, duration)

    def set_screen_saver_image(self, image_path):
        """Set screen saver image for DYNAMIC wheel"""
        if image_path and os.path.exists(image_path):
            pixmap = QPixmap(image_path)
            if not pixmap.isNull():
                self.screen_saver_image = self.create_circular_pixmap(pixmap)
                self.screen_saver_video_placeholder = None
                print(f"DYNAMIC screen saver image set: {os.path.basename(image_path)}")
                self.update()
            else:
                print("Failed to load DYNAMIC screen saver image")
                self.screen_saver_image = None
        else:
            print(f"DYNAMIC screen saver image file not found: {image_path}")
            self.screen_saver_image = None

    def play_video_in_wheel(self, video_path, duration):
        """Play video embedded in DYNAMIC wheel"""
        if not video_path or not os.path.exists(video_path):
            print(f"DYNAMIC video file not found: {video_path}")
            self.on_screen_saver_finished()
            return
        
        print(f"Playing DYNAMIC video: {os.path.basename(video_path)} for {duration}s")
        
        # Clean previous video player
        self.stop_video_player()
        
        # Get DYNAMIC wheel geometry
        wheel_geo = self.get_dynamic_wheel_circle_geometry()
        if not wheel_geo:
            print("Could not determine DYNAMIC wheel geometry")
            self.on_screen_saver_finished()
            return
        
        x, y, diameter = wheel_geo
        
        # Create video widget
        self.video_widget = QVideoWidget(self)
        self.video_widget.setGeometry(x, y, diameter, diameter)
        self.video_widget.show()
        
        # Create video player
        self.video_player = QMediaPlayer()
        self.video_player.setVideoOutput(self.video_widget)
        self.video_player.setMedia(QMediaContent(QUrl.fromLocalFile(video_path)))
        
        # Apply circular mask
        self.apply_circular_mask_to_video(diameter)
        
        # Connect signals
        self.video_player.stateChanged.connect(self.handle_video_state)
        self.video_player.error.connect(self.handle_video_error)
        
        # Play video
        self.video_player.play()
        self.video_player_active = True
        self.current_video_path = video_path
        
        # Start duration timer
        self.screen_saver_timer.start(duration * 1000)
        print("DYNAMIC embedded video player started")

    def apply_circular_mask_to_video(self, diameter):
        """Apply circular mask to video widget"""
        if self.video_widget:
            mask = QPixmap(diameter, diameter)
            mask.fill(Qt.transparent)
            
            painter = QPainter(mask)
            painter.setRenderHint(QPainter.Antialiasing)
            painter.setBrush(Qt.black)
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(0, 0, diameter, diameter)
            painter.end()
            
            self.video_widget.setMask(mask.mask())

    def handle_video_state(self, state):
        """Handle video state changes"""
        if state == QMediaPlayer.StoppedState:
            print("DYNAMIC video stopped")

    def handle_video_error(self):
        """Handle video playback error"""
        if self.video_player:
            error_msg = self.video_player.errorString()
            print(f"DYNAMIC video player error: {error_msg}")
        else:
            print("DYNAMIC video player error: Player is None")
        self.stop_video_player()
        self.on_screen_saver_finished()

    def get_dynamic_wheel_circle_geometry(self):
        """Return DYNAMIC wheel circle geometry (x, y, diameter)"""
        try:
            # Get current dynamic radius
            outer_radius = self.get_dynamic_wheel_radius()
            
            # Calculate center of widget
            cx, cy = self.width() // 2, self.height() // 2
            
            # Circle diameter and position
            diameter = outer_radius * 2
            x = cx - outer_radius
            y = cy - outer_radius
            
            return x, y, diameter
        except:
            return None

    def stop_video_player(self):
        """Stop and clean video player"""
        if self.video_player:
            print("Stopping DYNAMIC embedded video player")
            try:
                self.video_player.stop()
                self.video_player.setMedia(QMediaContent())
            except Exception as e:
                print(f"Error stopping DYNAMIC video player: {e}")
            finally:
                self.video_player = None
        
        if self.video_widget:
            try:
                self.video_widget.hide()
                self.video_widget.deleteLater()
            except Exception as e:
                print(f"Error cleaning DYNAMIC video widget: {e}")
            finally:
                self.video_widget = None
        
        self.video_player_active = False
        self.current_video_path = None

    def create_circular_pixmap(self, source_pixmap):
        """Make pixmap circular with DYNAMIC wheel size"""
        radius = self.get_dynamic_wheel_radius()
        circle_diameter = radius * 2
        
        # Scale to DYNAMIC size
        scaled = source_pixmap.scaled(
            circle_diameter, circle_diameter, 
            Qt.KeepAspectRatioByExpanding,
            Qt.SmoothTransformation
        )
        
        # Crop if needed
        if scaled.width() > circle_diameter or scaled.height() > circle_diameter:
            crop_x = (scaled.width() - circle_diameter) // 2
            crop_y = (scaled.height() - circle_diameter) // 2
            scaled = scaled.copy(crop_x, crop_y, circle_diameter, circle_diameter)
        
        # Apply circular mask
        mask = QPixmap(circle_diameter, circle_diameter)
        mask.fill(Qt.transparent)
        mp = QPainter(mask)
        mp.setRenderHint(QPainter.Antialiasing)
        mp.setBrush(Qt.black)
        mp.setPen(Qt.NoPen)
        mp.drawEllipse(0, 0, circle_diameter, circle_diameter)
        mp.end()
        
        scaled.setMask(mask.mask())
        return scaled

    def create_video_placeholder(self, video_path):
        """Create video placeholder pixmap for DYNAMIC wheel"""
        radius = self.get_dynamic_wheel_radius()
        circle_diameter = radius * 2
        
        placeholder = QPixmap(circle_diameter, circle_diameter)
        placeholder.fill(Qt.transparent)
        
        painter = QPainter(placeholder)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Gradient background
        gradient = QRadialGradient(radius, radius, radius)
        gradient.setColorAt(0, QColor(60, 60, 80))
        gradient.setColorAt(0.7, QColor(40, 40, 60))
        gradient.setColorAt(1, QColor(20, 20, 40))
        
        painter.setBrush(QBrush(gradient))
        painter.setPen(QPen(QColor(100, 100, 120), 3))
        painter.drawEllipse(0, 0, circle_diameter, circle_diameter)
        
        # Video icon and text - scale with wheel size
        painter.setPen(QPen(QColor(255, 255, 255)))
        
        # Scale font sizes based on wheel size
        icon_size = max(48, radius // 8)
        text_size = max(14, radius // 25)
        status_size = max(16, radius // 20)
        
        # Video icon
        icon_font = painter.font()
        icon_font.setPointSize(icon_size)
        painter.setFont(icon_font)
        painter.drawText(0, 0, circle_diameter, circle_diameter//2 + 20, Qt.AlignCenter, "▶")
        
        # Video name
        video_name = os.path.basename(video_path)
        short_name = video_name[:25] + "..." if len(video_name) > 25 else video_name
        
        text_font = painter.font()
        text_font.setPointSize(text_size)
        text_font.setBold(True)
        painter.setFont(text_font)
        painter.drawText(10, circle_diameter//2 + 30, circle_diameter - 20, 60, 
                        Qt.AlignCenter | Qt.TextWordWrap, short_name)
        
        # Status text
        status_font = painter.font()
        status_font.setPointSize(status_size)
        status_font.setBold(False)
        painter.setFont(status_font)
        painter.setPen(QPen(QColor(100, 255, 100)))
        
        status_text = "Playing..." if self.video_player_active else "Loading..."
        painter.drawText(0, circle_diameter - 80, circle_diameter, 40, 
                        Qt.AlignCenter, status_text)
        
        painter.end()
        return placeholder

    def exit_screen_saver_mode(self):
        """Exit screen saver mode with smooth transition"""
        if not self.screen_saver_mode:
            return
        
        print("Exiting DYNAMIC screen saver mode")
        
        # Stop video player
        self.stop_video_player()
        
        # Stop timer
        if self.screen_saver_timer.isActive():
            self.screen_saver_timer.stop()
        
        # Smooth transition to clear content
        self.pending_screen_saver_content = "EXIT"
        self.start_smooth_transition()

    def apply_exit_screen_saver(self):
        """Apply screen saver exit"""
        self.screen_saver_mode = False
        self.screen_saver_image = None
        self.screen_saver_video_placeholder = None
        print("DYNAMIC screen saver mode exited")

    def on_screen_saver_finished(self):
        """When screen saver item finishes"""
        print("DYNAMIC screen saver item finished")
        
        # Stop video player if active
        if self.video_player_active:
            self.stop_video_player()
        
        self.screen_saver_item_finished.emit()

    def resizeEvent(self, event):
        """DYNAMIC resize event - reposition video player"""
        super().resizeEvent(event)
        
        print(f"DYNAMIC wheel resize: {self.width()}x{self.height()}, radius: {self.get_dynamic_wheel_radius()}")
        
        # If video is playing, reposition it to new DYNAMIC size
        if self.video_player_active and self.video_widget:
            wheel_geo = self.get_dynamic_wheel_circle_geometry()
            if wheel_geo:
                x, y, diameter = wheel_geo
                self.video_widget.setGeometry(x, y, diameter, diameter)
                self.apply_circular_mask_to_video(diameter)
                print(f"DYNAMIC video repositioned to {x},{y} diameter {diameter}")

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Apply transition opacity
        if self.transitioning and self._transition_opacity < 1.0:
            painter.setOpacity(self._transition_opacity)

        # Get DYNAMIC dimensions
        cx, cy = self.width() // 2, self.height() // 2
        outer_radius = self.get_dynamic_wheel_radius()
        rect = QRect(cx - outer_radius, cy - outer_radius, outer_radius * 2, outer_radius * 2)

        # Screen saver mode
        if self.screen_saver_mode:
            self.paint_screen_saver_mode(painter, cx, cy, outer_radius)
        else:
            # Normal DYNAMIC wheel mode
            self.paint_normal_wheel_mode(painter, cx, cy, outer_radius, rect)

    def paint_screen_saver_mode(self, painter, cx, cy, radius):
        """Paint DYNAMIC screen saver mode"""
        if self.video_player_active:
            # Minimal background for video
            painter.setBrush(QBrush(QColor(0, 0, 0, 50)))
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(QPoint(cx, cy), radius, radius)
            
            # Green frame for video
            painter.setBrush(Qt.NoBrush)
            painter.setPen(QPen(QColor(100, 255, 100, 150), 3))
            painter.drawEllipse(QPoint(cx, cy), radius, radius)
            
        else:
            # Screen saver image
            if self.screen_saver_image:
                draw_x = cx - self.screen_saver_image.width() // 2
                draw_y = cy - self.screen_saver_image.height() // 2
                painter.drawPixmap(draw_x, draw_y, self.screen_saver_image)
            
            # Video placeholder
            elif self.screen_saver_video_placeholder:
                draw_x = cx - self.screen_saver_video_placeholder.width() // 2
                draw_y = cy - self.screen_saver_video_placeholder.height() // 2
                painter.drawPixmap(draw_x, draw_y, self.screen_saver_video_placeholder)
            
            # Outer frame
            painter.setBrush(Qt.NoBrush)
            painter.setPen(QPen(QColor(100, 100, 100, 150), 2))
            painter.drawEllipse(QPoint(cx, cy), radius, radius)

    def paint_normal_wheel_mode(self, painter, cx, cy, outer_radius, rect):
        """Paint normal DYNAMIC wheel mode"""
        if self.num_slices <= 0: 
            return
        
        slice_angle = 360 / self.num_slices
        slice_offset = slice_angle
        visual_rotation = 90 - self.target_angle - slice_offset
        pointer_position_on_wheel = (90 + visual_rotation) % 360
        selected_index = int(pointer_position_on_wheel / slice_angle) % self.num_slices

        # Outer Circle
        painter.setBrush(Qt.NoBrush)
        painter.setPen(QPen(QColor(100, 100, 100, 150), 2))
        painter.drawEllipse(QPoint(cx, cy), outer_radius, outer_radius)

        # DYNAMIC Background image
        painter.save()
        painter.translate(cx, cy)
        painter.rotate(-self.target_angle)
        painter.translate(-cx, -cy)

        if self.background_image:
            circle_diameter = outer_radius * 2
            scaled = self.background_image.scaled(
                circle_diameter, circle_diameter, 
                Qt.KeepAspectRatioByExpanding,
                Qt.SmoothTransformation
            )
            
            if scaled.width() > circle_diameter or scaled.height() > circle_diameter:
                crop_x = (scaled.width() - circle_diameter) // 2
                crop_y = (scaled.height() - circle_diameter) // 2
                scaled = scaled.copy(crop_x, crop_y, circle_diameter, circle_diameter)
            
            # Create DYNAMIC circular mask
            mask = QPixmap(circle_diameter, circle_diameter)
            mask.fill(Qt.transparent)
            mp = QPainter(mask)
            mp.setRenderHint(QPainter.Antialiasing)
            mp.setBrush(Qt.black)
            mp.setPen(Qt.NoPen)
            mp.drawEllipse(0, 0, circle_diameter, circle_diameter)
            mp.end()
            
            scaled.setMask(mask.mask())
            draw_x = cx - circle_diameter // 2
            draw_y = cy - circle_diameter // 2
            painter.drawPixmap(draw_x, draw_y, scaled)

        painter.restore()

        # DYNAMIC Slices and numbers
        painter.save()
        painter.translate(cx, cy)
        painter.rotate(visual_rotation)
        painter.translate(-cx, -cy)

        # Non-selected slices overlay
        for i in range(self.num_slices):
            start_angle = i * slice_angle
            if i != selected_index:
                painter.setBrush(QColor(255, 255, 255, 200))
                painter.setPen(Qt.NoPen)
                painter.drawPie(rect, int(start_angle * 16), int(slice_angle * 16))

        # Slice lines
        for i in range(self.num_slices):
            start_angle = i * slice_angle
            angle_rad = math.radians(start_angle)
            x1, y1 = cx, cy
            x2 = cx + outer_radius * math.cos(angle_rad)
            y2 = cy + outer_radius * math.sin(angle_rad)
            painter.setPen(QPen(QColor(80, 80, 80, 120), 1.5, Qt.SolidLine))
            painter.drawLine(int(x1), int(y1), int(x2), int(y2))

        # DYNAMIC Slice numbers - scale font with wheel size
        number_font_size = max(11, outer_radius // 25)  # Scale with wheel size
        
        for i in range(self.num_slices):
            center_angle = (i * slice_angle) + (slice_angle / 2)
            angle_rad = math.radians(center_angle)
            text_radius = outer_radius * 0.75
            tx = cx + text_radius * math.cos(angle_rad)
            ty = cy + text_radius * math.sin(angle_rad)

            painter.save()
            painter.translate(tx, ty)
            text_rot = center_angle
            if 90 < center_angle <= 270: 
                text_rot += 180
            painter.rotate(text_rot)
            
            # Scale text size with wheel
            painter.setPen(QPen(QColor(0, 0, 0, 100)))
            painter.setFont(QFont("Arial", number_font_size, QFont.Bold))
            
            # Scale text rect with wheel size
            text_rect_width = max(80, outer_radius // 6)
            text_rect_height = max(16, outer_radius // 25)
            
            painter.drawText(QRect(-text_rect_width//2 + 1, -text_rect_height//2 + 1, 
                                 text_rect_width, text_rect_height), 
                           Qt.AlignCenter, f"No: {i + 1}")
            
            painter.setPen(QPen(QColor(255, 255, 255)))
            painter.drawText(QRect(-text_rect_width//2, -text_rect_height//2, 
                                 text_rect_width, text_rect_height), 
                           Qt.AlignCenter, f"No: {i + 1}")
            painter.restore()

        painter.restore()

        # DYNAMIC Center point - scale with wheel
        center_size = max(8, outer_radius // 30)
        painter.setBrush(QBrush(QColor(120, 120, 120, 150)))
        painter.setPen(QPen(QColor(80, 80, 80, 100), 1))
        painter.drawEllipse(QPoint(cx, cy), center_size, center_size)

        # DYNAMIC Pointer - scale with wheel
        pointer_size = max(25, outer_radius // 15)
        pointer_offset = outer_radius + 8
        ax, ay = cx, cy - pointer_offset
        
        painter.setBrush(QBrush(QColor(220, 53, 69)))
        painter.setPen(QPen(QColor(120, 30, 40), 2))
        
        arrow = QPolygon([
            QPoint(ax, ay + pointer_size), 
            QPoint(ax - pointer_size // 2, ay), 
            QPoint(ax + pointer_size // 2, ay)
        ])
        painter.drawPolygon(arrow)
        
        # Pointer highlight
        highlight_size = max(4, outer_radius // 50)
        painter.setBrush(QColor(255, 100, 110))
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(QPoint(ax, ay + 4), highlight_size, highlight_size)
        
        print(f"DYNAMIC wheel painted - radius: {outer_radius}, center: ({cx},{cy})")
