import os
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
    QComboBox, QPushButton, QMessageBox)
from PyQt5.QtCore import Qt, QPropertyAnimation, QEasingCurve, pyqtSignal
from PyQt5.QtGui import QPainter, QColor, QBrush, QPen, QFont
from .image_manager import ImageManager  # Import our modular image manager

# Video format checker import - updated
try:
    from .video_player import is_supported_video_format
except ImportError:
    try:
        from video_player import is_supported_video_format
    except ImportError:
        print("Warning: video_player module not found. Using fallback video format checker.")
        def is_supported_video_format(file_path):
            """Fallback video format checker"""
            if not file_path or not os.path.exists(file_path):
                return False
            supported_formats = ('.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv', '.webm', '.m4v')
            return file_path.lower().endswith(supported_formats)


class MenuWidget(QWidget):
    game_image_selected = pyqtSignal(str)
    clock_image_selected = pyqtSignal(str)
    screen_saver_selected = pyqtSignal(str)
    slices_changed = pyqtSignal(int)
    save_clicked = pyqtSignal()
    clock_config_requested = pyqtSignal(dict)  # Clock configuration signal - send current config too
    clock_duration_changed = pyqtSignal(int)  # Clock duration signal
    screen_saver_config_changed = pyqtSignal(list) # Screen saver config signal
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.is_visible = False
        self.animation = None
        self.wheel_outer_radius = 200
        self.image_folder = os.path.join(os.path.dirname(__file__), "images")
        self.video_folder = os.path.join(os.path.dirname(__file__), "videos") # Video folder
        self.current_clock_config = None  # Store current clock config
        self.setup_ui()
        self.setup_animation()

    def setup_ui(self):
        self.setFixedSize(400, 400)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setWindowFlags(Qt.FramelessWindowHint)
        
        self.setStyleSheet("""
            QWidget { background: transparent; }
            QLabel {
                color: white;
                font-size: 12px;
                font-weight: bold;
                background: transparent;
                border: none;
                padding: 0px;
                margin: 0px;
            }
            QComboBox {
                background-color: white;
                border: 1px solid #ccc;
                border-radius: 6px;
                padding: 4px 8px;
                font-size: 11px;
                min-height: 20px;
                max-height: 24px;
                font-weight: bold;
                color: black;
            }
            QLabel.textBox {
                background-color: white;
                border: 1px solid #ccc;
                border-radius: 6px;
                padding: 4px 8px;
                font-size: 11px;
                min-height: 20px;
                max-height: 24px;
                color: black;
                font-weight: bold;
            }
            QLabel.textBox:hover {
                background-color: #f0f0f0;
                border-color: #007bff;
            }
            QPushButton {
                background-color: #d32f2f;
                color: white;
                border: none;
                border-radius: 8px;
                padding: 8px 20px;
                font-size: 14px;
                font-weight: bold;
                min-width: 80px;
                min-height: 32px;
            }
            QPushButton:hover {
                background-color: #b71c1c;
            }
        """)
        
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(40, 40, 40, 40)
        main_layout.setSpacing(8)

        # 1. Game Image Section
        game_header = QLabel("Select Game Image")
        slices_header = QLabel("Slices")
        
        game_header_layout = QHBoxLayout()
        game_header_layout.addWidget(game_header)
        game_header_layout.addStretch()
        game_header_layout.addWidget(slices_header)
        main_layout.addLayout(game_header_layout)

        game_layout = QHBoxLayout()
        game_layout.setSpacing(8)
        self.game_text_box = QLabel("Click to choose image")
        self.game_text_box.setProperty("class", "textBox")
        self.game_text_box.setStyleSheet("QLabel { background-color: white; }")
        self.game_text_box.setCursor(Qt.PointingHandCursor)
        self.game_text_box.mousePressEvent = self.select_game_image
        self.slices_combo = QComboBox()
        self.slices_combo.addItems(["2","3","4","5","6", "8", "12", "16","20","24"])
        self.slices_combo.setCurrentText("8")
        self.slices_combo.setFixedWidth(60)
        game_layout.addWidget(self.game_text_box, 1)
        game_layout.addWidget(self.slices_combo)
        main_layout.addLayout(game_layout)

        # 2. Clock Section - Updated
        clock_header = QLabel("Clock Settings")
        duration_header = QLabel("Duration")
        
        clock_header_layout = QHBoxLayout()
        clock_header_layout.addWidget(clock_header)
        clock_header_layout.addStretch()
        clock_header_layout.addWidget(duration_header)
        main_layout.addLayout(clock_header_layout)

        clock_layout = QHBoxLayout()
        clock_layout.setSpacing(8)
        self.clock_text_box = QLabel("Click to configure clock")
        self.clock_text_box.setProperty("class", "textBox")
        self.clock_text_box.setStyleSheet("QLabel { background-color: white; }")
        self.clock_text_box.setCursor(Qt.PointingHandCursor)
        self.clock_text_box.mousePressEvent = self.configure_clock  # Make clickable
        self.duration_combo = QComboBox()
        self.duration_combo.addItems(["1", "2", "5", "10", "15", "20", "22", "25", "30"])
        self.duration_combo.setCurrentText("1")
        self.duration_combo.setFixedWidth(60)
        # Listen to duration changes
        self.duration_combo.currentTextChanged.connect(self.on_clock_duration_changed)
        
        clock_layout.addWidget(self.clock_text_box, 1)
        clock_layout.addWidget(self.duration_combo)
        main_layout.addLayout(clock_layout)

        # 3. Screen Saver Section
        saver_header = QLabel("Select Screen Saver")
        duration_header2 = QLabel("Duration")
        
        saver_header_layout = QHBoxLayout()
        saver_header_layout.addWidget(saver_header)
        saver_header_layout.addStretch()
        saver_header_layout.addWidget(duration_header2)
        main_layout.addLayout(saver_header_layout)

        # Product 1
        product_layout1 = QHBoxLayout()
        product_layout1.setSpacing(8)
        self.product_text_box1 = QLabel("Click to choose image")
        self.product_text_box1.setProperty("class", "textBox")
        self.product_text_box1.setCursor(Qt.PointingHandCursor)
        self.product_text_box1.mousePressEvent = lambda event: self.select_screen_saver_image(event, self.product_text_box1)
        self.duration_combo1 = QComboBox()
        self.duration_combo1.addItems(["1", "2", "3", "4", "5", "10"])
        self.duration_combo1.setCurrentText("4")
        self.duration_combo1.setFixedWidth(60)
        product_layout1.addWidget(self.product_text_box1, 1)
        product_layout1.addWidget(self.duration_combo1)
        main_layout.addLayout(product_layout1)

        # Product 2
        product_layout2 = QHBoxLayout()
        product_layout2.setSpacing(8)
        self.product_text_box2 = QLabel("Click to choose image")
        self.product_text_box2.setProperty("class", "textBox")
        self.product_text_box2.setCursor(Qt.PointingHandCursor)
        self.product_text_box2.mousePressEvent = lambda event: self.select_screen_saver_image(event, self.product_text_box2)
        self.duration_combo2 = QComboBox()
        self.duration_combo2.addItems(["1", "2", "3", "4", "5", "6", "10"])
        self.duration_combo2.setCurrentText("6")
        self.duration_combo2.setFixedWidth(60)
        product_layout2.addWidget(self.product_text_box2, 1)
        product_layout2.addWidget(self.duration_combo2)
        main_layout.addLayout(product_layout2)

        # Product 3
        product_layout3 = QHBoxLayout()
        product_layout3.setSpacing(8)
        self.product_text_box3 = QLabel("Click to choose image")
        self.product_text_box3.setProperty("class", "textBox")
        self.product_text_box3.setCursor(Qt.PointingHandCursor)
        self.product_text_box3.mousePressEvent = lambda event: self.select_screen_saver_image(event, self.product_text_box3)
        self.duration_combo3 = QComboBox()
        self.duration_combo3.addItems(["1", "2", "3", "4", "5", "6", "10"])
        self.duration_combo3.setCurrentText("6")
        self.duration_combo3.setFixedWidth(60)
        product_layout3.addWidget(self.product_text_box3, 1)
        product_layout3.addWidget(self.duration_combo3)
        main_layout.addLayout(product_layout3)

        # Introduction Video
        intro_layout = QHBoxLayout()
        intro_layout.setSpacing(8)
        self.intro_text_box = QLabel("Click to choose video")
        self.intro_text_box.setProperty("class", "textBox")
        self.intro_text_box.setCursor(Qt.PointingHandCursor)
        self.intro_text_box.mousePressEvent = lambda event: self.select_video_file(event, self.intro_text_box, "Introduction Video")
        self.intro_duration_combo = QComboBox()
        self.intro_duration_combo.addItems(["10", "15", "20", "25", "30", "35", "40"])
        self.intro_duration_combo.setCurrentText("30")
        self.intro_duration_combo.setFixedWidth(60)
        intro_layout.addWidget(self.intro_text_box, 1)
        intro_layout.addWidget(self.intro_duration_combo)
        main_layout.addLayout(intro_layout)

        # Promotion Video
        promo_layout = QHBoxLayout()
        promo_layout.setSpacing(8)
        self.promo_text_box = QLabel("Click to choose video")
        self.promo_text_box.setProperty("class", "textBox")
        self.promo_text_box.setCursor(Qt.PointingHandCursor)
        self.promo_text_box.mousePressEvent = lambda event: self.select_video_file(event, self.promo_text_box, "Promotion Video")
        self.promo_duration_combo = QComboBox()
        self.promo_duration_combo.addItems(["10", "15", "20", "25", "30", "35", "40"])
        self.promo_duration_combo.setCurrentText("30")
        self.promo_duration_combo.setFixedWidth(60)
        promo_layout.addWidget(self.promo_text_box, 1)
        promo_layout.addWidget(self.promo_duration_combo)
        main_layout.addLayout(promo_layout)

        # Save Button
        main_layout.addSpacing(10)
        button_layout = QHBoxLayout()
        button_layout.setContentsMargins(0, 0, 0, 0)
        self.save_button = QPushButton("Save")
        self.save_button.clicked.connect(self.on_save_clicked)
        button_layout.addStretch()
        button_layout.addWidget(self.save_button)
        button_layout.addStretch()
        main_layout.addLayout(button_layout)

        # Connect signals
        self.slices_combo.currentTextChanged.connect(self.on_slices_changed)
        
        self.hide()

    def set_current_clock_config(self, config):
        """Store current clock config and update UI"""
        print(f"DEBUG MENU: set_current_clock_config called with: {config.get('clock_type', 'None') if config else 'None'}")
        self.current_clock_config = config.copy() if config else None
        self.update_clock_text_display()
        print(f"DEBUG MENU: Config saved, current_clock_config is now: {self.current_clock_config.get('clock_type', 'None') if self.current_clock_config else 'None'}")

    def update_clock_text_display(self):
        """Update clock text box content according to current config"""
        if self.current_clock_config:
            clock_type = self.current_clock_config.get('clock_type', 'Analog')
            if clock_type == 'Digital':
                style = self.current_clock_config.get('digital_style', 'neon')
                display_text = f"Digital - {style.capitalize()}"
            else:
                style = self.current_clock_config.get('analog_style', 'modern')
                display_text = f"Analog - {style.capitalize()}"
            
            self.clock_text_box.setText(display_text)
        else:
            self.clock_text_box.setText("Click to configure clock")

    def on_clock_duration_changed(self, text):
        """Called when clock duration changes"""
        if text.isdigit():
            self.clock_duration_changed.emit(int(text))    

    def configure_clock(self, event):
        """Send signal for clock configuration"""
        # Send current config with signal - not empty dict
        current_config = self.current_clock_config if self.current_clock_config else {}
        print(f"DEBUG MENU: Sending config to dialog: {current_config.get('clock_type', 'None')}")
        self.clock_config_requested.emit(current_config)

    def select_game_image(self, event):
        """Use modular ImageManager for game image selection"""
        try:
            selected_file = ImageManager.show_image_selection_dialog(
                parent=self,
                image_folder=self.image_folder,
                title="Select Game Image",
                enable_add=True
            )
            
            if selected_file:
                filename = os.path.basename(selected_file)
                self.game_text_box.setText(filename)
                # Store full path as data attribute for later use
                self.game_text_box.setProperty("full_path", selected_file)
                self.game_image_selected.emit(selected_file)
                
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to select image: {str(e)}")
        
    def select_screen_saver_image(self, event, text_box):
        """Use modular ImageManager for screen saver image selection"""
        try:
            selected_file = ImageManager.show_image_selection_dialog(
                parent=self,
                image_folder=self.image_folder,
                title="Select Screen Saver Image",
                enable_add=True
            )

            if selected_file:
                filename = os.path.basename(selected_file)
                text_box.setText(filename)
                # Store full path as data attribute for later use
                text_box.setProperty("full_path", selected_file)
                self.screen_saver_selected.emit(selected_file)
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to select image: {str(e)}")

    def select_video_file(self, event, text_box, title):
        """Use modular ImageManager for video file selection with video format validation"""
        try:
            # Create video folder if it doesn't exist
            if not os.path.exists(self.video_folder):
                os.makedirs(self.video_folder)

            # Special dialog for video selection
            selected_file = self.show_video_selection_dialog(title)

            if selected_file:
                # Check video format
                if is_supported_video_format(selected_file):
                    filename = os.path.basename(selected_file)
                    text_box.setText(filename)
                    # Store full path as data attribute for later use
                    text_box.setProperty("full_path", selected_file)
                    print(f"Video selected: {filename} for {title}")
                else:
                    QMessageBox.warning(self, "Unsupported Format",
                        "Selected file is not a supported video format.\n"
                        "Supported formats: MP4, AVI, MOV, MKV, WEBM")

        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to select video: {str(e)}")
            print(f"Error selecting video: {str(e)}")

    def show_video_selection_dialog(self, title):
        """Special dialog for video selection"""
        try:
            # Use ImageManager's video version for video selection
            selected_file = ImageManager.show_video_selection_dialog(
                parent=self,
                video_folder=self.video_folder,
                title=title,
                enable_add=True
            )
            
            if selected_file:
                return selected_file
            
            return None
            
        except Exception as e:
            print(f"Error in video selection: {e}")
            return None
        
    def setup_animation(self):
        self.animation = QPropertyAnimation(self, b"windowOpacity")
        self.animation.setDuration(300)
        self.animation.setEasingCurve(QEasingCurve.InOutQuad)
        
    def update_size(self, wheel_outer_radius):
        self.wheel_outer_radius = wheel_outer_radius
        menu_size = int(self.wheel_outer_radius * 2 + 20)
        self.setFixedSize(menu_size, menu_size)
        margin = int(menu_size * 0.18)
        self.layout().setContentsMargins(margin, margin, margin, margin)
        
    def toggle_menu(self):
        if self.is_visible:
            self.hide_menu()
        else:
            self.show_menu()
        
    def show_menu(self):
        if not self.is_visible:
            self.is_visible = True
            self.show()
            self.animation.setStartValue(0.0)
            self.animation.setEndValue(1.0)
            self.animation.start()
        
    def hide_menu(self):
        if self.is_visible:
            self.is_visible = False
            self.animation.setStartValue(1.0)
            self.animation.setEndValue(0.0)
            self.animation.finished.connect(self._animation_finished_hide)
            self.animation.start()
        
    def _animation_finished_hide(self):
        self.hide()
        self.animation.finished.disconnect(self._animation_finished_hide)
        
    def position_over_wheel(self, wheel_center_x, wheel_center_y):
        menu_x = wheel_center_x - self.width() // 2
        menu_y = wheel_center_y - self.height() // 2
        self.move(menu_x, menu_y)
        
    def on_game_image_changed(self, text):
        self.game_text_box.setText(text)
        self.game_image_selected.emit(text)
        
    def on_clock_image_changed(self, text):
        self.clock_text_box.setText(text)
        self.clock_image_selected.emit(text)
        
    def on_screen_saver_changed(self, text):
        self.screen_saver_selected.emit(text)
        
    def on_slices_changed(self, text):
        if text.isdigit():
            self.slices_changed.emit(int(text))

    def on_save_clicked(self):
        # Emit current duration value when save button is pressed
        duration = int(self.duration_combo.currentText())
        self.clock_duration_changed.emit(duration)

        # Collect screen saver settings
        screen_saver_config = []

        # Images - USE FULL PATH
        image_boxes = [self.product_text_box1, self.product_text_box2, self.product_text_box3]
        duration_combos = [self.duration_combo1, self.duration_combo2, self.duration_combo3]
        for i, box in enumerate(image_boxes):
            path = box.text()
            if path != "Click to choose image":
                # Get full path from property, use old method if not available
                full_path = box.property("full_path")
                if not full_path:
                    full_path = os.path.join(self.image_folder, path)

                screen_saver_config.append({
                    'type': 'image',
                    'path': full_path,
                    'duration': int(duration_combos[i].currentText())
                })

        # Videos - USE FULL PATH
        video_boxes = [self.intro_text_box, self.promo_text_box]
        video_duration_combos = [self.intro_duration_combo, self.promo_duration_combo]
        video_names = ["Introduction", "Promotion"]

        for i, box in enumerate(video_boxes):
            path = box.text()
            if path != "Click to choose video":
                # Get full path from property, use old method if not available
                full_path = box.property("full_path")
                if not full_path:
                    full_path = os.path.join(self.video_folder, path)

                # Check if video file exists and is supported format
                if os.path.exists(full_path) and is_supported_video_format(full_path):
                    screen_saver_config.append({
                        'type': 'video',
                        'path': full_path,
                        'duration': int(video_duration_combos[i].currentText()),
                        'name': video_names[i]
                    })
                    print(f"Added {video_names[i]} video to screen saver config: {full_path}")
                else:
                    print(f"Warning: {video_names[i]} video file not found or unsupported: {full_path}")

        print(f"Screen saver config created with {len(screen_saver_config)} items")
        self.screen_saver_config_changed.emit(screen_saver_config)
        self.save_clicked.emit()
        self.hide_menu()
        
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        center = self.rect().center()
        radius = self.wheel_outer_radius
        
        # Background Circle
        painter.setBrush(QBrush(QColor(50, 50, 50, 180)))
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(center.x() - radius, center.y() - radius, 
                           radius * 2, radius * 2)
        
        # Outer Frame
        painter.setBrush(QBrush(QColor(0, 0, 0, 0)))
        painter.setPen(QPen(QColor(255, 255, 255, 80), 2))
        painter.drawEllipse(center.x() - radius, center.y() - radius, 
                           radius * 2, radius * 2)
        
        # Inner Frame
        painter.setPen(QPen(QColor(0, 123, 255, 100), 1))
        painter.drawEllipse(center.x() - radius + 3, center.y() - radius + 3, 
                           (radius - 3) * 2, (radius - 3) * 2)
        
        super().paintEvent(event)
